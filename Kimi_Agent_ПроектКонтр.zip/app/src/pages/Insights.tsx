import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Code2,
  Box,
  Zap,
  Shield,
  CheckCircle,
  XCircle,
  Filter,
} from "lucide-react";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Legend,
} from "recharts";

const typeIcons: Record<string, typeof Code2> = {
  code: Code2,
  architecture: Box,
  performance: Zap,
  security: Shield,
};

const typeColors: Record<string, string> = {
  code: "#7C3AED",
  architecture: "#0EA5E9",
  performance: "#10B981",
  security: "#F59E0B",
};

const priorityColors: Record<string, { bg: string; text: string }> = {
  high: { bg: "var(--error-dim)", text: "var(--error)" },
  medium: { bg: "var(--warning-dim)", text: "var(--warning)" },
  low: { bg: "rgba(59, 130, 246, 0.15)", text: "var(--info)" },
};

export default function Insights() {
  const [filterType, setFilterType] = useState<string>("");
  const { data: suggestions, refetch } = trpc.suggestions.list.useQuery(
    filterType ? { type: filterType as "code" | "architecture" | "performance" | "security" } : undefined
  );
  const { data: summary } = trpc.analytics.suggestionsSummary.useQuery();

  const applyMutation = trpc.suggestions.apply.useMutation({ onSuccess: () => refetch() });
  const dismissMutation = trpc.suggestions.dismiss.useMutation({ onSuccess: () => refetch() });

  // Radar chart data
  const radarData = [
    { metric: "Code Quality", value: 72 },
    { metric: "Performance", value: 65 },
    { metric: "Security", value: 80 },
    { metric: "Maintainability", value: 68 },
    { metric: "Test Coverage", value: 45 },
    { metric: "Documentation", value: 55 },
  ];

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "grid", gridTemplateColumns: "2fr 1fr", gridTemplateRows: "auto 1fr", gap: 1, overflow: "hidden" }}>
      {/* Summary bar */}
      <div className="dashboard-panel" style={{ gridColumn: "1 / -1", display: "flex", gap: 16, alignItems: "center" }}>
        <div style={{ display: "flex", gap: 12 }}>
          {[
            { label: "Total", value: summary?.total || 0, color: "var(--base-text-primary)" },
            { label: "Pending", value: summary?.pending || 0, color: "var(--warning)" },
            { label: "Applied", value: summary?.applied || 0, color: "var(--success)" },
            { label: "Dismissed", value: summary?.dismissed || 0, color: "var(--base-text-muted)" },
          ].map((s) => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: "1rem", fontWeight: 700, fontFamily: "var(--font-mono)", color: s.color }}>{s.value}</div>
              <div style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>{s.label}</div>
            </div>
          ))}
        </div>

        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          <Filter size={14} style={{ color: "var(--base-text-muted)" }} />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            style={{ padding: "4px 8px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem" }}
          >
            <option value="">All types</option>
            <option value="code">Code</option>
            <option value="architecture">Architecture</option>
            <option value="performance">Performance</option>
            <option value="security">Security</option>
          </select>
        </div>
      </div>

      {/* Suggestions Feed */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>AI Suggestions</h3>
        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
          {(suggestions || [])
            .filter((s) => s.status === "pending")
            .map((suggestion) => {
              const TypeIcon = typeIcons[suggestion.type] || Code2;
              const typeColor = typeColors[suggestion.type] || "#7C3AED";
              const priorityConfig = priorityColors[suggestion.priority] || priorityColors.medium;

              return (
                <div
                  key={suggestion.id}
                  style={{
                    padding: 12,
                    background: "var(--base-surface-elevated)",
                    borderRadius: 8,
                    border: "1px solid var(--base-border)",
                    transition: "all 300ms var(--ease-out-expo)",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <div style={{
                      width: 28, height: 28, borderRadius: 6,
                      background: `${typeColor}15`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      <TypeIcon size={14} style={{ color: typeColor }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "0.875rem", fontWeight: 600 }}>{suggestion.title}</div>
                    </div>
                    <span style={{
                      padding: "2px 8px", borderRadius: 20, fontSize: "0.6875rem", fontWeight: 500,
                      background: priorityConfig.bg, color: priorityConfig.text, textTransform: "uppercase",
                    }}>
                      {suggestion.priority}
                    </span>
                  </div>

                  <p style={{ fontSize: "0.8125rem", color: "var(--base-text-secondary)", margin: "0 0 8px", lineHeight: 1.5 }}>
                    {suggestion.description}
                  </p>

                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{
                      padding: "2px 8px", borderRadius: 20, fontSize: "0.6875rem",
                      background: `${typeColor}15`, color: typeColor, textTransform: "capitalize",
                    }}>
                      {suggestion.type}
                    </span>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button
                        onClick={() => applyMutation.mutate({ id: suggestion.id })}
                        className="btn-primary"
                        style={{ padding: "4px 10px", fontSize: "0.75rem", display: "flex", alignItems: "center", gap: 4 }}
                      >
                        <CheckCircle size={12} />
                        Apply
                      </button>
                      <button
                        onClick={() => dismissMutation.mutate({ id: suggestion.id })}
                        className="btn-secondary"
                        style={{ padding: "4px 10px", fontSize: "0.75rem", display: "flex", alignItems: "center", gap: 4 }}
                      >
                        <XCircle size={12} />
                        Dismiss
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

          {(suggestions || []).filter((s) => s.status === "pending").length === 0 && (
            <div style={{ textAlign: "center", padding: 40, color: "var(--base-text-muted)" }}>
              <CheckCircle size={32} style={{ marginBottom: 8, color: "var(--success)" }} />
              <div style={{ fontSize: "0.875rem" }}>All caught up! No pending suggestions.</div>
            </div>
          )}
        </div>
      </div>

      {/* Impact Analysis */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>Impact Analysis</h3>
        <div style={{ flex: 1, minHeight: 0 }}>
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
              <PolarGrid stroke="var(--base-border)" />
              <PolarAngleAxis
                dataKey="metric"
                tick={{ fill: "var(--base-text-secondary)", fontSize: 11 }}
              />
              <PolarRadiusAxis
                angle={90}
                domain={[0, 100]}
                tick={{ fill: "var(--base-text-muted)", fontSize: 10 }}
              />
              <Radar
                name="Current"
                dataKey="value"
                stroke="var(--brand-purple)"
                fill="var(--brand-purple)"
                fillOpacity={0.2}
                strokeWidth={2}
              />
              <Legend
                wrapperStyle={{ color: "var(--base-text-secondary)", fontSize: "0.75rem" }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
