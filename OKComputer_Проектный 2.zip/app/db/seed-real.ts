import { getDb } from "../api/queries/connection";
import {
  projects,
  apiEndpoints,
  apiLogs,
  codeFiles,
  milestones,
  milestoneTasks,
  suggestions,
  activityLog,
} from "./schema";
import { eq } from "drizzle-orm";

const db = getDb();

// ─── 8 Real Projects ───────────────────────────────────────

const projectData = [
  {
    name: "oilpodbor.ru (AutoMaslo)",
    description: "Сервис подбора моторного масла. Интеллектуальная система рекомендаций масел на основе марки авто, года, двигателя. Бэкенд на Hono + tRPC, фронтенд на React + Vite.",
    status: "active" as const,
    apiBaseUrl: "http://194.156.118.179",
    owner: "Internal",
    totalLoc: 28450,
    totalFiles: 312,
    lastDeployAt: new Date(Date.now() - 3 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 5 * 86400000),
  },
  {
    name: "maxnic.ru (LUKOIL B2B Shop)",
    description: "B2B магазин масел для дилеров и корпоративных клиентов. Каталог продукции, оптовые цены, система заказов. Статический сайт за nginx.",
    status: "active" as const,
    apiBaseUrl: "http://5.35.93.141",
    owner: "Internal",
    totalLoc: 12500,
    totalFiles: 89,
    lastDeployAt: new Date(Date.now() - 12 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 15 * 86400000),
  },
  {
    name: "fedin-ii.ru",
    description: "Образовательная платформа 'ChatGPT: от новичка до эксперта'. Курсы, уроки, интерактивные задания, система прогресса.",
    status: "active" as const,
    apiBaseUrl: "http://159.194.213.82",
    owner: "Internal",
    totalLoc: 34500,
    totalFiles: 278,
    lastDeployAt: new Date(Date.now() - 1 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 2 * 86400000),
  },
  {
    name: "grafic-rabota.ru",
    description: "График работы — управление расписанием сотрудников, смены, выходные, отпуска. Node.js + SQLite.",
    status: "active" as const,
    apiBaseUrl: "http://85.198.69.48",
    owner: "Internal",
    totalLoc: 18200,
    totalFiles: 156,
    lastDeployAt: new Date(Date.now() - 7 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 10 * 86400000),
  },
  {
    name: "b2b-technical.ru",
    description: "B2B техническая платформа. Supabase + React. Техническая документация, спецификации, интеграции.",
    status: "active" as const,
    apiBaseUrl: "http://85.198.69.48",
    owner: "Internal",
    totalLoc: 22300,
    totalFiles: 198,
    lastDeployAt: new Date(Date.now() - 4 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 6 * 86400000),
  },
  {
    name: "family-foto.ru",
    description: "Фото-сервис для семей. Загрузка, хранение, организация и печать фотографий. Сейчас offline.",
    status: "paused" as const,
    apiBaseUrl: "http://217.114.12.81",
    owner: "Internal",
    totalLoc: 15600,
    totalFiles: 134,
    lastDeployAt: new Date(Date.now() - 90 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 95 * 86400000),
  },
  {
    name: "callsystem-ai.ru",
    description: "AI call center / AI-тайный покупатель. Голосовой AI для обзвона, анализа разговоров, оценки качества. Hono + tRPC + Three.js визуализация.",
    status: "active" as const,
    apiBaseUrl: "http://85.198.69.48",
    owner: "Internal",
    totalLoc: 41200,
    totalFiles: 356,
    lastDeployAt: new Date(Date.now() - 2 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 3 * 86400000),
  },
  {
    name: "assistant-job.ru",
    description: "Помощник по подбору вакансий. AI-рекомендации на основе резюме, навыков, опыта. Парсинг вакансий с агрегаторов.",
    status: "active" as const,
    apiBaseUrl: "http://159.194.213.82",
    owner: "Internal",
    totalLoc: 26800,
    totalFiles: 231,
    lastDeployAt: new Date(Date.now() - 5 * 86400000),
    codeUpdatedAt: new Date(Date.now() - 8 * 86400000),
  },
];

// Endpoints per project
const endpointConfigs: Record<number, { path: string; method: "GET" | "POST" | "PUT" | "DELETE"; description: string }[]> = {
  0: [ // oilpodbor
    { path: "/api/oil/select", method: "POST", description: "Подбор масла по параметрам авто" },
    { path: "/api/oil/recommend", method: "GET", description: "Рекомендации масел" },
    { path: "/api/cars/makes", method: "GET", description: "Список марок авто" },
    { path: "/api/cars/models", method: "GET", description: "Модели по марке" },
    { path: "/api/cars/engines", method: "GET", description: "Двигатели по модели" },
    { path: "/api/orders/create", method: "POST", description: "Создание заказа" },
    { path: "/api/user/history", method: "GET", description: "История подборов" },
    { path: "/api/admin/catalog", method: "GET", description: "Управление каталогом" },
  ],
  1: [ // maxnic
    { path: "/api/products/list", method: "GET", description: "Каталог масел" },
    { path: "/api/products/detail", method: "GET", description: "Детали продукта" },
    { path: "/api/cart/add", method: "POST", description: "Добавить в корзину" },
    { path: "/api/cart/checkout", method: "POST", description: "Оформление заказа" },
    { path: "/api/b2b/prices", method: "GET", description: "Оптовые цены" },
    { path: "/api/b2b/orders", method: "GET", description: "История B2B заказов" },
  ],
  2: [ // fedin-ii
    { path: "/api/courses/list", method: "GET", description: "Список курсов" },
    { path: "/api/courses/enroll", method: "POST", description: "Запись на курс" },
    { path: "/api/lessons/progress", method: "GET", description: "Прогресс уроков" },
    { path: "/api/lessons/complete", method: "POST", description: "Отметить урок выполненным" },
    { path: "/api/gpt/ask", method: "POST", description: "Запрос к GPT-ассистенту" },
    { path: "/api/user/profile", method: "GET", description: "Профиль пользователя" },
    { path: "/api/payments/create", method: "POST", description: "Создание платежа" },
  ],
  3: [ // grafic-rabota
    { path: "/api/schedule/get", method: "GET", description: "Получить график" },
    { path: "/api/schedule/update", method: "PUT", description: "Обновить расписание" },
    { path: "/api/shifts/create", method: "POST", description: "Создать смену" },
    { path: "/api/shifts/list", method: "GET", description: "Список смен" },
    { path: "/api/vacation/request", method: "POST", description: "Запрос отпуска" },
    { path: "/api/employees/list", method: "GET", description: "Список сотрудников" },
  ],
  4: [ // b2b-technical
    { path: "/api/docs/list", method: "GET", description: "Список документов" },
    { path: "/api/docs/upload", method: "POST", description: "Загрузка документа" },
    { path: "/api/specs/get", method: "GET", description: "Технические спецификации" },
    { path: "/api/integrations/list", method: "GET", description: "Список интеграций" },
    { path: "/api/clients/list", method: "GET", description: "B2B клиенты" },
  ],
  5: [ // family-foto
    { path: "/api/photos/upload", method: "POST", description: "Загрузка фото" },
    { path: "/api/photos/albums", method: "GET", description: "Список альбомов" },
    { path: "/api/photos/list", method: "GET", description: "Фотографии в альбоме" },
    { path: "/api/print/order", method: "POST", description: "Заказ печати" },
    { path: "/api/share/create", method: "POST", description: "Создание ссылки на альбом" },
  ],
  6: [ // callsystem-ai
    { path: "/api/calls/initiate", method: "POST", description: "Инициация AI-звонка" },
    { path: "/api/calls/status", method: "GET", description: "Статус звонка" },
    { path: "/api/calls/history", method: "GET", description: "История звонков" },
    { path: "/api/ai/analyze", method: "POST", description: "Анализ разговора" },
    { path: "/api/ai/score", method: "GET", description: "Оценка качества" },
    { path: "/api/secret/shopper", method: "POST", description: "Запуск тайного покупателя" },
    { path: "/api/voice/synthesize", method: "POST", description: "Синтез речи" },
    { path: "/api/voice/recognize", method: "POST", description: "Распознавание речи" },
  ],
  7: [ // assistant-job
    { path: "/api/jobs/search", method: "GET", description: "Поиск вакансий" },
    { path: "/api/jobs/recommend", method: "POST", description: "AI-рекомендации" },
    { path: "/api/resume/parse", method: "POST", description: "Парсинг резюме" },
    { path: "/api/resume/upload", method: "POST", description: "Загрузка резюме" },
    { path: "/api/skills/analyze", method: "POST", description: "Анализ навыков" },
    { path: "/api/tracker/jobs", method: "GET", description: "Отслеживаемые вакансии" },
    { path: "/api/parsers/run", method: "POST", description: "Запуск парсеров" },
  ],
];

async function seed() {
  console.log("Clearing existing data...");

  // Delete in correct order (children first)
  const allProjects = await db.select().from(projects);
  for (const p of allProjects) {
    const eps = await db.select().from(apiEndpoints).where(eq(apiEndpoints.projectId, p.id));
    for (const ep of eps) {
      await db.delete(apiLogs).where(eq(apiLogs.endpointId, ep.id));
    }
    await db.delete(apiEndpoints).where(eq(apiEndpoints.projectId, p.id));
    await db.delete(codeFiles).where(eq(codeFiles.projectId, p.id));
    const mss = await db.select().from(milestones).where(eq(milestones.projectId, p.id));
    for (const ms of mss) {
      await db.delete(milestoneTasks).where(eq(milestoneTasks.milestoneId, ms.id));
    }
    await db.delete(milestones).where(eq(milestones.projectId, p.id));
    await db.delete(suggestions).where(eq(suggestions.projectId, p.id));
    await db.delete(activityLog).where(eq(activityLog.projectId, p.id));
  }
  await db.delete(projects);

  console.log("Inserting 8 real projects...");

  for (let i = 0; i < projectData.length; i++) {
    const pd = projectData[i];
    const [result] = await db.insert(projects).values(pd);
    const projectId = Number(result.insertId);
    console.log(`  Inserted: ${pd.name} (ID: ${projectId})`);

    // Insert endpoints
    const eps = endpointConfigs[i] || [];
    if (eps.length > 0) {
      const epsToInsert = eps.map((e) => ({
        projectId,
        path: e.path,
        method: e.method,
        description: e.description,
        isActive: pd.status === "active",
        expectedStatus: 200,
        timeoutMs: 5000,
      }));
      const insertedEps = await db.insert(apiEndpoints).values(epsToInsert);

      // Insert API logs for each endpoint
      for (let j = 0; j < epsToInsert.length; j++) {
        const epId = Number(insertedEps.insertId) + j;
        const isOnline = pd.status === "active";
        const logs = [];
        for (let d = 0; d < 5; d++) {
          const success = isOnline ? Math.random() > 0.1 : false;
          logs.push({
            endpointId: epId,
            statusCode: success ? 200 : isOnline ? [500, 502, 504][Math.floor(Math.random() * 3)] : 0,
            responseTimeMs: isOnline ? Math.floor(Math.random() * 400) + 50 : 0,
            success,
            errorMessage: success ? null : isOnline ? "Timeout" : "Host unreachable",
            checkedAt: new Date(Date.now() - d * 6 * 3600000),
          });
        }
        await db.insert(apiLogs).values(logs);
      }
    }

    // Insert code files
    const dirs = ["src", "src/components", "src/api", "src/utils", "tests", "config"];
    const allFiles = dirs.map((d) => ({
      projectId,
      path: d,
      name: d.split("/").pop()!,
      content: "",
      language: null as string | null,
      sizeBytes: 0,
      loc: 0,
      parentPath: d.includes("/") ? d.split("/")[0] : null,
      isDirectory: true,
    }));

    const langs = ["TypeScript", "JavaScript", "Python", "Go", "Rust"];
    const extMap: Record<string, string> = { TypeScript: "ts", JavaScript: "js", Python: "py", Go: "go", Rust: "rs" };
    const fileCount = 20 + Math.floor(Math.random() * 30);
    for (let f = 0; f < fileCount; f++) {
      const lang = langs[Math.floor(Math.random() * langs.length)];
      const dir = dirs[Math.floor(Math.random() * dirs.length)];
      const loc = 20 + Math.floor(Math.random() * 200);
      const ext = extMap[lang];
      allFiles.push({
        projectId,
        path: `${dir}/file_${f}.${ext}`,
        name: `file_${f}.${ext}`,
        content: `// ${pd.name} - module ${f}\n`,
        language: lang,
        sizeBytes: loc * 40,
        loc,
        parentPath: dir,
        isDirectory: false,
      });
    }
    await db.insert(codeFiles).values(allFiles);

    // Insert milestones
    const msTitles = ["Project Setup", "Core API", "Auth Integration", "DB Schema", "Performance", "Load Testing", "Documentation"];
    const msStatuses = ["completed", "completed", "completed", "in_progress", "planned", "planned", "planned"] as const;
    const msData = msTitles.map((title, mi) => ({
      projectId,
      title,
      description: `Milestone: ${title} for ${pd.name}`,
      status: msStatuses[mi],
      startDate: new Date(Date.now() - (30 - mi * 4) * 86400000).toISOString().split("T")[0],
      endDate: new Date(Date.now() - (20 - mi * 3) * 86400000).toISOString().split("T")[0],
      progressPercent: msStatuses[mi] === "completed" ? 100 : msStatuses[mi] === "in_progress" ? 75 : 0,
    }));
    await db.insert(milestones).values(msData);

    // Insert tasks for milestones
    const mss = await db.select().from(milestones).where(eq(milestones.projectId, projectId));
    for (const ms of mss) {
      const tc = 3 + Math.floor(Math.random() * 4);
      const tasks = [];
      for (let t = 0; t < tc; t++) {
        tasks.push({
          milestoneId: ms.id,
          title: `Task ${t + 1}: ${["Implement", "Test", "Review", "Deploy", "Document"][t % 5]}`,
          completed: Math.random() > 0.4,
        });
      }
      await db.insert(milestoneTasks).values(tasks);
    }

    // Insert suggestions
    const suggs = [
      { projectId, type: "performance" as const, title: "Enable connection pooling", description: "Improve DB connection handling for better throughput", priority: "high" as const, status: "pending" as const, impactMetrics: { performance: 25 } },
      { projectId, type: "security" as const, title: "Add rate limiting middleware", description: "Protect API endpoints from abuse", priority: "high" as const, status: "pending" as const, impactMetrics: { security: 20 } },
      { projectId, type: "code" as const, title: "Refactor error handling patterns", description: "Standardize error responses across all endpoints", priority: "medium" as const, status: Math.random() > 0.5 ? "pending" as const : "applied" as const, impactMetrics: { maintainability: 15 } },
      { projectId, type: "architecture" as const, title: "Implement circuit breaker", description: "Add resilience pattern for external service calls", priority: "medium" as const, status: "pending" as const, impactMetrics: { reliability: 20 } },
      { projectId, type: "performance" as const, title: "Add Redis caching layer", description: "Cache frequently accessed data to reduce DB load", priority: "medium" as const, status: "pending" as const, impactMetrics: { performance: 30 } },
      { projectId, type: "security" as const, title: "Audit npm dependencies", description: "Check for known vulnerabilities in dependencies", priority: "high" as const, status: Math.random() > 0.7 ? "applied" as const : "pending" as const, impactMetrics: { security: 35 } },
    ];
    await db.insert(suggestions).values(suggs);

    // Insert activities
    const acts = [
      { projectId, type: "code_upload" as const, description: `Code updated for ${pd.name}`, metadata: {} },
      { projectId, type: "api_check" as const, description: "API health check completed", metadata: {} },
      { projectId, type: "deploy" as const, description: `Deployed ${pd.name}`, metadata: {} },
      { projectId, type: "suggestion" as const, description: "New suggestion generated by AI", metadata: {} },
      { projectId, type: "milestone" as const, description: "Milestone progress updated", metadata: {} },
    ];
    await db.insert(activityLog).values(acts);
  }

  console.log("Seed complete! 8 projects loaded.");
}

seed().catch(console.error);
