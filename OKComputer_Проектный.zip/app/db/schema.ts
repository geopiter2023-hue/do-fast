import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  date,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users (Auth) ──────────────────────────────────────────

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Projects ──────────────────────────────────────────────

export const projects = mysqlTable("projects", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["active", "warning", "critical", "paused"])
    .default("active")
    .notNull(),
  apiBaseUrl: varchar("api_base_url", { length: 255 }),
  owner: varchar("owner", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  totalLoc: int("total_loc").default(0),
  totalFiles: int("total_files").default(0),
  lastDeployAt: timestamp("last_deploy_at"),
  codeUpdatedAt: timestamp("code_updated_at"),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

// ─── API Endpoints ─────────────────────────────────────────

export const apiEndpoints = mysqlTable("api_endpoints", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => projects.id),
  path: varchar("path", { length: 255 }).notNull(),
  method: mysqlEnum("method", ["GET", "POST", "PUT", "DELETE", "PATCH"]).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  expectedStatus: int("expected_status").default(200),
  timeoutMs: int("timeout_ms").default(5000),
});

export type ApiEndpoint = typeof apiEndpoints.$inferSelect;

// ─── API Logs ──────────────────────────────────────────────

export const apiLogs = mysqlTable("api_logs", {
  id: serial("id").primaryKey(),
  endpointId: bigint("endpoint_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => apiEndpoints.id),
  statusCode: int("status_code"),
  responseTimeMs: int("response_time_ms"),
  success: boolean("success").notNull(),
  errorMessage: text("error_message"),
  checkedAt: timestamp("checked_at").defaultNow(),
});

export type ApiLog = typeof apiLogs.$inferSelect;

// ─── Code Files ────────────────────────────────────────────

export const codeFiles = mysqlTable("code_files", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => projects.id),
  path: varchar("path", { length: 500 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  content: text("content"),
  language: varchar("language", { length: 50 }),
  sizeBytes: int("size_bytes").default(0),
  loc: int("loc").default(0),
  parentPath: varchar("parent_path", { length: 500 }),
  isDirectory: boolean("is_directory").default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type CodeFile = typeof codeFiles.$inferSelect;

// ─── Milestones ────────────────────────────────────────────

export const milestones = mysqlTable("milestones", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => projects.id),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["planned", "in_progress", "completed", "cancelled"])
    .default("planned")
    .notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  progressPercent: int("progress_percent").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type Milestone = typeof milestones.$inferSelect;

// ─── Milestone Tasks ───────────────────────────────────────

export const milestoneTasks = mysqlTable("milestone_tasks", {
  id: serial("id").primaryKey(),
  milestoneId: bigint("milestone_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => milestones.id),
  title: varchar("title", { length: 200 }).notNull(),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export type MilestoneTask = typeof milestoneTasks.$inferSelect;

// ─── Suggestions ───────────────────────────────────────────

export const suggestions = mysqlTable("suggestions", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => projects.id),
  type: mysqlEnum("type", ["code", "architecture", "performance", "security"]).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  priority: mysqlEnum("priority", ["high", "medium", "low"]).default("medium").notNull(),
  status: mysqlEnum("status", ["pending", "applied", "dismissed"]).default("pending").notNull(),
  impactMetrics: json("impact_metrics"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export type Suggestion = typeof suggestions.$inferSelect;

// ─── Activity Log ──────────────────────────────────────────

export const activityLog = mysqlTable("activity_log", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).references(
    () => projects.id
  ),
  type: mysqlEnum("type", [
    "code_upload",
    "api_check",
    "plan_update",
    "suggestion",
    "deploy",
    "milestone",
  ]).notNull(),
  description: text("description").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Activity = typeof activityLog.$inferSelect;

// ─── User Settings ─────────────────────────────────────────

export const userSettings = mysqlTable("user_settings", {
  id: serial("id").primaryKey(),
  apiTimeout: int("api_timeout").default(5000),
  apiRetryCount: int("api_retry_count").default(3),
  refreshIntervalSeconds: int("refresh_interval_seconds").default(30),
  emailNotifications: boolean("email_notifications").default(true),
  pushNotifications: boolean("push_notifications").default(false),
  webhookUrl: varchar("webhook_url", { length: 255 }),
  theme: mysqlEnum("theme", ["dark", "light"]).default("dark"),
});

export type UserSettings = typeof userSettings.$inferSelect;
