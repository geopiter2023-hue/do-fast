import { relations } from "drizzle-orm";
import {
  projects,
  apiEndpoints,
  apiLogs,
  codeFiles,
  milestones,
  milestoneTasks,
  suggestions,
  activityLog,
} from "./schema";

export const projectsRelations = relations(projects, ({ many }) => ({
  endpoints: many(apiEndpoints),
  codeFiles: many(codeFiles),
  milestones: many(milestones),
  suggestions: many(suggestions),
  activities: many(activityLog),
}));

export const apiEndpointsRelations = relations(apiEndpoints, ({ one, many }) => ({
  project: one(projects, {
    fields: [apiEndpoints.projectId],
    references: [projects.id],
  }),
  logs: many(apiLogs),
}));

export const apiLogsRelations = relations(apiLogs, ({ one }) => ({
  endpoint: one(apiEndpoints, {
    fields: [apiLogs.endpointId],
    references: [apiEndpoints.id],
  }),
}));

export const codeFilesRelations = relations(codeFiles, ({ one }) => ({
  project: one(projects, {
    fields: [codeFiles.projectId],
    references: [projects.id],
  }),
}));

export const milestonesRelations = relations(milestones, ({ one, many }) => ({
  project: one(projects, {
    fields: [milestones.projectId],
    references: [projects.id],
  }),
  tasks: many(milestoneTasks),
}));

export const milestoneTasksRelations = relations(milestoneTasks, ({ one }) => ({
  milestone: one(milestones, {
    fields: [milestoneTasks.milestoneId],
    references: [milestones.id],
  }),
}));

export const suggestionsRelations = relations(suggestions, ({ one }) => ({
  project: one(projects, {
    fields: [suggestions.projectId],
    references: [projects.id],
  }),
}));

export const activityLogRelations = relations(activityLog, ({ one }) => ({
  project: one(projects, {
    fields: [activityLog.projectId],
    references: [projects.id],
  }),
}));
