import { useEffect, useRef } from "react";
import { useLocation } from "react-router";

interface Point {
  x: number;
  y: number;
  z: number;
  baseX: number;
  baseY: number;
  baseZ: number;
}

interface ProjectedPoint {
  sx: number;
  sy: number;
  scale: number;
  visible: boolean;
}

function generateGrid(cols: number, rows: number): Point[] {
  const points: Point[] = [];
  const spacing = 60;
  const startX = -((cols - 1) * spacing) / 2;
  const startY = -((rows - 1) * spacing) / 2;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      points.push({
        x: startX + c * spacing,
        y: startY + r * spacing,
        z: 0,
        baseX: startX + c * spacing,
        baseY: startY + r * spacing,
        baseZ: 0,
      });
    }
  }
  return points;
}

function project(x: number, y: number, z: number, fov: number, cameraZ: number, cw: number, ch: number): ProjectedPoint {
  const scale = fov / (fov + z + cameraZ);
  return {
    sx: x * scale + cw / 2,
    sy: y * scale + ch / 2,
    scale,
    visible: scale > 0,
  };
}

function updateWavePoints(points: Point[], time: number) {
  const waveSpeed = 0.4;
  const waveFrequency = 0.008;
  const waveAmplitude = 60;
  const t = time * waveSpeed;

  points.forEach((p) => {
    const wave = Math.sin(p.baseX * waveFrequency + p.baseY * waveFrequency + t) * waveAmplitude;
    const wave2 = Math.cos(p.baseX * waveFrequency * 0.5 - t * 0.7) * waveAmplitude * 0.5;
    p.z = p.baseZ + wave + wave2;
  });
}

function applyMouseInfluence(
  points: Point[],
  mouseX: number,
  mouseY: number,
  mouseActive: boolean,
  canvasWidth: number,
  canvasHeight: number
) {
  if (!mouseActive) return;

  const centerX = canvasWidth / 2;
  const centerY = canvasHeight / 2;
  const mX = mouseX - centerX;
  const mY = mouseY - centerY;
  const mouseInfluenceRadius = 250;
  const mouseInfluenceStrength = 0.6;

  points.forEach((p) => {
    const dx = p.x - mX;
    const dy = p.y - mY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < mouseInfluenceRadius && dist > 0) {
      const force = (1 - dist / mouseInfluenceRadius) * mouseInfluenceStrength;
      p.z += force * 80;
      p.x += (dx / dist) * force * 20;
      p.y += (dy / dist) * force * 20;
    }
  });
}

function drawMatrix(
  ctx: CanvasRenderingContext2D,
  projected: ProjectedPoint[],
  cols: number,
  rows: number,
  canvasWidth: number,
  canvasHeight: number
) {
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  const dotColor = [124, 58, 237];
  const lineColor = [124, 58, 237];
  const connectDistance = 100;
  const dotSize = 2;

  // Connections first
  ctx.lineWidth = 0.5;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      const p = projected[i];
      if (!p || !p.visible) continue;

      // Right
      if (c < cols - 1) {
        const right = projected[i + 1];
        if (right && right.visible) {
          const dist = Math.abs(p.sx - right.sx) + Math.abs(p.sy - right.sy);
          if (dist < connectDistance * 2) {
            const alpha = Math.max(0, 1 - dist / (connectDistance * 3)) * 0.15;
            ctx.strokeStyle = `rgba(${lineColor[0]}, ${lineColor[1]}, ${lineColor[2]}, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(p.sx, p.sy);
            ctx.lineTo(right.sx, right.sy);
            ctx.stroke();
          }
        }
      }
      // Down
      if (r < rows - 1) {
        const down = projected[i + cols];
        if (down && down.visible) {
          const dist = Math.abs(p.sx - down.sx) + Math.abs(p.sy - down.sy);
          if (dist < connectDistance * 2) {
            const alpha = Math.max(0, 1 - dist / (connectDistance * 3)) * 0.15;
            ctx.strokeStyle = `rgba(${lineColor[0]}, ${lineColor[1]}, ${lineColor[2]}, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(p.sx, p.sy);
            ctx.lineTo(down.sx, down.sy);
            ctx.stroke();
          }
        }
      }
    }
  }

  // Dots
  for (let i = 0; i < projected.length; i++) {
    const p = projected[i];
    if (!p || !p.visible) continue;

    const size = dotSize * p.scale;
    const alpha = Math.min(1, p.scale * 1.5);

    ctx.fillStyle = `rgba(${dotColor[0]}, ${dotColor[1]}, ${dotColor[2]}, ${alpha})`;
    ctx.beginPath();
    ctx.arc(p.sx, p.sy, size, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function DepthMatrix() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, active: false });
  const location = useLocation();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio, 1.5);
    let cols = Math.floor((window.innerWidth - 64) / 60);
    let rows = Math.floor((window.innerHeight - 48) / 60);
    let points = generateGrid(cols, rows);
    let rotation = 0;
    let animationId = 0;

    function resize() {
      if (!canvas) return;
      canvas.width = (window.innerWidth - 64) * dpr;
      canvas.height = (window.innerHeight - 48) * dpr;
      ctx!.scale(dpr, dpr);

      cols = Math.floor((window.innerWidth - 64) / 60);
      rows = Math.floor((window.innerHeight - 48) / 60);
      points = generateGrid(cols, rows);
    }

    resize();

    function frame(timestamp: number) {
      const time = timestamp / 1000;
      const cw = window.innerWidth - 64;
      const ch = window.innerHeight - 48;

      // Reset
      points.forEach((p) => {
        p.x = p.baseX;
        p.y = p.baseY;
        p.z = p.baseZ;
      });

      // Auto rotation
      rotation += 0.003;
      const cosR = Math.cos(rotation);
      const sinR = Math.sin(rotation);

      // Wave
      updateWavePoints(points, time);

      // Rotation
      points.forEach((p) => {
        const rx = p.x * cosR - p.z * sinR;
        const rz = p.x * sinR + p.z * cosR;
        p.x = rx;
        p.z = rz;
      });

      // Mouse
      applyMouseInfluence(
        points,
        mouseRef.current.x,
        mouseRef.current.y,
        mouseRef.current.active,
        cw,
        ch
      );

      // Project
      const projected = points.map((p) =>
        project(p.x, p.y, p.z, 600, 800, cw, ch)
      );

      // Draw
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawMatrix(ctx!, projected, cols, rows, cw, ch);

      animationId = requestAnimationFrame(frame);
    }

    animationId = requestAnimationFrame(frame);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
      mouseRef.current.active = true;
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    const handleResize = () => resize();

    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Only show on dashboard
  const isDashboard = location.pathname === "/";

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        top: 48,
        left: 64,
        width: "calc(100vw - 64px)",
        height: "calc(100vh - 48px)",
        zIndex: 0,
        opacity: isDashboard ? 1 : 0,
        transition: "opacity 300ms ease",
        pointerEvents: isDashboard ? "auto" : "none",
      }}
    />
  );
}
