import { useLocation, useNavigate } from "react-router";
import {
  LayoutDashboard,
  FolderKanban,
  Code2,
  Activity,
  Route,
  Lightbulb,
  Settings,
  Bell,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useState, useEffect } from "react";

const navItems = [
  { icon: LayoutDashboard, path: "/", label: "Dashboard" },
  { icon: FolderKanban, path: "/projects", label: "Projects" },
  { icon: Code2, path: "/code", label: "Code" },
  { icon: Activity, path: "/systems", label: "Systems" },
  { icon: Route, path: "/roadmap", label: "Roadmap" },
  { icon: Lightbulb, path: "/insights", label: "Insights" },
  { icon: Settings, path: "/settings", label: "Settings" },
];

const pageTitles: Record<string, string> = {
  "/": "Dashboard",
  "/projects": "Projects",
  "/code": "Code Explorer",
  "/systems": "System Status",
  "/roadmap": "Development Roadmap",
  "/insights": "Insights",
  "/settings": "Settings",
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  trpc.analytics.overview.useQuery();

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <div
      style={{
        display: "flex",
        height: "100vh",
        width: "100vw",
        background: "var(--base-bg)",
        overflow: "hidden",
      }}
    >
      {/* Left Sidebar */}
      <nav
        style={{
          width: "var(--sidebar-width)",
          minWidth: "var(--sidebar-width)",
          height: "100vh",
          background: "var(--base-surface)",
          borderRight: "1px solid var(--base-border)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "16px 0",
          zIndex: 10,
          position: "relative",
        }}
      >
        {/* Logo */}
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            background: "linear-gradient(135deg, var(--brand-purple), var(--brand-azure))",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 24,
            fontWeight: 700,
            fontSize: 16,
            color: "white",
            cursor: "pointer",
          }}
          onClick={() => navigate("/")}
        >
          N
        </div>

        {/* Nav Items */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
          {navItems.map((item) => {
            const active = isActive(item.path);
            return (
              <div
                key={item.path}
                style={{ position: "relative" }}
                onMouseEnter={() => setHoveredNav(item.path)}
                onMouseLeave={() => setHoveredNav(null)}
              >
                <button
                  onClick={() => navigate(item.path)}
                  style={{
                    width: 48,
                    height: 48,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: 10,
                    border: "none",
                    background: active ? "var(--interactive-selected)" : "transparent",
                    color: active
                      ? "var(--brand-purple)"
                      : "var(--base-text-muted)",
                    cursor: "pointer",
                    transition: "all 200ms var(--ease-out-expo)",
                    position: "relative",
                    borderLeft: active
                      ? "2px solid var(--brand-purple)"
                      : "2px solid transparent",
                  }}
                >
                  <item.icon size={20} />
                </button>

                {/* Tooltip */}
                {hoveredNav === item.path && (
                  <div
                    style={{
                      position: "absolute",
                      left: "calc(100% + 12px)",
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: "var(--base-surface-elevated)",
                      border: "1px solid var(--base-border)",
                      borderRadius: 6,
                      padding: "4px 10px",
                      fontSize: 12,
                      color: "var(--base-text-primary)",
                      whiteSpace: "nowrap",
                      zIndex: 100,
                      boxShadow: "var(--panel-shadow)",
                      pointerEvents: "none",
                    }}
                  >
                    {item.label}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom */}
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <button
            style={{
              width: 48,
              height: 48,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: 10,
              border: "none",
              background: "transparent",
              color: "var(--base-text-muted)",
              cursor: "pointer",
              position: "relative",
            }}
          >
            <Bell size={20} />
            <span
              style={{
                position: "absolute",
                top: 8,
                right: 8,
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "var(--brand-purple)",
                border: "2px solid var(--base-surface)",
              }}
            />
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Top Bar */}
        <header
          style={{
            height: 48,
            minHeight: 48,
            background: "var(--base-surface)",
            borderBottom: "1px solid var(--base-border)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 20px",
            zIndex: 5,
          }}
        >
          {/* Breadcrumbs */}
          <div
            style={{
              fontSize: "0.8125rem",
              color: "var(--base-text-secondary)",
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <span style={{ color: "var(--base-text-muted)" }}>Nexus Core</span>
            <span style={{ color: "var(--base-text-muted)" }}>/</span>
            <span>{pageTitles[location.pathname] || "Dashboard"}</span>
          </div>

          {/* Right side */}
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            {/* API Status */}
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div
                className="pulse-indicator"
                style={{
                  width: 6,
                  height: 6,
                }}
              />
              <span style={{ fontSize: "0.75rem", color: "var(--base-text-secondary)" }}>
                API Online
              </span>
            </div>

            {/* Clock */}
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "0.8125rem",
                color: "var(--base-text-secondary)",
              }}
            >
              {currentTime.toLocaleTimeString("en-US", { hour12: false })}
            </span>

            {/* User Avatar */}
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "50%",
                background: "linear-gradient(135deg, var(--brand-purple), var(--brand-azure))",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 11,
                fontWeight: 600,
                color: "white",
              }}
            >
              A
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main
          style={{
            flex: 1,
            overflow: "auto",
            position: "relative",
          }}
        >
          {children}
        </main>
      </div>
    </div>
  );
}
