import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Search,
  FolderGit2,
  FileCode2,
  Activity,
  Route,
  ChevronRight,
} from "lucide-react";
import { useSearchParams } from "react-router";
import { formatDistanceToNow } from "date-fns";

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    active: "var(--success)",
    warning: "var(--warning)",
    critical: "var(--error)",
    paused: "var(--base-text-muted)",
  };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "2px 8px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 500,
      background: `${colors[status] || colors.paused}15`,
      color: colors[status] || colors.paused,
      textTransform: "capitalize",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: colors[status] || colors.paused }} />
      {status}
    </span>
  );
}

type TabType = "overview" | "code" | "api" | "plan";

export default function Projects() {
  const [searchParams] = useSearchParams();
  const preselectedId = searchParams.get("id");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(preselectedId ? Number(preselectedId) : null);
  const [activeTab, setActiveTab] = useState<TabType>("overview");

  const { data: projects, isLoading } = trpc.projects.list.useQuery({ search: search || undefined });
  const { data: selectedProject } = trpc.projects.getById.useQuery(
    { id: selectedId! },
    { enabled: !!selectedId }
  );

  const { data: endpointsWithStatus } = trpc.api.listEndpoints.useQuery(
    { projectId: selectedId! },
    { enabled: !!selectedId && activeTab === "api" }
  );

  const tabs: { key: TabType; label: string; icon: typeof FolderGit2 }[] = [
    { key: "overview", label: "Overview", icon: FolderGit2 },
    { key: "code", label: "Code", icon: FileCode2 },
    { key: "api", label: "API", icon: Activity },
    { key: "plan", label: "Plan", icon: Route },
  ];

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "grid", gridTemplateColumns: selectedId ? "1fr 1.5fr" : "1fr", gap: 1, overflow: "hidden" }}>
      {/* Project List */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: 0 }}>All Projects</h3>
          <span style={{ fontSize: "0.75rem", color: "var(--base-text-muted)" }}>{projects?.length || 0} projects</span>
        </div>

        <div style={{ position: "relative", marginBottom: 12 }}>
          <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--base-text-muted)" }} />
          <input
            type="text"
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: "100%",
              padding: "8px 10px 8px 32px",
              background: "var(--base-bg)",
              border: "1px solid var(--base-border)",
              borderRadius: "var(--button-radius)",
              color: "var(--base-text-primary)",
              fontSize: "0.8125rem",
              outline: "none",
              boxSizing: "border-box",
            }}
          />
        </div>

        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="skeleton-shimmer" style={{ height: 64, borderRadius: 8 }} />
            ))
          ) : (
            (projects || []).map((p) => (
              <div
                key={p.id}
                onClick={() => { setSelectedId(p.id); setActiveTab("overview"); }}
                style={{
                  padding: 12,
                  borderRadius: 8,
                  background: selectedId === p.id ? "var(--interactive-selected)" : "var(--base-surface-elevated)",
                  border: `1px solid ${selectedId === p.id ? "rgba(124, 58, 237, 0.3)" : "var(--base-border)"}`,
                  cursor: "pointer",
                  transition: "all 200ms var(--ease-out-expo)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <FolderGit2 size={16} style={{ color: "var(--brand-purple)" }} />
                    <span style={{ fontWeight: 600, fontSize: "0.875rem" }}>{p.name}</span>
                  </div>
                  <StatusBadge status={p.status} />
                </div>
                <p style={{ fontSize: "0.75rem", color: "var(--base-text-secondary)", margin: "0 0 6px", lineHeight: 1.4 }}>
                  {p.description}
                </p>
                <div style={{ display: "flex", gap: 12, fontSize: "0.6875rem", color: "var(--base-text-muted)", fontFamily: "var(--font-mono)" }}>
                  <span>{(p.totalLoc || 0).toLocaleString()} LOC</span>
                  <span>{p.totalFiles} files</span>
                  <span>{formatDistanceToNow(p.codeUpdatedAt ? new Date(p.codeUpdatedAt) : new Date(), { addSuffix: true })}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Project Detail */}
      {selectedId && selectedProject && (
        <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
          {/* Header */}
          <div style={{ marginBottom: 12, paddingBottom: 12, borderBottom: "1px solid var(--base-border)" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <h2 style={{ fontSize: "1.25rem", fontWeight: 700, margin: 0 }}>{selectedProject.name}</h2>
              <StatusBadge status={selectedProject.status} />
            </div>
            <p style={{ fontSize: "0.8125rem", color: "var(--base-text-secondary)", margin: "4px 0 0" }}>
              {selectedProject.description}
            </p>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 4, marginBottom: 12, borderBottom: "1px solid var(--base-border)", paddingBottom: 8 }}>
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "6px 12px",
                  borderRadius: 6,
                  border: "none",
                  background: activeTab === tab.key ? "var(--interactive-selected)" : "transparent",
                  color: activeTab === tab.key ? "var(--brand-purple)" : "var(--base-text-secondary)",
                  fontSize: "0.8125rem",
                  fontWeight: 500,
                  cursor: "pointer",
                  transition: "all 200ms",
                }}
              >
                <tab.icon size={14} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div style={{ flex: 1, overflow: "auto" }}>
            {activeTab === "overview" && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Owner</div>
                  <div style={{ fontSize: "0.875rem", fontWeight: 500 }}>{selectedProject.owner || "Unassigned"}</div>
                </div>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Base URL</div>
                  <div style={{ fontSize: "0.8125rem", fontFamily: "var(--font-mono)", color: "var(--base-text-secondary)" }}>{selectedProject.apiBaseUrl || "N/A"}</div>
                </div>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Total LOC</div>
                  <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{(selectedProject.totalLoc || 0).toLocaleString()}</div>
                </div>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Files</div>
                  <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{selectedProject.totalFiles || 0}</div>
                </div>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Endpoints</div>
                  <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{selectedProject.endpoints?.length || 0}</div>
                </div>
                <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, border: "1px solid var(--base-border)" }}>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Milestones</div>
                  <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{selectedProject.milestones?.length || 0}</div>
                </div>
              </div>
            )}

            {activeTab === "code" && (
              <div>
                {selectedProject.files?.filter((f) => f.isDirectory).map((dir) => (
                  <div key={dir.id} style={{ marginBottom: 8 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 8px", fontWeight: 600, fontSize: "0.8125rem", color: "var(--brand-purple)" }}>
                      <ChevronRight size={14} />
                      {dir.name}
                    </div>
                    <div style={{ paddingLeft: 20 }}>
                      {selectedProject.files?.filter((f) => f.parentPath === dir.path && !f.isDirectory).slice(0, 5).map((file) => (
                        <div key={file.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 8px", fontSize: "0.75rem", color: "var(--base-text-secondary)" }}>
                          <span>{file.name}</span>
                          <span style={{ fontFamily: "var(--font-mono)", color: "var(--base-text-muted)" }}>{file.loc} LOC</span>
                        </div>
                      ))}
                      {(selectedProject.files?.filter((f) => f.parentPath === dir.path && !f.isDirectory).length || 0) > 5 && (
                        <div style={{ padding: "4px 8px", fontSize: "0.6875rem", color: "var(--base-text-muted)", fontStyle: "italic" }}>
                          +{(selectedProject.files?.filter((f) => f.parentPath === dir.path && !f.isDirectory).length || 0) - 5} more files
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "api" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {(endpointsWithStatus || []).map((ep) => (
                  <div key={ep.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 10px", background: "var(--base-surface-elevated)", borderRadius: 6, border: "1px solid var(--base-border)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{
                        padding: "2px 6px", borderRadius: 4, fontSize: "0.625rem", fontWeight: 600, fontFamily: "var(--font-mono)",
                        background: ep.method === "GET" ? "rgba(16, 185, 129, 0.15)" : ep.method === "POST" ? "rgba(59, 130, 246, 0.15)" : ep.method === "DELETE" ? "rgba(239, 68, 68, 0.15)" : "rgba(245, 158, 11, 0.15)",
                        color: ep.method === "GET" ? "var(--success)" : ep.method === "POST" ? "var(--info)" : ep.method === "DELETE" ? "var(--error)" : "var(--warning)",
                      }}>
                        {ep.method}
                      </span>
                      <span style={{ fontSize: "0.8125rem", fontFamily: "var(--font-mono)" }}>{ep.path}</span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div className={`pulse-indicator ${ep.latestSuccess ? "" : "error"}`} style={{ background: ep.latestSuccess ? "var(--success)" : "var(--error)" }} />
                      <span style={{ fontSize: "0.75rem", fontFamily: "var(--font-mono)", color: ep.latestResponseTime && ep.latestResponseTime < 100 ? "var(--success)" : ep.latestResponseTime && ep.latestResponseTime < 500 ? "var(--warning)" : "var(--error)" }}>
                        {ep.latestResponseTime ? `${ep.latestResponseTime}ms` : "N/A"}
                      </span>
                      <span style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)" }}>{ep.uptime}%</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "plan" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {(selectedProject.milestones || []).map((ms) => (
                  <div key={ms.id} style={{ padding: 10, background: "var(--base-surface-elevated)", borderRadius: 8, border: "1px solid var(--base-border)" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: "0.875rem" }}>{ms.title}</span>
                      <span style={{
                        padding: "2px 8px", borderRadius: 20, fontSize: "0.6875rem", fontWeight: 500,
                        background: ms.status === "completed" ? "var(--success-dim)" : ms.status === "in_progress" ? "var(--info-dim)" : "rgba(90, 90, 122, 0.15)",
                        color: ms.status === "completed" ? "var(--success)" : ms.status === "in_progress" ? "var(--info)" : "var(--base-text-muted)",
                        textTransform: "capitalize",
                      }}>
                        {ms.status.replace("_", " ")}
                      </span>
                    </div>
                    <div style={{ width: "100%", height: 4, background: "var(--base-border)", borderRadius: 2, overflow: "hidden", marginBottom: 6 }}>
                      <div style={{
                        width: `${ms.progressPercent}%`,
                        height: "100%",
                        background: "linear-gradient(90deg, var(--brand-purple), var(--brand-azure))",
                        borderRadius: 2,
                        transition: "width 500ms var(--ease-out-expo)",
                      }} />
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.6875rem", color: "var(--base-text-muted)" }}>
                      <span>{ms.progressPercent}% complete</span>
                      <span>{ms.startDate ? new Date(ms.startDate).toISOString().split("T")[0] : "N/A"} - {ms.endDate ? new Date(ms.endDate).toISOString().split("T")[0] : "N/A"}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
