import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Plus,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  XCircle,
  Trash2,
} from "lucide-react";

const statusConfig: Record<string, { color: string; bg: string; icon: typeof Circle }> = {
  planned: { color: "var(--base-text-muted)", bg: "rgba(90, 90, 122, 0.15)", icon: Circle },
  in_progress: { color: "var(--brand-purple)", bg: "var(--interactive-selected)", icon: Clock },
  completed: { color: "var(--success)", bg: "var(--success-dim)", icon: CheckCircle2 },
  cancelled: { color: "var(--error)", bg: "var(--error-dim)", icon: XCircle },
};

export default function Roadmap() {
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [selectedMilestoneId, setSelectedMilestoneId] = useState<number | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newMilestone, setNewMilestone] = useState({ title: "", description: "", startDate: "", endDate: "" });

  const { data: projects } = trpc.projects.list.useQuery();
  const { data: milestones, refetch } = trpc.milestones.list.useQuery(
    { projectId: selectedProjectId! },
    { enabled: !!selectedProjectId }
  );
  const { data: tasks, refetch: refetchTasks } = trpc.tasks.list.useQuery(
    { milestoneId: selectedMilestoneId! },
    { enabled: !!selectedMilestoneId }
  );

  const createMilestone = trpc.milestones.create.useMutation({
    onSuccess: () => {
      setShowCreate(false);
      setNewMilestone({ title: "", description: "", startDate: "", endDate: "" });
      refetch();
    },
  });

  const deleteMilestone = trpc.milestones.delete.useMutation({
    onSuccess: () => {
      setSelectedMilestoneId(null);
      refetch();
    },
  });

  const toggleTask = trpc.tasks.toggle.useMutation({
    onSuccess: () => refetchTasks(),
  });

  const createTask = trpc.tasks.create.useMutation({
    onSuccess: () => refetchTasks(),
  });

  const [newTaskTitle, setNewTaskTitle] = useState("");

  const selectedMilestone = milestones?.find((m) => m.id === selectedMilestoneId);

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "grid", gridTemplateColumns: selectedMilestoneId ? "2fr 1fr" : "1fr", gap: 1, overflow: "hidden" }}>
      {/* Roadmap Timeline */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: 0 }}>Development Roadmap</h3>
            <select
              value={selectedProjectId || ""}
              onChange={(e) => {
                setSelectedProjectId(Number(e.target.value) || null);
                setSelectedMilestoneId(null);
              }}
              style={{ padding: "4px 8px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem" }}
            >
              <option value="">Select project</option>
              {(projects || []).map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
          {selectedProjectId && (
            <button className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8125rem" }} onClick={() => setShowCreate(true)}>
              <Plus size={14} />
              Add Milestone
            </button>
          )}
        </div>

        {showCreate && (
          <div style={{ background: "var(--base-surface-elevated)", borderRadius: 8, padding: 12, marginBottom: 12, border: "1px solid var(--base-border)" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 8 }}>
              <input
                placeholder="Title"
                value={newMilestone.title}
                onChange={(e) => setNewMilestone((p) => ({ ...p, title: e.target.value }))}
                style={{ padding: "6px 10px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem", outline: "none" }}
              />
              <input
                placeholder="Description"
                value={newMilestone.description}
                onChange={(e) => setNewMilestone((p) => ({ ...p, description: e.target.value }))}
                style={{ padding: "6px 10px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem", outline: "none" }}
              />
              <input
                type="date"
                value={newMilestone.startDate}
                onChange={(e) => setNewMilestone((p) => ({ ...p, startDate: e.target.value }))}
                style={{ padding: "6px 10px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem", outline: "none" }}
              />
              <input
                type="date"
                value={newMilestone.endDate}
                onChange={(e) => setNewMilestone((p) => ({ ...p, endDate: e.target.value }))}
                style={{ padding: "6px 10px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem", outline: "none" }}
              />
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn-primary" style={{ fontSize: "0.75rem" }} onClick={() => createMilestone.mutate({ projectId: selectedProjectId!, ...newMilestone })}>Create</button>
              <button className="btn-secondary" style={{ fontSize: "0.75rem" }} onClick={() => setShowCreate(false)}>Cancel</button>
            </div>
          </div>
        )}

        <div style={{ flex: 1, overflow: "auto" }}>
          {selectedProjectId ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {/* Timeline bar */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 0", borderBottom: "1px solid var(--base-border)", marginBottom: 4 }}>
                <div style={{ width: 2, height: 20, background: "var(--brand-azure)", borderRadius: 1, animation: "timelinePulse 2s ease-in-out infinite" }} />
                <span style={{ fontSize: "0.6875rem", color: "var(--brand-azure)", fontFamily: "var(--font-mono)" }}>
                  {new Date().toISOString().split("T")[0]} (Today)
                </span>
              </div>

              {/* Milestones */}
              {(milestones || []).map((ms) => {
                const config = statusConfig[ms.status] || statusConfig.planned;
                const Icon = config.icon;
                return (
                  <div
                    key={ms.id}
                    onClick={() => setSelectedMilestoneId(ms.id)}
                    style={{
                      padding: 12,
                      background: selectedMilestoneId === ms.id ? "var(--interactive-selected)" : "var(--base-surface-elevated)",
                      borderRadius: 8,
                      border: `1px solid ${selectedMilestoneId === ms.id ? "rgba(124, 58, 237, 0.3)" : "var(--base-border)"}`,
                      cursor: "pointer",
                      transition: "all 200ms",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <Icon size={16} style={{ color: config.color }} />
                        <span style={{ fontWeight: 600, fontSize: "0.875rem" }}>{ms.title}</span>
                      </div>
                      <span style={{
                        padding: "2px 8px", borderRadius: 20, fontSize: "0.6875rem", fontWeight: 500,
                        background: config.bg, color: config.color, textTransform: "capitalize",
                      }}>
                        {ms.status.replace("_", " ")}
                      </span>
                    </div>

                    <div style={{ width: "100%", height: 6, background: "var(--base-border)", borderRadius: 3, overflow: "hidden", marginBottom: 6 }}>
                      <div style={{
                        width: `${ms.progressPercent}%`,
                        height: "100%",
                        background: `linear-gradient(90deg, ${config.color}, ${config.color}aa)`,
                        borderRadius: 3,
                        transition: "width 500ms var(--ease-out-expo)",
                      }} />
                    </div>

                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.6875rem", color: "var(--base-text-muted)" }}>
                      <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                        <Calendar size={10} />
                        {ms.startDate ? new Date(ms.startDate).toISOString().split("T")[0] : "N/A"} - {ms.endDate ? new Date(ms.endDate).toISOString().split("T")[0] : "N/A"}
                      </span>
                      <span>{ms.taskCount || 0} tasks ({ms.completedTasks || 0} done)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: 40, color: "var(--base-text-muted)" }}>
              <Calendar size={32} style={{ marginBottom: 8, opacity: 0.5 }} />
              <div style={{ fontSize: "0.875rem" }}>Select a project to view roadmap</div>
            </div>
          )}
        </div>
      </div>

      {/* Milestone Detail */}
      {selectedMilestoneId && selectedMilestone && (
        <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12, paddingBottom: 12, borderBottom: "1px solid var(--base-border)" }}>
            <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: 0 }}>{selectedMilestone.title}</h3>
            <button onClick={() => deleteMilestone.mutate({ id: selectedMilestoneId })} style={{ background: "none", border: "none", color: "var(--error)", cursor: "pointer", padding: 4 }}>
              <Trash2 size={14} />
            </button>
          </div>

          <div style={{ fontSize: "0.8125rem", color: "var(--base-text-secondary)", marginBottom: 12 }}>
            {selectedMilestone.description}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
            <div style={{ background: "var(--base-surface-elevated)", borderRadius: 6, padding: 8, border: "1px solid var(--base-border)" }}>
              <div style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Start</div>
              <div style={{ fontSize: "0.75rem", fontFamily: "var(--font-mono)" }}>{selectedMilestone.startDate ? new Date(selectedMilestone.startDate).toISOString().split("T")[0] : "N/A"}</div>
            </div>
            <div style={{ background: "var(--base-surface-elevated)", borderRadius: 6, padding: 8, border: "1px solid var(--base-border)" }}>
              <div style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>End</div>
              <div style={{ fontSize: "0.75rem", fontFamily: "var(--font-mono)" }}>{selectedMilestone.endDate ? new Date(selectedMilestone.endDate).toISOString().split("T")[0] : "N/A"}</div>
            </div>
          </div>

          {/* Tasks */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8 }}>
              Tasks ({selectedMilestone.completedTasks || 0}/{selectedMilestone.taskCount || 0})
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 8 }}>
              {(tasks || []).map((task) => (
                <div
                  key={task.id}
                  onClick={() => toggleTask.mutate({ id: task.id })}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    padding: "6px 8px",
                    borderRadius: 6,
                    cursor: "pointer",
                    background: "var(--base-surface-elevated)",
                    transition: "all 100ms",
                  }}
                >
                  {task.completed ? (
                    <CheckCircle2 size={14} style={{ color: "var(--success)", flexShrink: 0 }} />
                  ) : (
                    <Circle size={14} style={{ color: "var(--base-text-muted)", flexShrink: 0 }} />
                  )}
                  <span style={{
                    fontSize: "0.8125rem",
                    textDecoration: task.completed ? "line-through" : "none",
                    color: task.completed ? "var(--base-text-muted)" : "var(--base-text-primary)",
                  }}>
                    {task.title}
                  </span>
                </div>
              ))}
            </div>

            {/* Add task */}
            <div style={{ display: "flex", gap: 6 }}>
              <input
                placeholder="New task..."
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && newTaskTitle.trim()) {
                    createTask.mutate({ milestoneId: selectedMilestoneId, title: newTaskTitle.trim() });
                    setNewTaskTitle("");
                  }
                }}
                style={{
                  flex: 1,
                  padding: "5px 8px",
                  background: "var(--base-bg)",
                  border: "1px solid var(--base-border)",
                  borderRadius: 6,
                  color: "var(--base-text-primary)",
                  fontSize: "0.75rem",
                  outline: "none",
                }}
              />
              <button
                onClick={() => {
                  if (newTaskTitle.trim()) {
                    createTask.mutate({ milestoneId: selectedMilestoneId, title: newTaskTitle.trim() });
                    setNewTaskTitle("");
                  }
                }}
                className="btn-primary"
                style={{ padding: "5px 10px", fontSize: "0.75rem" }}
              >
                <Plus size={12} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
