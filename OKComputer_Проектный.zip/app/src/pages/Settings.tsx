import { useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { Save, Download, RefreshCw } from "lucide-react";

export default function Settings() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const updateMutation = trpc.settings.update.useMutation();
  const utils = trpc.useUtils();

  const [form, setForm] = useState({
    apiTimeout: 5000,
    apiRetryCount: 3,
    refreshIntervalSeconds: 30,
    emailNotifications: true,
    pushNotifications: false,
    webhookUrl: "",
    theme: "dark" as "dark" | "light",
  });

  useEffect(() => {
    if (settings) {
      setForm({
        apiTimeout: settings.apiTimeout || 5000,
        apiRetryCount: settings.apiRetryCount || 3,
        refreshIntervalSeconds: settings.refreshIntervalSeconds || 30,
        emailNotifications: settings.emailNotifications ?? true,
        pushNotifications: settings.pushNotifications ?? false,
        webhookUrl: settings.webhookUrl || "",
        theme: (settings.theme as "dark" | "light") || "dark",
      });
    }
  }, [settings]);

  const handleSave = () => {
    updateMutation.mutate(
      { ...form, webhookUrl: form.webhookUrl || null },
      {
        onSuccess: () => {
          utils.settings.get.invalidate();
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="skeleton-shimmer" style={{ width: 400, height: 300, borderRadius: 12 }} />
      </div>
    );
  }

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "flex", alignItems: "flex-start", justifyContent: "center", overflow: "auto" }}>
      <div className="dashboard-panel" style={{ width: "100%", maxWidth: 640 }}>
        <h2 style={{ fontSize: "1.25rem", fontWeight: 700, margin: "0 0 20px" }}>Settings</h2>

        {/* API Configuration */}
        <div style={{ marginBottom: 24 }}>
          <h3 style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--brand-purple)", margin: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            API Configuration
          </h3>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div>
              <label style={{ display: "block", fontSize: "0.75rem", color: "var(--base-text-muted)", marginBottom: 4, textTransform: "uppercase" }}>
                API Timeout (ms)
              </label>
              <input
                type="number"
                value={form.apiTimeout}
                onChange={(e) => setForm((p) => ({ ...p, apiTimeout: Number(e.target.value) }))}
                min={1000}
                max={30000}
                step={500}
                style={{
                  width: "100%",
                  padding: "8px 12px",
                  background: "var(--base-bg)",
                  border: "1px solid var(--base-border)",
                  borderRadius: "var(--button-radius)",
                  color: "var(--base-text-primary)",
                  fontSize: "0.875rem",
                  fontFamily: "var(--font-mono)",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.75rem", color: "var(--base-text-muted)", marginBottom: 4, textTransform: "uppercase" }}>
                Retry Count
              </label>
              <input
                type="number"
                value={form.apiRetryCount}
                onChange={(e) => setForm((p) => ({ ...p, apiRetryCount: Number(e.target.value) }))}
                min={0}
                max={10}
                style={{
                  width: "100%",
                  padding: "8px 12px",
                  background: "var(--base-bg)",
                  border: "1px solid var(--base-border)",
                  borderRadius: "var(--button-radius)",
                  color: "var(--base-text-primary)",
                  fontSize: "0.875rem",
                  fontFamily: "var(--font-mono)",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.75rem", color: "var(--base-text-muted)", marginBottom: 4, textTransform: "uppercase" }}>
                Refresh Interval (seconds)
              </label>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <input
                  type="range"
                  value={form.refreshIntervalSeconds}
                  onChange={(e) => setForm((p) => ({ ...p, refreshIntervalSeconds: Number(e.target.value) }))}
                  min={10}
                  max={300}
                  step={10}
                  style={{ flex: 1 }}
                />
                <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.875rem", minWidth: 50 }}>
                  {form.refreshIntervalSeconds}s
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div style={{ marginBottom: 24, paddingTop: 20, borderTop: "1px solid var(--base-border)" }}>
          <h3 style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--brand-purple)", margin: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            Notifications
          </h3>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <ToggleRow
              label="Email Notifications"
              description="Receive email alerts for critical system events"
              checked={form.emailNotifications}
              onChange={(v) => setForm((p) => ({ ...p, emailNotifications: v }))}
            />
            <ToggleRow
              label="Push Notifications"
              description="Receive browser push notifications"
              checked={form.pushNotifications}
              onChange={(v) => setForm((p) => ({ ...p, pushNotifications: v }))}
            />

            <div>
              <label style={{ display: "block", fontSize: "0.75rem", color: "var(--base-text-muted)", marginBottom: 4, textTransform: "uppercase" }}>
                Webhook URL
              </label>
              <input
                type="url"
                value={form.webhookUrl}
                onChange={(e) => setForm((p) => ({ ...p, webhookUrl: e.target.value }))}
                placeholder="https://hooks.example.com/nexus"
                style={{
                  width: "100%",
                  padding: "8px 12px",
                  background: "var(--base-bg)",
                  border: "1px solid var(--base-border)",
                  borderRadius: "var(--button-radius)",
                  color: "var(--base-text-primary)",
                  fontSize: "0.875rem",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>
          </div>
        </div>

        {/* Theme */}
        <div style={{ marginBottom: 24, paddingTop: 20, borderTop: "1px solid var(--base-border)" }}>
          <h3 style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--brand-purple)", margin: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            Appearance
          </h3>
          <div style={{ display: "flex", gap: 8 }}>
            {(["dark", "light"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setForm((p) => ({ ...p, theme: t }))}
                style={{
                  flex: 1,
                  padding: "10px",
                  borderRadius: "var(--button-radius)",
                  border: `1px solid ${form.theme === t ? "var(--brand-purple)" : "var(--base-border)"}`,
                  background: form.theme === t ? "var(--interactive-selected)" : "var(--base-bg)",
                  color: form.theme === t ? "var(--brand-purple)" : "var(--base-text-secondary)",
                  fontSize: "0.8125rem",
                  fontWeight: 500,
                  cursor: "pointer",
                  textTransform: "capitalize",
                  transition: "all 200ms",
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: "flex", gap: 8, paddingTop: 16, borderTop: "1px solid var(--base-border)" }}>
          <button onClick={handleSave} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <Save size={14} />
            Save Changes
          </button>
          <button className="btn-secondary" style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <RefreshCw size={14} />
            Reset
          </button>
          <button className="btn-secondary" style={{ display: "flex", alignItems: "center", gap: 6, marginLeft: "auto" }}>
            <Download size={14} />
            Export Data
          </button>
        </div>

        {updateMutation.isSuccess && (
          <div style={{
            marginTop: 12,
            padding: "8px 12px",
            background: "var(--success-dim)",
            borderRadius: "var(--button-radius)",
            color: "var(--success)",
            fontSize: "0.8125rem",
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}>
            <Save size={14} />
            Settings saved successfully
          </div>
        )}
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div>
        <div style={{ fontSize: "0.875rem", fontWeight: 500 }}>{label}</div>
        <div style={{ fontSize: "0.75rem", color: "var(--base-text-muted)" }}>{description}</div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        style={{
          width: 40,
          height: 22,
          borderRadius: 11,
          border: "none",
          background: checked
            ? "linear-gradient(135deg, var(--brand-purple), var(--brand-azure))"
            : "var(--base-border)",
          cursor: "pointer",
          position: "relative",
          transition: "all 200ms",
        }}
      >
        <div
          style={{
            width: 16,
            height: 16,
            borderRadius: "50%",
            background: "white",
            position: "absolute",
            top: 3,
            left: checked ? 21 : 3,
            transition: "left 200ms var(--ease-spring)",
          }}
        />
      </button>
    </div>
  );
}
