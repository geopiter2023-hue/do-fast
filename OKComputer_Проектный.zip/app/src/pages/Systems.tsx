import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { RefreshCw, Play, AlertTriangle, AlertCircle, CheckCircle } from "lucide-react";

export default function Systems() {
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const { data: projects } = trpc.projects.list.useQuery();
  const { data: endpoints, refetch } = trpc.api.listEndpoints.useQuery(
    { projectId: selectedProjectId! },
    { enabled: !!selectedProjectId }
  );
  const { data: errorLog } = trpc.api.getErrorLog.useQuery(
    selectedProjectId ? { projectId: selectedProjectId } : undefined
  );

  const checkEndpoint = trpc.api.checkEndpoint.useMutation({
    onSuccess: () => refetch(),
  });

  const checkAll = trpc.api.checkAll.useMutation({
    onSuccess: () => refetch(),
  });

  const totalEndpoints = endpoints?.length || 0;
  const healthyEndpoints = endpoints?.filter((e) => e.latestSuccess).length || 0;
  const avgResponseTime = endpoints?.length
    ? Math.round(
        endpoints.reduce((sum, e) => sum + (e.latestResponseTime || 0), 0) / endpoints.length
      )
    : 0;

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "grid", gridTemplateColumns: "2fr 1fr", gridTemplateRows: "auto 1fr", gap: 1, overflow: "hidden" }}>
      {/* Top Stats */}
      <div className="dashboard-panel" style={{ gridColumn: "1 / -1", display: "flex", gap: 16, alignItems: "center", marginBottom: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: "0.8125rem", color: "var(--base-text-secondary)" }}>Project:</span>
          <select
            value={selectedProjectId || ""}
            onChange={(e) => setSelectedProjectId(Number(e.target.value) || null)}
            style={{ padding: "4px 8px", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 6, color: "var(--base-text-primary)", fontSize: "0.8125rem" }}
          >
            <option value="">Select project</option>
            {(projects || []).map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        <div style={{ display: "flex", gap: 16, flex: 1 }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Endpoints</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{totalEndpoints}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Healthy</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)", color: "var(--success)" }}>{healthyEndpoints}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Avg Response</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>{avgResponseTime}ms</div>
          </div>
        </div>

        <button
          className="btn-primary"
          onClick={() => selectedProjectId && checkAll.mutate({ projectId: selectedProjectId })}
          disabled={!selectedProjectId || checkAll.isPending}
          style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.8125rem" }}
        >
          <RefreshCw size={14} style={{ animation: checkAll.isPending ? "spin 1s linear infinite" : "none" }} />
          Refresh All
        </button>
      </div>

      {/* API Status Table */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>API Status</h3>
        <div style={{ flex: 1, overflow: "auto" }}>
          {selectedProjectId ? (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.8125rem" }}>
              <thead>
                <tr style={{ color: "var(--base-text-muted)", fontSize: "0.6875rem", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  <th style={{ textAlign: "left", padding: "6px 8px" }}>Endpoint</th>
                  <th style={{ textAlign: "left", padding: "6px 8px" }}>Method</th>
                  <th style={{ textAlign: "left", padding: "6px 8px" }}>Status</th>
                  <th style={{ textAlign: "left", padding: "6px 8px" }}>Response</th>
                  <th style={{ textAlign: "left", padding: "6px 8px" }}>Uptime</th>
                  <th style={{ textAlign: "center", padding: "6px 8px" }}>Test</th>
                </tr>
              </thead>
              <tbody>
                {(endpoints || []).map((ep) => (
                  <tr key={ep.id} style={{ borderBottom: "1px solid rgba(42, 42, 69, 0.3)" }}>
                    <td style={{ padding: "8px", fontFamily: "var(--font-mono)", fontSize: "0.75rem" }}>{ep.path}</td>
                    <td style={{ padding: "8px" }}>
                      <span style={{
                        padding: "2px 6px", borderRadius: 4, fontSize: "0.625rem", fontWeight: 600, fontFamily: "var(--font-mono)",
                        background: ep.method === "GET" ? "var(--success-dim)" : ep.method === "POST" ? "var(--info-dim)" : ep.method === "DELETE" ? "var(--error-dim)" : "var(--warning-dim)",
                        color: ep.method === "GET" ? "var(--success)" : ep.method === "POST" ? "var(--info)" : ep.method === "DELETE" ? "var(--error)" : "var(--warning)",
                      }}>
                        {ep.method}
                      </span>
                    </td>
                    <td style={{ padding: "8px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div className={`pulse-indicator ${ep.latestSuccess ? "" : "error"}`} style={{ background: ep.latestSuccess ? "var(--success)" : "var(--error)" }} />
                        <span style={{ fontSize: "0.75rem", color: ep.latestSuccess ? "var(--success)" : "var(--error)" }}>
                          {ep.latestSuccess ? `${ep.latestStatusCode || 200} OK` : "Failed"}
                        </span>
                      </div>
                    </td>
                    <td style={{ padding: "8px", fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: (ep.latestResponseTime || 0) < 100 ? "var(--success)" : (ep.latestResponseTime || 0) < 500 ? "var(--warning)" : "var(--error)" }}>
                      {ep.latestResponseTime ? `${ep.latestResponseTime}ms` : "N/A"}
                    </td>
                    <td style={{ padding: "8px", fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: "var(--base-text-secondary)" }}>
                      {ep.uptime}%
                    </td>
                    <td style={{ padding: "8px", textAlign: "center" }}>
                      <button
                        onClick={() => checkEndpoint.mutate({ endpointId: ep.id })}
                        disabled={checkEndpoint.isPending}
                        style={{ padding: "3px 8px", fontSize: "0.6875rem", background: "var(--base-bg)", border: "1px solid var(--base-border)", borderRadius: 4, color: "var(--base-text-primary)", cursor: "pointer" }}
                      >
                        <Play size={10} style={{ display: "inline", marginRight: 2 }} />
                        Test
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div style={{ textAlign: "center", padding: 40, color: "var(--base-text-muted)" }}>
              Select a project to view API status
            </div>
          )}
        </div>
      </div>

      {/* Error Log */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px", display: "flex", alignItems: "center", gap: 6 }}>
          <AlertTriangle size={16} style={{ color: "var(--warning)" }} />
          Recent Errors
        </h3>
        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
          {(errorLog || []).length === 0 ? (
            <div style={{ textAlign: "center", padding: 20, color: "var(--base-text-muted)" }}>
              <CheckCircle size={24} style={{ marginBottom: 6, color: "var(--success)" }} />
              <div style={{ fontSize: "0.8125rem" }}>No errors found</div>
            </div>
          ) : (
            (errorLog || []).slice(0, 10).map((log) => {
              const severity = log.statusCode && log.statusCode >= 500 ? "critical" : "warning";
              return (
                <div key={log.id} style={{ padding: 8, background: "var(--base-surface-elevated)", borderRadius: 6, border: "1px solid var(--base-border)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                    {severity === "critical" ? (
                      <AlertCircle size={12} style={{ color: "var(--error)", flexShrink: 0 }} />
                    ) : (
                      <AlertTriangle size={12} style={{ color: "var(--warning)", flexShrink: 0 }} />
                    )}
                    <span style={{ fontSize: "0.75rem", fontWeight: 600, fontFamily: "var(--font-mono)", color: severity === "critical" ? "var(--error)" : "var(--warning)" }}>
                      {log.statusCode || "ERR"}
                    </span>
                    <span style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", marginLeft: "auto" }}>
                      {log.checkedAt ? new Date(log.checkedAt).toLocaleTimeString() : ""}
                    </span>
                  </div>
                  <div style={{ fontSize: "0.75rem", color: "var(--base-text-secondary)" }}>
                    {log.errorMessage || "Request failed"}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
