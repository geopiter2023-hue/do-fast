import { trpc } from "@/providers/trpc";
import { useNavigate } from "react-router";
import {
  Upload,
  Activity,
  FileText,
  Lightbulb,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { formatDistanceToNow } from "date-fns";

const COLORS = ["#7C3AED", "#0EA5E9", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"];

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    active: "var(--success)",
    warning: "var(--warning)",
    critical: "var(--error)",
    paused: "var(--base-text-muted)",
  };
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        padding: "2px 8px",
        borderRadius: 20,
        fontSize: "0.75rem",
        fontWeight: 500,
        background: `${colors[status] || colors.paused}15`,
        color: colors[status] || colors.paused,
        textTransform: "capitalize",
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: colors[status] || colors.paused }} />
      {status}
    </span>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { data: projects, isLoading: projectsLoading } = trpc.projects.list.useQuery();
  const { data: analytics } = trpc.analytics.overview.useQuery();
  const { data: langDist } = trpc.analytics.languageDistribution.useQuery();
  const { data: activities } = trpc.activity.list.useQuery({ limit: 8 });

  const quickActions = [
    { label: "Upload Code", icon: Upload, path: "/code", color: "var(--brand-purple)" },
    { label: "Check API Status", icon: Activity, path: "/systems", color: "var(--brand-azure)" },
    { label: "Update Plan", icon: FileText, path: "/roadmap", color: "var(--success)" },
    { label: "View Insights", icon: Lightbulb, path: "/insights", color: "var(--warning)" },
  ];

  return (
    <div
      style={{
        padding: 16,
        height: "calc(100vh - 48px)",
        display: "grid",
        gridTemplateColumns: "2fr 1fr",
        gridTemplateRows: "1fr 1fr",
        gap: 1,
        overflow: "hidden",
      }}
    >
      {/* Project Status */}
      <div className="dashboard-panel panel-animated panel-delay-1" style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div>
            <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: 0 }}>Project Status</h3>
            <p style={{ fontSize: "0.75rem", color: "var(--base-text-secondary)", margin: "2px 0 0" }}>
              {analytics?.totalProjects || 0} active projects
            </p>
          </div>
          <button className="btn-secondary" style={{ fontSize: "0.75rem", padding: "4px 10px" }} onClick={() => navigate("/projects")}>
            View All
          </button>
        </div>

        <div style={{ flex: 1, overflow: "auto" }}>
          {projectsLoading ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton-shimmer" style={{ height: 36, borderRadius: 6 }} />
              ))}
            </div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.8125rem" }}>
              <thead>
                <tr style={{ color: "var(--base-text-muted)", fontSize: "0.6875rem", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  <th style={{ textAlign: "left", padding: "6px 8px", fontWeight: 500 }}>Project</th>
                  <th style={{ textAlign: "left", padding: "6px 8px", fontWeight: 500 }}>Status</th>
                  <th style={{ textAlign: "left", padding: "6px 8px", fontWeight: 500 }}>API Health</th>
                  <th style={{ textAlign: "left", padding: "6px 8px", fontWeight: 500 }}>Last Deploy</th>
                  <th style={{ textAlign: "left", padding: "6px 8px", fontWeight: 500 }}>Code Age</th>
                </tr>
              </thead>
              <tbody>
                {(projects || []).slice(0, 8).map((p) => (
                  <tr
                    key={p.id}
                    className="hover-glow"
                    style={{
                      borderBottom: "1px solid rgba(42, 42, 69, 0.3)",
                      cursor: "pointer",
                      transition: "all 200ms",
                    }}
                    onClick={() => navigate(`/projects?id=${p.id}`)}
                  >
                    <td style={{ padding: "8px", fontWeight: 500 }}>{p.name}</td>
                    <td style={{ padding: "8px" }}><StatusBadge status={p.status} /></td>
                    <td style={{ padding: "8px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div style={{ width: 60, height: 4, background: "var(--base-border)", borderRadius: 2, overflow: "hidden" }}>
                          <div style={{
                            width: `${p.apiHealthPercent}%`,
                            height: "100%",
                            background: p.apiHealthPercent > 90 ? "var(--success)" : p.apiHealthPercent > 70 ? "var(--warning)" : "var(--error)",
                            borderRadius: 2,
                            transition: "width 500ms var(--ease-out-expo)",
                          }} />
                        </div>
                        <span style={{ fontSize: "0.6875rem", color: "var(--base-text-secondary)", fontFamily: "var(--font-mono)" }}>
                          {p.apiHealthPercent}%
                        </span>
                      </div>
                    </td>
                    <td style={{ padding: "8px", color: "var(--base-text-secondary)", fontFamily: "var(--font-mono)", fontSize: "0.75rem" }}>
                      {p.lastDeployAt ? formatDistanceToNow(new Date(p.lastDeployAt), { addSuffix: true }) : "N/A"}
                    </td>
                    <td style={{ padding: "8px", color: "var(--base-text-secondary)", fontFamily: "var(--font-mono)", fontSize: "0.75rem" }}>
                      {p.codeAgeDays}d
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* System Health */}
      <div className="dashboard-panel panel-animated panel-delay-2" style={{ display: "flex", flexDirection: "column" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>System Health</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, flex: 1 }}>
          {[
            { label: "API Uptime", value: "99.7%", trend: "up", spark: [98, 99, 100, 99, 99, 100, 100] },
            { label: "Error Rate", value: "0.3%", trend: "down", spark: [1.2, 0.8, 0.5, 0.4, 0.3, 0.3, 0.3] },
            { label: "Avg Response", value: `${analytics?.avgResponseTime || 142}ms`, trend: "down", spark: [200, 180, 160, 150, 145, 142, 142] },
            { label: "Active APIs", value: `${analytics?.totalApis || 0}`, trend: "up", spark: [40, 42, 44, 45, 46, 47, 47] },
          ].map((metric) => (
            <div
              key={metric.label}
              style={{
                background: "var(--base-surface-elevated)",
                borderRadius: 8,
                padding: 12,
                border: "1px solid var(--base-border)",
              }}
            >
              <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>
                {metric.label}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                <span style={{ fontSize: "1.25rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>
                  {metric.value}
                </span>
                {metric.trend === "up" ? (
                  <ArrowUpRight size={14} style={{ color: "var(--success)" }} />
                ) : (
                  <ArrowDownRight size={14} style={{ color: "var(--brand-azure)" }} />
                )}
              </div>
              {/* Mini sparkline */}
              <svg width="100%" height={20} viewBox={`0 0 ${metric.spark.length * 10} 20`} preserveAspectRatio="none">
                <polyline
                  points={metric.spark.map((v, i) => `${i * 10},${20 - (v / Math.max(...metric.spark)) * 18}`).join(" ")}
                  fill="none"
                  stroke={metric.trend === "up" ? "var(--success)" : "var(--brand-azure)"}
                  strokeWidth={1.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          ))}
        </div>
      </div>

      {/* Code Overview */}
      <div className="dashboard-panel panel-animated panel-delay-3" style={{ display: "flex", flexDirection: "column" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>Code Overview</h3>
        <div style={{ display: "flex", gap: 16, flex: 1 }}>
          <div style={{ flex: 1, minHeight: 0 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={langDist?.slice(0, 6) || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="loc"
                  animationDuration={800}
                  animationEasing="ease-out"
                  animationBegin={300}
                >
                  {(langDist || []).slice(0, 6).map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--base-surface-elevated)",
                    border: "1px solid var(--base-border)",
                    borderRadius: 8,
                    color: "var(--base-text-primary)",
                    fontSize: "0.75rem",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: 6 }}>
            {(langDist || []).slice(0, 6).map((lang, i) => (
              <div key={lang.language} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.75rem" }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: COLORS[i % COLORS.length] }} />
                <span style={{ flex: 1, color: "var(--base-text-secondary)" }}>{lang.language}</span>
                <span style={{ fontFamily: "var(--font-mono)", fontWeight: 500 }}>{lang.percentage}%</span>
              </div>
            ))}
            <div style={{ marginTop: 8, paddingTop: 8, borderTop: "1px solid var(--base-border)", display: "flex", gap: 12 }}>
              <div>
                <div style={{ fontSize: "0.875rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>
                  {(analytics?.totalLoc || 0).toLocaleString()}
                </div>
                <div style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Total LOC</div>
              </div>
              <div>
                <div style={{ fontSize: "0.875rem", fontWeight: 700, fontFamily: "var(--font-mono)" }}>
                  {analytics?.totalProjects || 0}
                </div>
                <div style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", textTransform: "uppercase" }}>Projects</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="dashboard-panel panel-animated panel-delay-4" style={{ display: "flex", flexDirection: "column" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>Recent Activity</h3>
        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
          {(activities || []).slice(0, 6).map((activity, i) => {
            const icons: Record<string, typeof Upload> = {
              code_upload: Upload,
              api_check: Activity,
              plan_update: FileText,
              suggestion: Lightbulb,
              deploy: ArrowUpRight,
              milestone: Clock,
            };
            const colors: Record<string, string> = {
              code_upload: "var(--brand-purple)",
              api_check: "var(--brand-azure)",
              plan_update: "var(--success)",
              suggestion: "var(--warning)",
              deploy: "var(--info)",
              milestone: "var(--base-text-muted)",
            };
            const Icon = icons[activity.type] || Clock;
            return (
              <div
                key={activity.id || i}
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 10,
                  padding: "6px 0",
                  borderBottom: "1px solid rgba(42, 42, 69, 0.2)",
                }}
              >
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 6,
                    background: `${colors[activity.type] || colors.milestone}15`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  <Icon size={13} style={{ color: colors[activity.type] || colors.milestone }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: "0.8125rem", color: "var(--base-text-primary)", lineHeight: 1.3 }}>
                    {activity.description}
                  </div>
                  <div style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", marginTop: 2 }}>
                    {activity.createdAt ? formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true }) : ""}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="dashboard-panel panel-animated panel-delay-5" style={{ gridColumn: "2", gridRow: "2", display: "flex", flexDirection: "column" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: "0 0 12px" }}>Quick Actions</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
          {quickActions.map((action) => (
            <button
              key={action.label}
              className="btn-primary"
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                background: `linear-gradient(135deg, ${action.color}, ${action.color}dd)`,
              }}
              onClick={() => navigate(action.path)}
            >
              <action.icon size={16} />
              {action.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
