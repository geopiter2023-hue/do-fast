import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Search,
  FolderOpen,
  FileCode2,
  ChevronRight,
  ChevronDown,
  Upload,
  Save,
} from "lucide-react";
import Editor from "@monaco-editor/react";

interface FileNode {
  id: number;
  name: string;
  path: string;
  isDirectory: boolean | null;
  language: string | null;
  loc: number | null;
  content: string | null;
}

export default function Code() {
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [fileContent, setFileContent] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: projects } = trpc.projects.list.useQuery();
  const { data: rootFiles } = trpc.code.getTree.useQuery(
    { projectId: selectedProjectId!, path: undefined },
    { enabled: !!selectedProjectId }
  );

  const fileMutation = trpc.code.updateFile.useMutation({
    onSuccess: () => {
      // Could show toast
    },
  });

  const toggleDir = (path: string) => {
    setExpandedDirs((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const handleFileClick = (file: FileNode) => {
    if (file.isDirectory) {
      toggleDir(file.path);
    } else {
      setSelectedFile(file);
      setFileContent(file.content || "// File content not loaded");
    }
  };

  const fileToNode = (file: { id: number; name: string; path: string; isDirectory: boolean | null; language: string | null; loc: number | null; content: string | null }): FileNode => ({
    id: file.id,
    name: file.name,
    path: file.path,
    isDirectory: file.isDirectory ?? false,
    language: file.language,
    loc: file.loc ?? 0,
    content: file.content,
  });

  const handleSave = () => {
    if (!selectedFile || !selectedProjectId) return;
    fileMutation.mutate({
      projectId: selectedProjectId,
      path: selectedFile.path,
      content: fileContent,
    });
  };

  const getLanguage = (filename: string): string => {
    const ext = filename.split(".").pop()?.toLowerCase();
    const map: Record<string, string> = {
      ts: "typescript",
      tsx: "typescript",
      js: "javascript",
      jsx: "javascript",
      py: "python",
      go: "go",
      rs: "rust",
      java: "java",
      rb: "ruby",
      php: "php",
      sh: "shell",
      json: "json",
      yml: "yaml",
      yaml: "yaml",
      md: "markdown",
    };
    return map[ext || ""] || "plaintext";
  };

  const filteredFiles = (rootFiles || []).filter(
    (f) =>
      !searchQuery ||
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div style={{ padding: 16, height: "calc(100vh - 48px)", display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 1, overflow: "hidden" }}>
      {/* File Explorer */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <h3 style={{ fontSize: "1rem", fontWeight: 600, margin: 0 }}>Code Explorer</h3>
          <select
            value={selectedProjectId || ""}
            onChange={(e) => {
              setSelectedProjectId(Number(e.target.value) || null);
              setSelectedFile(null);
              setExpandedDirs(new Set());
            }}
            style={{
              padding: "4px 8px",
              background: "var(--base-bg)",
              border: "1px solid var(--base-border)",
              borderRadius: 6,
              color: "var(--base-text-primary)",
              fontSize: "0.8125rem",
            }}
          >
            <option value="">Select project</option>
            {(projects || []).map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        {/* Search */}
        <div style={{ position: "relative", marginBottom: 12 }}>
          <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--base-text-muted)" }} />
          <input
            type="text"
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: "100%",
              padding: "8px 10px 8px 32px",
              background: "var(--base-bg)",
              border: "1px solid var(--base-border)",
              borderRadius: "var(--button-radius)",
              color: "var(--base-text-primary)",
              fontSize: "0.8125rem",
              outline: "none",
              boxSizing: "border-box",
            }}
          />
        </div>

        {/* Upload zone */}
        <div
          style={{
            border: "2px dashed var(--base-border)",
            borderRadius: 8,
            padding: 16,
            textAlign: "center",
            marginBottom: 12,
            cursor: "pointer",
            transition: "all 200ms",
          }}
          onDragOver={(e) => { e.preventDefault(); e.currentTarget.style.borderColor = "var(--brand-purple)"; }}
          onDragLeave={(e) => { e.currentTarget.style.borderColor = "var(--base-border)"; }}
          onDrop={(e) => {
            e.preventDefault();
            e.currentTarget.style.borderColor = "var(--base-border)";
            // Handle file drop
          }}
        >
          <Upload size={20} style={{ color: "var(--base-text-muted)", marginBottom: 4 }} />
          <div style={{ fontSize: "0.75rem", color: "var(--base-text-secondary)" }}>
            Drop code archive or click to upload
          </div>
        </div>

        {/* File Tree */}
        <div style={{ flex: 1, overflow: "auto" }}>
          {selectedProjectId ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
              {filteredFiles.map((file) => (
                <div key={file.id}>
                  <div
                    onClick={() => handleFileClick(fileToNode(file))}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                      padding: "5px 8px",
                      borderRadius: 6,
                      cursor: "pointer",
                      background: selectedFile?.path === file.path ? "var(--interactive-selected)" : "transparent",
                      transition: "all 100ms",
                    }}
                  >
                    {file.isDirectory ? (
                      expandedDirs.has(file.path) ? (
                        <ChevronDown size={14} style={{ color: "var(--base-text-muted)", flexShrink: 0 }} />
                      ) : (
                        <ChevronRight size={14} style={{ color: "var(--base-text-muted)", flexShrink: 0 }} />
                      )
                    ) : (
                      <span style={{ width: 14, flexShrink: 0 }} />
                    )}
                    {file.isDirectory ? (
                      <FolderOpen size={14} style={{ color: "var(--brand-purple)", flexShrink: 0 }} />
                    ) : (
                      <FileCode2 size={14} style={{ color: "var(--brand-azure)", flexShrink: 0 }} />
                    )}
                    <span style={{ fontSize: "0.8125rem", flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {file.name}
                    </span>
                    {!file.isDirectory && (
                      <span style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", fontFamily: "var(--font-mono)", flexShrink: 0 }}>
                        {file.loc} LOC
                      </span>
                    )}
                  </div>

                  {/* Expanded directory contents */}
                  {file.isDirectory && expandedDirs.has(file.path) && (
                    <div style={{ paddingLeft: 20 }}>
                      {(rootFiles || [])
                        .filter((f) => f.parentPath === file.path)
                        .map((child) => (
                          <div
                            key={child.id}
                            onClick={() => handleFileClick(fileToNode(child))}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 6,
                              padding: "4px 8px",
                              borderRadius: 6,
                              cursor: "pointer",
                              background: selectedFile?.path === child.path ? "var(--interactive-selected)" : "transparent",
                            }}
                          >
                            <span style={{ width: 14, flexShrink: 0 }} />
                            <FileCode2 size={12} style={{ color: "var(--brand-azure)", flexShrink: 0 }} />
                            <span style={{ fontSize: "0.75rem", flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {child.name}
                            </span>
                            <span style={{ fontSize: "0.625rem", color: "var(--base-text-muted)", fontFamily: "var(--font-mono)", flexShrink: 0 }}>
                              {child.loc} LOC
                            </span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: 40, color: "var(--base-text-muted)" }}>
              <FolderOpen size={32} style={{ marginBottom: 8, opacity: 0.5 }} />
              <div style={{ fontSize: "0.875rem" }}>Select a project to browse files</div>
            </div>
          )}
        </div>
      </div>

      {/* Code Editor */}
      <div className="dashboard-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {selectedFile ? (
          <>
            {/* Editor Header */}
            <div style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "8px 12px",
              background: "var(--base-bg)",
              borderBottom: "1px solid var(--base-border)",
              borderRadius: "8px 8px 0 0",
              margin: "-16px -16px 0",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <FileCode2 size={14} style={{ color: "var(--brand-azure)" }} />
                <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>{selectedFile.name}</span>
                <span style={{ fontSize: "0.6875rem", color: "var(--base-text-muted)", fontFamily: "var(--font-mono)" }}>
                  {selectedFile.language} | {selectedFile.loc} LOC
                </span>
              </div>
              <button onClick={handleSave} className="btn-primary" style={{ padding: "4px 10px", fontSize: "0.75rem", display: "flex", alignItems: "center", gap: 4 }}>
                <Save size={12} />
                Save
              </button>
            </div>

            {/* Monaco Editor */}
            <div style={{ flex: 1, margin: "12px -16px -16px", overflow: "hidden" }}>
              <Editor
                height="100%"
                language={getLanguage(selectedFile.name)}
                value={fileContent}
                onChange={(value) => setFileContent(value || "")}
                theme="vs-dark"
                options={{
                  minimap: { enabled: false },
                  fontSize: 13,
                  fontFamily: "var(--font-mono)",
                  lineNumbers: "on",
                  roundedSelection: false,
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  padding: { top: 8 },
                }}
              />
            </div>
          </>
        ) : (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--base-text-muted)" }}>
            <div style={{ textAlign: "center" }}>
              <FileCode2 size={40} style={{ marginBottom: 12, opacity: 0.3 }} />
              <div style={{ fontSize: "0.875rem" }}>Select a file to view and edit</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
