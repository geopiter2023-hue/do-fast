import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { activityLog } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const activityRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          projectId: z.number().optional(),
          limit: z.number().min(1).max(100).default(50),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit || 50;

      if (input?.projectId) {
        return db
          .select()
          .from(activityLog)
          .where(eq(activityLog.projectId, input.projectId))
          .orderBy(desc(activityLog.createdAt))
          .limit(limit);
      }

      return db
        .select()
        .from(activityLog)
        .orderBy(desc(activityLog.createdAt))
        .limit(limit);
    }),
});
