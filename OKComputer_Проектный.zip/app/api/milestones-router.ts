import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { milestones, milestoneTasks } from "@db/schema";
import { eq } from "drizzle-orm";

export const milestonesRouter = createRouter({
  list: publicQuery
    .input(z.object({ projectId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const msList = await db
        .select()
        .from(milestones)
        .where(eq(milestones.projectId, input.projectId))
        .orderBy(milestones.startDate);

      // Get task counts
      const withTasks = await Promise.all(
        msList.map(async (ms) => {
          const tasks = await db
            .select()
            .from(milestoneTasks)
            .where(eq(milestoneTasks.milestoneId, ms.id));
          const completedTasks = tasks.filter((t) => t.completed).length;
          return {
            ...ms,
            taskCount: tasks.length,
            completedTasks,
          };
        })
      );

      return withTasks;
    }),

  create: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        title: z.string().min(1).max(200),
        description: z.string().optional(),
        startDate: z.string().date(),
        endDate: z.string().date(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(milestones).values({
        projectId: input.projectId,
        title: input.title,
        description: input.description || null,
        startDate: new Date(input.startDate),
        endDate: new Date(input.endDate),
      });
      const [ms] = await db
        .select()
        .from(milestones)
        .where(eq(milestones.id, Number(result.insertId)));
      return ms;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(200).optional(),
        description: z.string().optional(),
        status: z
          .enum(["planned", "in_progress", "completed", "cancelled"])
          .optional(),
        startDate: z.string().date().optional(),
        endDate: z.string().date().optional(),
        progressPercent: z.number().min(0).max(100).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const updateData: Record<string, unknown> = { updatedAt: new Date() };
      if (data.title !== undefined) updateData.title = data.title;
      if (data.description !== undefined) updateData.description = data.description;
      if (data.status !== undefined) updateData.status = data.status;
      if (data.startDate !== undefined) updateData.startDate = new Date(data.startDate);
      if (data.endDate !== undefined) updateData.endDate = new Date(data.endDate);
      if (data.progressPercent !== undefined)
        updateData.progressPercent = data.progressPercent;

      await db.update(milestones).set(updateData).where(eq(milestones.id, id));
      const [ms] = await db
        .select()
        .from(milestones)
        .where(eq(milestones.id, id));
      return ms;
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Delete tasks first
      await db
        .delete(milestoneTasks)
        .where(eq(milestoneTasks.milestoneId, input.id));
      await db.delete(milestones).where(eq(milestones.id, input.id));
      return { success: true };
    }),
});

export const tasksRouter = createRouter({
  list: publicQuery
    .input(z.object({ milestoneId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(milestoneTasks)
        .where(eq(milestoneTasks.milestoneId, input.milestoneId))
        .orderBy(milestoneTasks.createdAt);
    }),

  create: publicQuery
    .input(
      z.object({
        milestoneId: z.number(),
        title: z.string().min(1).max(200),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(milestoneTasks).values({
        milestoneId: input.milestoneId,
        title: input.title,
      });
      const [task] = await db
        .select()
        .from(milestoneTasks)
        .where(eq(milestoneTasks.id, Number(result.insertId)));
      return task;
    }),

  toggle: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [existing] = await db
        .select()
        .from(milestoneTasks)
        .where(eq(milestoneTasks.id, input.id));
      if (!existing) throw new Error("Task not found");

      await db
        .update(milestoneTasks)
        .set({ completed: !existing.completed })
        .where(eq(milestoneTasks.id, input.id));

      const [task] = await db
        .select()
        .from(milestoneTasks)
        .where(eq(milestoneTasks.id, input.id));
      return task;
    }),
});
