import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { projectsRouter } from "./projects-router";
import { apiRouter } from "./api-router";
import { codeRouter } from "./code-router";
import { milestonesRouter, tasksRouter } from "./milestones-router";
import { suggestionsRouter } from "./suggestions-router";
import { activityRouter } from "./activity-router";
import { settingsRouter } from "./settings-router";
import { analyticsRouter } from "./analytics-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  projects: projectsRouter,
  api: apiRouter,
  code: codeRouter,
  milestones: milestonesRouter,
  tasks: tasksRouter,
  suggestions: suggestionsRouter,
  activity: activityRouter,
  settings: settingsRouter,
  analytics: analyticsRouter,
});

export type AppRouter = typeof appRouter;
