import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { codeFiles } from "@db/schema";
import { eq, and, isNull } from "drizzle-orm";

export const codeRouter = createRouter({
  getTree: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        path: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      if (input.path) {
        return db
          .select()
          .from(codeFiles)
          .where(
            and(
              eq(codeFiles.projectId, input.projectId),
              eq(codeFiles.parentPath, input.path)
            )
          )
          .orderBy(codeFiles.isDirectory, codeFiles.name);
      }
      // Root level: files with no parent or parent is null
      return db
        .select()
        .from(codeFiles)
        .where(
          and(
            eq(codeFiles.projectId, input.projectId),
            isNull(codeFiles.parentPath)
          )
        )
        .orderBy(codeFiles.isDirectory, codeFiles.name);
    }),

  getFile: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        path: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const [file] = await db
        .select()
        .from(codeFiles)
        .where(
          and(
            eq(codeFiles.projectId, input.projectId),
            eq(codeFiles.path, input.path)
          )
        );
      return file || null;
    }),

  updateFile: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        path: z.string(),
        content: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(codeFiles)
        .set({
          content: input.content,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(codeFiles.projectId, input.projectId),
            eq(codeFiles.path, input.path)
          )
        );
      const [file] = await db
        .select()
        .from(codeFiles)
        .where(
          and(
            eq(codeFiles.projectId, input.projectId),
            eq(codeFiles.path, input.path)
          )
        );
      return file;
    }),

  uploadFiles: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        files: z.array(
          z.object({
            path: z.string(),
            name: z.string(),
            content: z.string(),
            language: z.string().nullable(),
            sizeBytes: z.number(),
            loc: z.number(),
            parentPath: z.string().nullable(),
            isDirectory: z.boolean(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      if (input.files.length === 0) return { filesProcessed: 0 };

      // Insert in batches of 50
      const batchSize = 50;
      for (let i = 0; i < input.files.length; i += batchSize) {
        const batch = input.files.slice(i, i + batchSize).map((f) => ({
          projectId: input.projectId,
          ...f,
        }));
        await db.insert(codeFiles).values(batch);
      }

      return { filesProcessed: input.files.length };
    }),
});
