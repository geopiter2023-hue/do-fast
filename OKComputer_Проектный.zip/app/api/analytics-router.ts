import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projects, apiEndpoints, apiLogs, codeFiles, suggestions } from "@db/schema";
import { eq, desc, sql, avg } from "drizzle-orm";

export const analyticsRouter = createRouter({
  overview: publicQuery.query(async () => {
    const db = getDb();

    const projectList = await db.select({ count: sql<number>`count(*)` }).from(projects);
    const totalProjects = projectList[0]?.count || 0;

    const activeProjects = await db
      .select({ count: sql<number>`count(*)` })
      .from(projects)
      .where(eq(projects.status, "active"));

    const endpointList = await db.select({ count: sql<number>`count(*)` }).from(apiEndpoints);
    const totalApis = endpointList[0]?.count || 0;

    const avgResponse = await db
      .select({ avg: avg(apiLogs.responseTimeMs) })
      .from(apiLogs);

    const locResult = await db
      .select({ total: sql<number>`sum(${codeFiles.loc})` })
      .from(codeFiles);

    return {
      totalProjects,
      activeProjects: activeProjects[0]?.count || 0,
      totalApis,
      avgResponseTime: Math.round(Number(avgResponse[0]?.avg) || 142),
      totalLoc: locResult[0]?.total || 0,
    };
  }),

  projectActivity: publicQuery
    .input(
      z.object({
        projectId: z.number(),
        days: z.number().min(1).max(90).default(30),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      // Get API logs for this project's endpoints
      const endpoints = await db
        .select({ id: apiEndpoints.id })
        .from(apiEndpoints)
        .where(eq(apiEndpoints.projectId, input.projectId));
      const endpointIds = endpoints.map((e) => e.id);

      if (endpointIds.length === 0) {
        return Array.from({ length: input.days }, (_, i) => ({
          date: new Date(Date.now() - (input.days - 1 - i) * 86400000).toISOString().split("T")[0],
          apiCalls: 0,
          errors: 0,
          avgResponseTime: 0,
        }));
      }

      // Get logs grouped by day
      const logs = await db
        .select({
          checkedAt: apiLogs.checkedAt,
          success: apiLogs.success,
          responseTimeMs: apiLogs.responseTimeMs,
        })
        .from(apiLogs)
        .where(sql`${apiLogs.endpointId} IN (${endpointIds.join(",")})`)
        .orderBy(desc(apiLogs.checkedAt));

      // Group by day
      const daysMap = new Map<string, { apiCalls: number; errors: number; totalResponse: number }>();
      for (let i = 0; i < input.days; i++) {
        const date = new Date(Date.now() - (input.days - 1 - i) * 86400000).toISOString().split("T")[0];
        daysMap.set(date, { apiCalls: 0, errors: 0, totalResponse: 0 });
      }

      for (const log of logs) {
        if (!log.checkedAt) continue;
        const date = new Date(log.checkedAt).toISOString().split("T")[0];
        if (daysMap.has(date)) {
          const day = daysMap.get(date)!;
          day.apiCalls++;
          if (!log.success) day.errors++;
          day.totalResponse += log.responseTimeMs || 0;
        }
      }

      return Array.from(daysMap.entries()).map(([date, data]) => ({
        date,
        apiCalls: data.apiCalls,
        errors: data.errors,
        avgResponseTime: data.apiCalls > 0 ? Math.round(data.totalResponse / data.apiCalls) : 0,
      }));
    }),

  languageDistribution: publicQuery.query(async () => {
    const db = getDb();
    const result = await db
      .select({
        language: codeFiles.language,
        totalLoc: sql<number>`sum(${codeFiles.loc})`,
        count: sql<number>`count(*)`,
      })
      .from(codeFiles)
      .where(sql`${codeFiles.language} IS NOT NULL`)
      .groupBy(codeFiles.language);

    const total = result.reduce((sum, r) => sum + (r.totalLoc || 0), 0);
    return result.map((r) => ({
      language: r.language || "Unknown",
      loc: r.totalLoc || 0,
      count: r.count || 0,
      percentage: total > 0 ? Math.round(((r.totalLoc || 0) / total) * 100) : 0,
    }));
  }),

  systemMetrics: publicQuery
    .input(z.object({ projectId: z.number().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();

      if (input?.projectId) {
        const endpoints = await db
          .select({ id: apiEndpoints.id })
          .from(apiEndpoints)
          .where(eq(apiEndpoints.projectId, input.projectId));
        const endpointIds = endpoints.map((e) => e.id);

        if (endpointIds.length === 0) return [];

        return db
          .select({
            endpointId: apiLogs.endpointId,
            avgResponseTime: avg(apiLogs.responseTimeMs),
            successRate: sql<number>`round(avg(case when ${apiLogs.success} then 1 else 0 end) * 100)`,
          })
          .from(apiLogs)
          .where(sql`${apiLogs.endpointId} IN (${endpointIds.join(",")})`)
          .groupBy(apiLogs.endpointId);
      }

      return db
        .select({
          endpointId: apiLogs.endpointId,
          avgResponseTime: avg(apiLogs.responseTimeMs),
          successRate: sql<number>`round(avg(case when ${apiLogs.success} then 1 else 0 end) * 100)`,
        })
        .from(apiLogs)
        .groupBy(apiLogs.endpointId);
    }),

  suggestionsSummary: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(suggestions);

    const byType: Record<string, number> = {};
    const byPriority: Record<string, number> = {};
    const byStatus: Record<string, number> = {};

    for (const s of all) {
      byType[s.type] = (byType[s.type] || 0) + 1;
      byPriority[s.priority] = (byPriority[s.priority] || 0) + 1;
      byStatus[s.status] = (byStatus[s.status] || 0) + 1;
    }

    return {
      total: all.length,
      pending: byStatus["pending"] || 0,
      applied: byStatus["applied"] || 0,
      dismissed: byStatus["dismissed"] || 0,
      byType,
      byPriority,
    };
  }),
});
