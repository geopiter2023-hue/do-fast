import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { suggestions } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const suggestionsRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          projectId: z.number().optional(),
          status: z.enum(["pending", "applied", "dismissed"]).optional(),
          type: z
            .enum(["code", "architecture", "performance", "security"])
            .optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      let query = db.select().from(suggestions);

      const conditions = [];
      if (input?.projectId) {
        conditions.push(eq(suggestions.projectId, input.projectId));
      }
      if (input?.status) {
        conditions.push(eq(suggestions.status, input.status));
      }
      if (input?.type) {
        conditions.push(eq(suggestions.type, input.type));
      }

      if (conditions.length > 0) {
        // Apply first condition directly since drizzle mysql doesn't have and() with array easily
        query = db.select().from(suggestions).where(conditions[0]) as typeof query;
      }

      return query.orderBy(
        desc(suggestions.priority),
        desc(suggestions.createdAt)
      );
    }),

  applySuggestion: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(suggestions)
        .set({ status: "applied", resolvedAt: new Date() })
        .where(eq(suggestions.id, input.id));
      const [sug] = await db
        .select()
        .from(suggestions)
        .where(eq(suggestions.id, input.id));
      return sug;
    }),

  dismissSuggestion: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(suggestions)
        .set({ status: "dismissed", resolvedAt: new Date() })
        .where(eq(suggestions.id, input.id));
      const [sug] = await db
        .select()
        .from(suggestions)
        .where(eq(suggestions.id, input.id));
      return sug;
    }),
});
