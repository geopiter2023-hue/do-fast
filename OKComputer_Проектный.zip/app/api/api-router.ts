import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { apiEndpoints, apiLogs, projects } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";

export const apiRouter = createRouter({
  listEndpoints: publicQuery
    .input(z.object({ projectId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const endpoints = await db
        .select()
        .from(apiEndpoints)
        .where(eq(apiEndpoints.projectId, input.projectId));

      // Get latest log for each endpoint
      const endpointsWithStatus = await Promise.all(
        endpoints.map(async (ep) => {
          const [latestLog] = await db
            .select()
            .from(apiLogs)
            .where(eq(apiLogs.endpointId, ep.id))
            .orderBy(desc(apiLogs.checkedAt))
            .limit(1);

          // Calculate uptime
          const logs = await db
            .select({ success: apiLogs.success })
            .from(apiLogs)
            .where(eq(apiLogs.endpointId, ep.id));

          const uptime = logs.length > 0
            ? Math.round((logs.filter((l) => l.success).length / logs.length) * 100)
            : 100;

          return {
            ...ep,
            latestStatusCode: latestLog?.statusCode || null,
            latestResponseTime: latestLog?.responseTimeMs || null,
            latestSuccess: latestLog?.success || false,
            lastCheckedAt: latestLog?.checkedAt || null,
            uptime,
          };
        })
      );

      return endpointsWithStatus;
    }),

  checkEndpoint: publicQuery
    .input(z.object({ endpointId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [endpoint] = await db
        .select()
        .from(apiEndpoints)
        .where(eq(apiEndpoints.id, input.endpointId));

      if (!endpoint) throw new Error("Endpoint not found");

      // Get project base URL
      const [project] = await db
        .select()
        .from(projects)
        .where(eq(projects.id, endpoint.projectId));

      const baseUrl = project?.apiBaseUrl || "http://localhost:3000";
      const url = `${baseUrl}${endpoint.path}`;

      const startTime = Date.now();
      let statusCode = 0;
      let success = false;
      let errorMessage = null;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), endpoint.timeoutMs || 5000);

        const response = await fetch(url, {
          method: endpoint.method,
          signal: controller.signal,
        });

        clearTimeout(timeout);
        statusCode = response.status;
        success = response.ok;
      } catch (err) {
        statusCode = 0;
        success = false;
        errorMessage = err instanceof Error ? err.message : "Request failed";
      }

      const responseTimeMs = Date.now() - startTime;

      await db.insert(apiLogs).values({
        endpointId: endpoint.id,
        statusCode,
        responseTimeMs,
        success,
        errorMessage,
      });

      return { statusCode, responseTimeMs, success };
    }),

  checkAll: publicQuery
    .input(z.object({ projectId: z.number().optional() }).optional())
    .mutation(async ({ input }) => {
      const db = getDb();
      let endpointsList;

      if (input?.projectId) {
        endpointsList = await db
          .select()
          .from(apiEndpoints)
          .where(eq(apiEndpoints.projectId, input.projectId));
      } else {
        endpointsList = await db.select().from(apiEndpoints);
      }

      const results = await Promise.all(
        endpointsList.map(async (ep) => {
          const [project] = await db
            .select()
            .from(projects)
            .where(eq(projects.id, ep.projectId));

          const baseUrl = project?.apiBaseUrl || "http://localhost:3000";
          const url = `${baseUrl}${ep.path}`;

          const startTime = Date.now();
          let statusCode = 0;
          let success = false;
          let errorMessage = null;

          try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), ep.timeoutMs || 5000);
            const response = await fetch(url, { method: ep.method, signal: controller.signal });
            clearTimeout(timeout);
            statusCode = response.status;
            success = response.ok;
          } catch (err) {
            errorMessage = err instanceof Error ? err.message : "Request failed";
          }

          const responseTimeMs = Date.now() - startTime;

          await db.insert(apiLogs).values({
            endpointId: ep.id,
            statusCode,
            responseTimeMs,
            success,
            errorMessage,
          });

          return { endpointId: ep.id, statusCode, responseTimeMs, success };
        })
      );

      return results;
    }),

  getLogs: publicQuery
    .input(
      z.object({
        endpointId: z.number(),
        limit: z.number().min(1).max(100).default(50),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(apiLogs)
        .where(eq(apiLogs.endpointId, input.endpointId))
        .orderBy(desc(apiLogs.checkedAt))
        .limit(input.limit);
    }),

  getErrorLog: publicQuery
    .input(
      z
        .object({
          projectId: z.number().optional(),
          limit: z.number().min(1).max(100).default(50),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit || 50;

      if (input?.projectId) {
        const endpoints = await db
          .select({ id: apiEndpoints.id })
          .from(apiEndpoints)
          .where(eq(apiEndpoints.projectId, input.projectId));
        const endpointIds = endpoints.map((e) => e.id);
        if (endpointIds.length === 0) return [];
        return db
          .select()
          .from(apiLogs)
          .where(and(sql`${apiLogs.endpointId} IN (${endpointIds.join(",")})`, eq(apiLogs.success, false)))
          .orderBy(desc(apiLogs.checkedAt))
          .limit(limit);
      }

      return db
        .select()
        .from(apiLogs)
        .where(eq(apiLogs.success, false))
        .orderBy(desc(apiLogs.checkedAt))
        .limit(limit);
    }),
});
