import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projects, apiEndpoints, apiLogs, codeFiles, milestones } from "@db/schema";
import { eq, like, or, desc, sql } from "drizzle-orm";

export const projectsRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          search: z.string().optional(),
          status: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.search) {
        conditions.push(
          or(
            like(projects.name, `%${input.search}%`),
            like(projects.description, `%${input.search}%`)
          )
        );
      }
      if (input?.status) {
        conditions.push(eq(projects.status, input.status as "active" | "warning" | "critical" | "paused"));
      }

      const result = await db
        .select({
          id: projects.id,
          name: projects.name,
          description: projects.description,
          status: projects.status,
          apiBaseUrl: projects.apiBaseUrl,
          owner: projects.owner,
          createdAt: projects.createdAt,
          totalLoc: projects.totalLoc,
          totalFiles: projects.totalFiles,
          lastDeployAt: projects.lastDeployAt,
          codeUpdatedAt: projects.codeUpdatedAt,
        })
        .from(projects)
        .where(conditions.length > 0 ? conditions[0] : undefined)
        .orderBy(projects.name);

      // Get latest API health for each project
      const projectsWithHealth = await Promise.all(
        result.map(async (p) => {
          const endpoints = await db
            .select({
              id: apiEndpoints.id,
            })
            .from(apiEndpoints)
            .where(eq(apiEndpoints.projectId, p.id));

          let apiHealthPercent = 100;
          if (endpoints.length > 0) {
            const endpointIds = endpoints.map((e) => e.id);
            const recentLogs = await db
              .select({
                success: apiLogs.success,
              })
              .from(apiLogs)
              .where(sql`${apiLogs.endpointId} IN (${endpointIds.join(",")})`)
              .orderBy(desc(apiLogs.checkedAt))
              .limit(endpointIds.length);

            if (recentLogs.length > 0) {
              const successCount = recentLogs.filter((l) => l.success).length;
              apiHealthPercent = Math.round((successCount / recentLogs.length) * 100);
            }
          }

          const codeAgeDays = p.codeUpdatedAt
            ? Math.floor((Date.now() - new Date(p.codeUpdatedAt).getTime()) / (1000 * 60 * 60 * 24))
            : 0;

          return {
            ...p,
            apiHealthPercent,
            codeAgeDays,
          };
        })
      );

      return projectsWithHealth;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [project] = await db.select().from(projects).where(eq(projects.id, input.id));
      if (!project) return null;

      const endpoints = await db
        .select()
        .from(apiEndpoints)
        .where(eq(apiEndpoints.projectId, input.id));

      const files = await db
        .select()
        .from(codeFiles)
        .where(eq(codeFiles.projectId, input.id));

      const milestoneList = await db
        .select()
        .from(milestones)
        .where(eq(milestones.projectId, input.id))
        .orderBy(milestones.startDate);

      return { ...project, endpoints, files, milestones: milestoneList };
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(100),
        description: z.string().optional(),
        apiBaseUrl: z.string().url().optional(),
        owner: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(projects).values({
        name: input.name,
        description: input.description || null,
        apiBaseUrl: input.apiBaseUrl || null,
        owner: input.owner || null,
      });
      const [project] = await db.select().from(projects).where(eq(projects.id, Number(result.insertId)));
      return project;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(100).optional(),
        description: z.string().optional(),
        status: z.enum(["active", "warning", "critical", "paused"]).optional(),
        apiBaseUrl: z.string().url().optional(),
        owner: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const updateData: Record<string, unknown> = {};
      if (data.name !== undefined) updateData.name = data.name;
      if (data.description !== undefined) updateData.description = data.description;
      if (data.status !== undefined) updateData.status = data.status;
      if (data.apiBaseUrl !== undefined) updateData.apiBaseUrl = data.apiBaseUrl;
      if (data.owner !== undefined) updateData.owner = data.owner;
      updateData.updatedAt = new Date();

      await db.update(projects).set(updateData).where(eq(projects.id, id));
      const [project] = await db.select().from(projects).where(eq(projects.id, id));
      return project;
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
