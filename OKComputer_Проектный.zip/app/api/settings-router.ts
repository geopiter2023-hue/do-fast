import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { userSettings } from "@db/schema";

export const settingsRouter = createRouter({
  get: publicQuery.query(async () => {
    const db = getDb();
    const settings = await db.select().from(userSettings).limit(1);
    if (settings.length === 0) {
      // Create default settings
      await db.insert(userSettings).values({
        apiTimeout: 5000,
        apiRetryCount: 3,
        refreshIntervalSeconds: 30,
        emailNotifications: true,
        pushNotifications: false,
        theme: "dark",
      });
      const [newSettings] = await db.select().from(userSettings).limit(1);
      return newSettings;
    }
    return settings[0];
  }),

  update: publicQuery
    .input(
      z.object({
        apiTimeout: z.number().min(1000).max(30000).optional(),
        apiRetryCount: z.number().min(0).max(10).optional(),
        refreshIntervalSeconds: z.number().min(10).max(300).optional(),
        emailNotifications: z.boolean().optional(),
        pushNotifications: z.boolean().optional(),
        webhookUrl: z.string().url().optional().nullable(),
        theme: z.enum(["dark", "light"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(userSettings).limit(1);

      if (existing.length === 0) {
        await db.insert(userSettings).values({
          apiTimeout: input.apiTimeout || 5000,
          apiRetryCount: input.apiRetryCount || 3,
          refreshIntervalSeconds: input.refreshIntervalSeconds || 30,
          emailNotifications: input.emailNotifications ?? true,
          pushNotifications: input.pushNotifications ?? false,
          webhookUrl: input.webhookUrl || null,
          theme: input.theme || "dark",
        });
      } else {
        const updateData: Record<string, unknown> = {};
        if (input.apiTimeout !== undefined) updateData.apiTimeout = input.apiTimeout;
        if (input.apiRetryCount !== undefined) updateData.apiRetryCount = input.apiRetryCount;
        if (input.refreshIntervalSeconds !== undefined)
          updateData.refreshIntervalSeconds = input.refreshIntervalSeconds;
        if (input.emailNotifications !== undefined)
          updateData.emailNotifications = input.emailNotifications;
        if (input.pushNotifications !== undefined)
          updateData.pushNotifications = input.pushNotifications;
        if (input.webhookUrl !== undefined) updateData.webhookUrl = input.webhookUrl;
        if (input.theme !== undefined) updateData.theme = input.theme;

        await db.update(userSettings).set(updateData);
      }

      const [settings] = await db.select().from(userSettings).limit(1);
      return settings;
    }),
});
