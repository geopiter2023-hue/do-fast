# LUKOIL B2B Shop - Техническая спецификация

## 1. Технологический стек

- **Framework**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Routing**: React Router DOM (v6)
- **State**: React Context + useState/useReducer
- **Icons**: Lucide React (иконки) + inline SVG (логотип)
- **Animation**: CSS Transitions + Framer Motion (слайдер, модалки)

## 2. Установка зависимостей

```bash
# После init-webapp.sh:
npm install react-router-dom framer-motion
```

## 3. Структура проекта

```
src/
├── components/          # Переиспользуемые компоненты
│   ├── TopBar.tsx
│   ├── Header.tsx
│   ├── MegaMenu.tsx
│   ├── Footer.tsx
│   ├── Breadcrumbs.tsx
│   ├── ProductCard.tsx
│   ├── CategoryCard.tsx
│   ├── SidebarMenu.tsx
│   ├── AuthModal.tsx
│   ├── ChatButton.tsx
│   └── ui/             # shadcn компоненты (уже есть)
│       ├── button.tsx
│       ├── input.tsx
│       ├── checkbox.tsx
│       ├── select.tsx
│       ├── dialog.tsx
│       ├── tabs.tsx
│       └── ...
├── sections/           # Секции главной страницы
│   ├── HeroSlider.tsx
│   ├── CategoriesGrid.tsx
│   ├── HelpBanner.tsx
│   ├── HowItWorks.tsx
│   ├── PopularProducts.tsx
│   ├── AboutBlock.tsx
│   ├── PopularCategories.tsx
│   └── Advantages.tsx
├── pages/              # Страницы
│   ├── HomePage.tsx
│   ├── CatalogPage.tsx
│   ├── ProductPage.tsx
│   ├── DeliveryPage.tsx
│   ├── PaymentPage.tsx
│   ├── AboutPage.tsx
│   ├── OilSelectorPage.tsx
│   ├── PromotionsPage.tsx
│   ├── CartPage.tsx
│   └── CommercialOfferPage.tsx
├── hooks/              # Кастомные хуки
│   ├── useCart.ts
│   ├── useAuth.ts
│   └── useScrollHeader.ts
├── data/               # Данные (моки)
│   ├── products.ts
│   ├── categories.ts
│   └── navigation.ts
├── types/              # TypeScript типы
│   └── index.ts
├── App.tsx
├── main.tsx
└── index.css
```

## 4. Маршруты (Routing)

| Путь | Компонент | Описание |
|------|-----------|----------|
| `/` | HomePage | Главная страница |
| `/catalog` | CatalogPage | Каталог |
| `/product/:id` | ProductPage | Страница товара |
| `/delivery` | DeliveryPage | Доставка |
| `/payment` | PaymentPage | Оплата |
| `/about` | AboutPage | О компании |
| `/oil-selector` | OilSelectorPage | Подбор масла |
| `/promotions` | PromotionsPage | Акции |
| `/cart` | CartPage | Корзина |
| `/commercial-offer` | CommercialOfferPage | Получить КП |

## 5. State Management

### Cart Context
```typescript
interface CartItem {
  id: string;
  name: string;
  article: string;
  packaging: string;
  price: number;
  quantity: number;
  image: string;
}

interface CartState {
  items: CartItem[];
  totalCount: number;
  totalPrice: number;
}
// Actions: ADD_ITEM, REMOVE_ITEM, UPDATE_QUANTITY, CLEAR
```

### Auth Context
```typescript
interface AuthState {
  isAuthenticated: boolean;
  user: { email: string; name: string } | null;
  showModal: boolean;
}
// Actions: LOGIN, LOGOUT, SHOW_MODAL, HIDE_MODAL
```

## 6. Компоненты: подробная реализация

### TopBar
- Простой div с flex, bg #2B2F3B
- Текст слева, телефон справа

### Header
- Flex container, bg white, border-bottom
- Логотип (SVG inline или img)
- Навигация (map по массиву ссылок)
- Правая часть: кнопки с иконками
- Sticky при скролле (useScrollHeader hook)

### MegaMenu
- Dropdown при hover на "Каталог"
- 4 колонки с подкатегориями
- CSS transition для анимации

### HeroSlider
- useState для текущего слайда
- useEffect для автопрокрутки (setInterval 5000ms)
- Framer Motion для анимации переходов
- Точки навигации + стрелки

### ProductCard
- Props: id, name, article, image, price, packaging, specs
- Select для выбора фасовки
- Кнопка "Купить" -> добавляет в корзину

### SidebarMenu
- Props: activeItem
- Массив пунктов меню
- Активный: bg #D5141D, text white

### AuthModal
- Dialog из shadcn
- Tabs: Вход | Регистрация
- Формы с валидацией

## 7. Страницы: состав

### HomePage
- HeroSlider
- CategoriesGrid (6 карточек)
- HelpBanner
- HowItWorks (4 шага)
- PopularProducts (4 товара)
- AboutBlock
- PopularCategories (карусель/сетка)
- Advantages (6 преимуществ)

### CatalogPage
- Sidebar (фильтры) + Content (сетка товаров)
- Состояние фильтров в useState
- Товары из mock data

### ProductPage
- Изображение + информация
- Табы: Описание / Документы
- Похожие товары

### DeliveryPage, PaymentPage, AboutPage
- SidebarMenu + контентная секция

### OilSelectorPage
- Форма с табами (Госномер/VIN)
- Карточки типов транспорта

### PromotionsPage
- Список акций с изображениями

### CartPage
- Таблица товаров / пустое состояние
- Итого + кнопка оформления

### CommercialOfferPage
- Форма заявки

## 8. Хуки

### useCart
- Доступ к CartContext
- Функции: addItem, removeItem, updateQuantity, clearCart

### useAuth
- Доступ к AuthContext
- Функции: login, logout, openModal, closeModal

### useScrollHeader
- Отслеживание scroll position
- Возвращает: isSticky (boolean)

## 9. Типы

```typescript
// types/index.ts

export interface Product {
  id: string;
  name: string;
  article: string;
  image: string;
  price: number;
  pricePerUnit: number;
  unit: string;
  category: string;
  viscosity: string;
  api: string;
  type: 'mineral' | 'semi-synthetic' | 'synthetic';
  vehicleType: string;
  packaging: PackagingOption[];
  description: string;
  specs: Record<string, string>;
  inStock: boolean;
}

export interface PackagingOption {
  id: string;
  name: string;
  volume: string;
  quantity: number;
  price: number;
}

export interface Category {
  id: string;
  name: string;
  subcategories: SubCategory[];
  image: string;
}

export interface SubCategory {
  id: string;
  name: string;
  count?: number;
}

export interface CartItem {
  productId: string;
  packagingId: string;
  quantity: number;
}

export interface NavItem {
  label: string;
  href: string;
  children?: NavItem[];
}
```

## 10. Mock данные

### Продукты (~20 товаров)
- Моторные масла (Genesis, Avantgarde, Super, Luxe)
- Трансмиссионные масла
- Индустриальные масла
- Охлаждающие жидкости
- Тормозные жидкости
- Смазки

### Категории (6 основных)
- Моторные масла
- Трансмиссионные масла
- Индустриальные масла
- Охлаждающие жидкости
- Тормозные жидкости
- Пластичные смазки

## 11. Responsive подход

- Mobile-first подход с Tailwind
- Брейкпоинты: sm (640), md (768), lg (1024), xl (1280)
- Гамбургер-меню на мобильных
- Карточки товаров: 1 колонка (mobile) → 2 (tablet) → 3 (desktop)
- Sidebar фильтры: скрыты за кнопкой на мобильных
