import { Phone } from 'lucide-react';

export function TopBar() {
  return (
    <div className="bg-[#2B2F3B] text-white h-9 flex items-center">
      <div className="max-w-[1400px] mx-auto w-full px-5 flex items-center justify-between">
        <span className="text-[13px]">
          Официальный магазин смазочных материалов ЛУКОЙЛ для бизнеса
        </span>
        <a href="tel:88007008700" className="text-[13px] flex items-center gap-1.5 hover:text-red-400 transition-colors">
          <Phone className="w-3.5 h-3.5" />
          8 800 700-8-700
        </a>
      </div>
    </div>
  );
}
