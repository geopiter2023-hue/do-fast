import { useState, useMemo } from 'react';
import { X, MapPin, Search } from 'lucide-react';
import { useGeolocation, defaultCities } from '@/hooks/useGeolocation';
import { Input } from '@/components/ui/input';

export function CityModal() {
  const { state, setCity, showModal, closeModal } = useGeolocation();
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    if (!search.trim()) return defaultCities;
    const q = search.toLowerCase();
    return defaultCities.filter((c) => c.toLowerCase().includes(q));
  }, [search]);

  if (!showModal) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={closeModal} />
      <div className="relative bg-white rounded-lg w-full max-w-[480px] mx-4 shadow-xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#E0E0E0]">
          <h3 className="text-lg font-semibold text-[#1A1A1A]">Выберите город</h3>
          <button onClick={closeModal} className="text-[#999] hover:text-[#1A1A1A] transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-[#E0E0E0]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#999]" />
            <Input
              placeholder="Поиск города..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 h-10"
              autoFocus
            />
          </div>
        </div>

        {/* Current city */}
        <div className="px-4 py-3 bg-[#F5F5F5] flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#D5141D]" />
          <span className="text-sm text-[#666]">Текущий город:</span>
          <span className="text-sm font-semibold text-[#1A1A1A]">{state.city}</span>
        </div>

        {/* City list */}
        <div className="overflow-y-auto flex-1 p-2">
          <div className="grid grid-cols-2 gap-1">
            {filtered.map((city) => (
              <button
                key={city}
                onClick={() => {
                  setCity(city);
                  closeModal();
                }}
                className={`text-left px-3 py-2.5 rounded text-sm transition-colors ${
                  state.city === city
                    ? 'bg-[#D5141D] text-white'
                    : 'text-[#1A1A1A] hover:bg-[#F5F5F5]'
                }`}
              >
                {city}
              </button>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center text-sm text-[#999] py-8">Город не найден</p>
          )}
        </div>
      </div>
    </div>
  );
}
