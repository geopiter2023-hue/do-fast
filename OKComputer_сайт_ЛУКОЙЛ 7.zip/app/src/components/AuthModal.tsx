import { useState } from 'react';
import { X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';

export function AuthModal() {
  const { state, login, closeModal } = useAuth();
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [agree, setAgree] = useState(false);

  if (!state.showModal) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tab === 'login') {
      login(email, password);
    } else {
      if (password !== confirmPassword) {
        alert('Пароли не совпадают');
        return;
      }
      if (!agree) {
        alert('Необходимо согласие с условиями');
        return;
      }
      login(email, password);
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={closeModal} />
      <div className="relative bg-white rounded-lg w-full max-w-[420px] mx-4 shadow-xl">
        <button
          onClick={closeModal}
          className="absolute top-4 right-4 text-[#666666] hover:text-[#1A1A1A] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6">
          {/* Tabs */}
          <div className="flex border-b border-[#E0E0E0] mb-6">
            <button
              onClick={() => setTab('login')}
              className={`pb-3 px-4 text-sm font-medium transition-colors ${
                tab === 'login'
                  ? 'text-[#D5141D] border-b-2 border-[#D5141D]'
                  : 'text-[#666666] hover:text-[#1A1A1A]'
              }`}
            >
              Вход
            </button>
            <button
              onClick={() => setTab('register')}
              className={`pb-3 px-4 text-sm font-medium transition-colors ${
                tab === 'register'
                  ? 'text-[#D5141D] border-b-2 border-[#D5141D]'
                  : 'text-[#666666] hover:text-[#1A1A1A]'
              }`}
            >
              Регистрация
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-[#666666] mb-1">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@company.ru"
                required
                className="h-11"
              />
            </div>

            <div>
              <label className="block text-sm text-[#666666] mb-1">Пароль</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="h-11"
              />
            </div>

            {tab === 'register' && (
              <div>
                <label className="block text-sm text-[#666666] mb-1">Подтвердите пароль</label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="h-11"
                />
              </div>
            )}

            {tab === 'login' && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm text-[#666666]">
                  <Checkbox checked={rememberMe} onCheckedChange={(v) => setRememberMe(!!v)} />
                  Запомнить меня
                </label>
                <button type="button" className="text-sm text-[#D5141D] hover:underline">
                  Забыли пароль?
                </button>
              </div>
            )}

            {tab === 'register' && (
              <label className="flex items-start gap-2 text-sm text-[#666666]">
                <Checkbox checked={agree} onCheckedChange={(v) => setAgree(!!v)} className="mt-0.5" />
                <span>
                  Я согласен с{' '}
                  <a href="/about" className="text-[#D5141D] hover:underline">
                    условиями использования
                  </a>
                </span>
              </label>
            )}

            <Button
              type="submit"
              className="w-full h-11 bg-[#D5141D] hover:bg-[#B01018] text-white"
            >
              {tab === 'login' ? 'Войти' : 'Зарегистрироваться'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
