import { Link } from 'react-router-dom';
import { ArrowRight, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { findAnalogs } from '@/data/analogs';
import { useGeolocation } from '@/hooks/useGeolocation';
import { getStockForProduct } from '@/data/warehouses';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/useCart';

interface StockAnalogsProps {
  productId: string;
}

export function StockAnalogs({ productId }: StockAnalogsProps) {
  const { state: geoState } = useGeolocation();
  const { addItem } = useCart();

  const stocks = getStockForProduct(productId);
  const cityStock = stocks.find(s => s.city === geoState.city);
  const isOutOfStock = !cityStock || cityStock.quantity === 0;
  const isLowStock = cityStock && cityStock.quantity > 0 && cityStock.quantity < 5;

  const analogs = findAnalogs(productId, 4);

  if (analogs.length === 0) return null;

  return (
    <div className="mt-8">
      {/* Header with status */}
      <div className="flex items-center gap-3 mb-4">
        {isOutOfStock ? (
          <>
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h3 className="text-lg font-semibold text-[#1A1A1A]">
              Товара нет в наличии в {geoState.city}
            </h3>
          </>
        ) : isLowStock ? (
          <>
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            <h3 className="text-lg font-semibold text-[#1A1A1A]">
              Осталось мало — аналоги на замену
            </h3>
          </>
        ) : (
          <>
            <CheckCircle2 className="w-5 h-5 text-[#D5141D]" />
            <h3 className="text-lg font-semibold text-[#1A1A1A]">Похожие товары</h3>
          </>
        )}
      </div>

      {isOutOfStock && (
        <p className="text-sm text-[#666] mb-4">
          Предлагаем аналогичные продукты, которые есть в наличии и подходят по характеристикам:
        </p>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {analogs.map((match) => {
          const p = match.product;
          const analogStocks = getStockForProduct(p.id);
          const analogCityStock = analogStocks.find(s => s.city === geoState.city);
          const analogAvailable = analogCityStock && analogCityStock.quantity > 0;
          const packaging = p.packaging[0];

          return (
            <div
              key={p.id}
              className="border border-[#E0E0E0] rounded-lg p-4 hover:border-[#D5141D] hover:shadow-md transition-all"
            >
              <div className="flex gap-3">
                <Link to={`/product/${p.id}`} className="flex-shrink-0">
                  <div className="w-16 h-16 bg-[#F9F9F9] rounded flex items-center justify-center">
                    <img src={p.image} alt={p.name} className="max-h-full max-w-full object-contain p-1" />
                  </div>
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${p.id}`}>
                    <h4 className="text-sm font-medium text-[#1A1A1A] hover:text-[#D5141D] line-clamp-2">
                      {p.name}
                    </h4>
                  </Link>

                  {/* Match badges */}
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {match.matchReasons.slice(0, 3).map((reason, i) => (
                      <span
                        key={i}
                        className="text-[10px] px-1.5 py-0.5 bg-red-50 text-[#D5141D] rounded"
                      >
                        {reason}
                      </span>
                    ))}
                  </div>

                  {/* Match score */}
                  <div className="flex items-center gap-1 mt-1">
                    <div className="flex-1 h-1.5 bg-[#E0E0E0] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#D5141D] rounded-full transition-all"
                        style={{ width: `${match.matchScore}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-[#999]">{match.matchScore}%</span>
                  </div>

                  {/* Stock status */}
                  {analogAvailable ? (
                    <span className="text-xs text-green-600 flex items-center gap-1 mt-1">
                      <CheckCircle2 className="w-3 h-3" />
                      {analogCityStock!.city} — {analogCityStock!.quantity > 20 ? '>20' : analogCityStock!.quantity} шт.
                    </span>
                  ) : (
                    <span className="text-xs text-red-500 mt-1">Нет в {geoState.city}</span>
                  )}

                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm font-bold text-[#1A1A1A]">
                      {packaging?.price?.toLocaleString('ru-RU') || p.price.toLocaleString('ru-RU')} ₽
                    </span>
                    <Button
                      size="sm"
                      onClick={() => packaging && addItem(p, packaging, 1)}
                      disabled={!analogAvailable}
                      className="h-7 text-xs bg-[#D5141D] hover:bg-[#B01018]"
                    >
                      В корзину
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Link
        to="/catalog"
        className="inline-flex items-center gap-1 text-sm text-[#D5141D] hover:underline mt-4"
      >
        Смотреть все аналоги в каталоге
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}
