import { Link } from 'react-router-dom';

interface MegaMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const motorSubcategories = {
  'Вязкость': ['0W-20', '0W-30', '0W-40', '5W-20', '5W-30', '5W-40', '10W-30', '10W-40', '15W-40'],
  'Классификация по API': ['SN', 'SN/CF', 'SL/CF', 'CI-4/SL', 'CJ-4', 'SP'],
  'Вид': ['Минеральные', 'Полусинтетические', 'Синтетические'],
  'Вид двигателя': ['Бензиновые 4-х тактные', 'Дизельные'],
  'Линейка': ['Genesis Special', 'Luxe', 'Авангард', 'Генезис', 'Супер'],
};

const transmissionSubcategories = {
  'Вязкость': ['75W-90', '80W-140', '80W-90', '85W-140'],
  'Классификация по API': ['GL-4', 'GL-4/5', 'GL-5'],
  'Вид': ['Минеральные', 'Полусинтетические', 'Синтетические'],
};

const industrialSubcategories = {
  'Вязкость': ['32', '46', '68', '100', '150', '220'],
  'Назначение': ['Гидравлические масла', 'Компрессорные масла', 'Редукторные масла'],
  'Вид': ['Минеральные', 'Полусинтетические'],
  'Линейка': ['ВМГЗ', 'Гейзер', 'Стабио', 'Стило', 'Суппорто'],
};

const otherSubcategories = {
  'Охлаждающие жидкости': ['Канистра 5 кг', 'Канистра 10 кг', 'Бочка 220 кг'],
  'Тормозные жидкости': ['DOT-3', 'DOT-4', 'DOT-4 class 6'],
  'Пластичные смазки': ['Картуш 0.4 кг', 'Бидон 18 кг', 'Бочка 216.5 л'],
};

export function MegaMenu({ isOpen, onClose }: MegaMenuProps) {
  if (!isOpen) return null;

  return (
    <div
      className="absolute top-full left-0 right-0 bg-white shadow-[0_8px_24px_rgba(0,0,0,0.12)] z-50 border-t border-[#E0E0E0]"
      onMouseEnter={() => {}}
      onMouseLeave={onClose}
    >
      <div className="max-w-[1400px] mx-auto px-5 py-6">
        <div className="grid grid-cols-4 gap-6">
          {/* Моторные масла */}
          <div>
            <Link to="/catalog?category=motor" className="font-semibold text-[#1A1A1A] hover:text-[#D5141D] transition-colors mb-3 block">
              Моторные масла
            </Link>
            {Object.entries(motorSubcategories).map(([group, items]) => (
              <div key={group} className="mb-3">
                <span className="text-xs text-[#666666] font-medium">{group}</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {items.map((item) => (
                    <Link
                      key={item}
                      to={`/catalog?category=motor&filter=${encodeURIComponent(item)}`}
                      className="text-xs text-[#1A1A1A] hover:text-[#D5141D] transition-colors"
                    >
                      {item}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Трансмиссионные */}
          <div>
            <Link to="/catalog?category=transmission" className="font-semibold text-[#1A1A1A] hover:text-[#D5141D] transition-colors mb-3 block">
              Трансмиссионные масла
            </Link>
            {Object.entries(transmissionSubcategories).map(([group, items]) => (
              <div key={group} className="mb-3">
                <span className="text-xs text-[#666666] font-medium">{group}</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {items.map((item) => (
                    <Link
                      key={item}
                      to={`/catalog?category=transmission&filter=${encodeURIComponent(item)}`}
                      className="text-xs text-[#1A1A1A] hover:text-[#D5141D] transition-colors"
                    >
                      {item}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Индустриальные */}
          <div>
            <Link to="/catalog?category=industrial" className="font-semibold text-[#1A1A1A] hover:text-[#D5141D] transition-colors mb-3 block">
              Индустриальные масла
            </Link>
            {Object.entries(industrialSubcategories).map(([group, items]) => (
              <div key={group} className="mb-3">
                <span className="text-xs text-[#666666] font-medium">{group}</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {items.map((item) => (
                    <Link
                      key={item}
                      to={`/catalog?category=industrial&filter=${encodeURIComponent(item)}`}
                      className="text-xs text-[#1A1A1A] hover:text-[#D5141D] transition-colors"
                    >
                      {item}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Другие продукты */}
          <div>
            <span className="font-semibold text-[#1A1A1A] mb-3 block">Другие продукты</span>
            {Object.entries(otherSubcategories).map(([group, items]) => (
              <div key={group} className="mb-3">
                <Link to={`/catalog?category=${encodeURIComponent(group)}`} className="text-xs text-[#666666] font-medium hover:text-[#D5141D]">
                  {group}
                </Link>
                <div className="flex flex-wrap gap-1 mt-1">
                  {items.map((item) => (
                    <span key={item} className="text-xs text-[#1A1A1A]">{item}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
