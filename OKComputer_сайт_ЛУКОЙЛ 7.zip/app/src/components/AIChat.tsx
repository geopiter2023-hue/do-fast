import { useState, useRef, useEffect } from 'react';
import { X, Bot, Send, User, Sparkles, Loader2 } from 'lucide-react';
import type { Product } from '@/types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
}

interface AIChatProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

// Simulated AI responses based on product info
function generateAIResponse(product: Product, userMessage: string): string {
  const msg = userMessage.toLowerCase();

  if (msg.includes('вязк') || msg.includes('5w') || msg.includes('10w')) {
    return `Масло ${product.name} имеет вязкость ${product.viscosity}. Это означает, что оно обеспечивает оптимальную текучесть при низких температурах (${product.viscosity.split('-')[0]}) и стабильную защиту при высоких (${product.viscosity.split('-')[1]}). Подходит для большинства современных двигателей.`;
  }

  if (msg.includes('api') || msg.includes('класс') || msg.includes('допуск')) {
    return `Классификация API данного масла — ${product.api}. Это соответствует современным требованиям к защите двигателя. Рекомендую проверить допуски производителя вашего автомобиля для полной совместимости.`;
  }

  if (msg.includes('синтет') || msg.includes('минер') || msg.includes('полусинт')) {
    const typeMap: Record<string, string> = {
      synthetic: 'синтетическое',
      'semi-synthetic': 'полусинтетическое',
      mineral: 'минеральное',
    };
    const typeDesc: Record<string, string> = {
      synthetic: 'Полностью синтетическая формула обеспечивает максимальную защиту, увеличенный интервал замены и лучшую работу при экстремальных температурах.',
      'semi-synthetic': 'Полусинтетическая основа — оптимальное соотношение цены и качества. Хорошая защита для стандартных режимов эксплуатации.',
      mineral: 'Минеральная основа — классическое решение для простых двигателей и бюджетного сегмента. Рекомендуется более частая замена.',
    };
    return `${product.name} — ${typeMap[product.type] || product.type} масло. ${typeDesc[product.type] || ''}`;
  }

  if (msg.includes('фасов') || msg.includes('объём') || msg.includes('литр') || msg.includes('бочк')) {
    const packs = product.packaging.map(p => `${p.name} (${p.price.toLocaleString('ru-RU')} ₽)`).join(', ');
    return `Данный продукт доступен в следующих фасовках: ${packs}. Выберите подходящий объём в зависимости от ваших потребностей — канистры для розничного использования, бочки для СТО.`;
  }

  if (msg.includes('цена') || msg.includes('стоим') || msg.includes('дорог')) {
    return `Цена ${product.name} начинается от ${product.price.toLocaleString('ru-RU')} ₽ за ${product.packaging[0]?.name || 'единицу'}. Для оптовых заказов от 10 бочек предусмотрены специальные цены — запросите коммерческое предложение.`;
  }

  if (msg.includes('налич') || msg.includes('склад') || msg.includes('остаток')) {
    return `Остатки по складам обновляются в реальном времени. Выберите ваш город в шапке сайта, чтобы увидеть актуальное наличие. При отсутствии товара на ближайшем складе система автоматически предложит аналоги.`;
  }

  if (msg.includes('подойдёт') || msg.includes('совместим') || msg.includes('можно')) {
    return `Для точного определения совместимости рекомендую добавить ваш автомобиль в гараж — система автоматически подберёт подходящие масла. Масло ${product.name} с вязкостью ${product.viscosity} и классом ${product.api} подходит для большинства современных двигателей.`;
  }

  if (msg.includes('замен') || msg.includes('интервал') || msg.includes('часто')) {
    return `Рекомендуемый интервал замены зависит от типа масла и условий эксплуатации:\n• Синтетические: 10,000–15,000 км\n• Полусинтетические: 7,000–10,000 км\n• Минеральные: 5,000–7,000 км\n${product.name} (${product.type === 'synthetic' ? 'синтетика' : product.type === 'semi-synthetic' ? 'полусинтетика' : 'минералка'}) — следуйте рекомендациям производителя вашего автомобиля.`;
  }

  // Default response
  const defaults = [
    `${product.name} — высококачественное ${product.type === 'synthetic' ? 'синтетическое' : product.type === 'semi-synthetic' ? 'полусинтетическое' : 'минеральное'} масло класса ${product.api} с вязкостью ${product.viscosity}. ${product.description.slice(0, 100)}...`,
    `Продукт ${product.name} соответствует спецификации ${product.api} и подходит для широкого спектра двигателей. Рекомендую уточнить допуски вашего автопроизводителя.`,
    `Для получения паспорта качества и сертификатов на ${product.name} свяжитесь с менеджером через форму коммерческого предложения или напишите на help@b2b.lukoil-shop.ru.`,
  ];
  return defaults[Math.floor(Math.random() * defaults.length)];
}

export function AIChat({ product, isOpen, onClose }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: `Здравствуйте! Я AI-консультант по продукции ЛУКОЙЛ. Спрашивайте о характеристиках, совместимости, фасовках и ценах — я помогу подобрать оптимальное решение для вашего бизнеса.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: input.trim(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI thinking delay
    setTimeout(() => {
      const response = generateAIResponse(product, userMsg.text);
      const botMsg: Message = {
        id: `b_${Date.now()}`,
        role: 'assistant',
        text: response,
      };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 800 + Math.random() * 700);
  };

  const quickQuestions = [
    'Какая вязкость?',
    'Подойдёт для дизеля?',
    'Какие фасовки?',
    'Есть в наличии?',
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-end justify-end sm:items-center sm:justify-center">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative bg-white rounded-t-xl sm:rounded-xl w-full sm:w-[420px] sm:mx-4 shadow-2xl flex flex-col max-h-[80vh] sm:max-h-[600px] overflow-hidden">
        {/* Header */}
        <div className="bg-[#D5141D] text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold">AI-консультант ЛУКОЙЛ</div>
              <div className="text-[10px] text-white/70 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Подбор продуктов и консультации
              </div>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product context */}
        <div className="bg-[#F5F5F5] px-4 py-2 flex items-center gap-2 text-xs border-b border-[#E0E0E0]">
          <img src={product.image} alt="" className="w-6 h-6 object-contain" />
          <span className="text-[#666] truncate">{product.name} — {product.viscosity} / {product.api}</span>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-6 h-6 bg-[#D5141D] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Bot className="w-3.5 h-3.5 text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-lg px-3 py-2 text-sm whitespace-pre-line ${
                  msg.role === 'user'
                    ? 'bg-[#D5141D] text-white'
                    : 'bg-[#F5F5F5] text-[#1A1A1A]'
                }`}
              >
                {msg.text}
              </div>
              {msg.role === 'user' && (
                <div className="w-6 h-6 bg-[#2B2F3B] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5 text-white" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-2 items-center">
              <div className="w-6 h-6 bg-[#D5141D] rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="bg-[#F5F5F5] rounded-lg px-3 py-2 flex items-center gap-1">
                <Loader2 className="w-4 h-4 animate-spin text-[#999]" />
                <span className="text-xs text-[#999]">Думаю...</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick questions */}
        <div className="px-4 py-2 flex flex-wrap gap-1.5 border-t border-[#E0E0E0]">
          {quickQuestions.map((q) => (
            <button
              key={q}
              onClick={() => {
                setInput(q);
              }}
              className="text-[11px] px-2.5 py-1 border border-[#E0E0E0] rounded-full text-[#666] hover:border-[#D5141D] hover:text-[#D5141D] transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="p-3 border-t border-[#E0E0E0] flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ваш вопрос о продукте..."
            className="flex-1 h-10 px-3 border border-[#E0E0E0] rounded text-sm focus:outline-none focus:border-[#D5141D]"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="w-10 h-10 bg-[#D5141D] hover:bg-[#B01018] disabled:bg-[#CCC] rounded flex items-center justify-center transition-colors"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
