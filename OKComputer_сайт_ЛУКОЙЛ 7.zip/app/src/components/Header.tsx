import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, User, ShoppingCart, FileText, ChevronDown, Menu, X, MapPin, Home, Package, Award } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { useGarage } from '@/hooks/useGarage';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useCashback } from '@/hooks/useCashback';
import { useScrollHeader } from '@/hooks/useScrollHeader';
import { mainNav } from '@/data/navigation';
import { MegaMenu } from './MegaMenu';
import { AuthModal } from './AuthModal';
import { CityModal } from './CityModal';

export function Header() {
  const location = useLocation();
  const { state: authState, openModal } = useAuth();
  const { totalCount } = useCart();
  const { vehicleCount } = useGarage();
  const { state: geoState, openModal: openCityModal } = useGeolocation();
  const { state: cashbackState } = useCashback();
  const isSticky = useScrollHeader(100);
  const [showMegaMenu, setShowMegaMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <header
        className={`bg-white border-b border-[#e2e8f0] transition-shadow duration-200 z-50 ${
          isSticky ? 'fixed top-0 left-0 right-0 shadow-sm' : 'relative'
        }`}
      >
        <div className="max-w-[1400px] mx-auto px-5">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex-shrink-0">
              <div className="flex flex-col">
                <div className="flex items-center gap-1">
                  <div className="w-8 h-8 bg-[#dc2626] rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">Л</span>
                  </div>
                  <span className="text-xl font-bold tracking-tight text-[#1e293b]">ЛУКОЙЛ</span>
                </div>
                <span className="text-[10px] font-semibold tracking-wider text-[#64748b] uppercase mt-0.5">
                  СМАЗОЧНЫЕ МАТЕРИАЛЫ
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {mainNav.map((item) => (
                <div
                  key={item.href}
                  className="relative"
                  onMouseEnter={() => item.label === 'Каталог' && setShowMegaMenu(true)}
                  onMouseLeave={() => item.label === 'Каталог' && setShowMegaMenu(false)}
                >
                  <Link
                    to={item.href}
                    className={`text-sm flex items-center gap-1 py-6 transition-colors hover:text-[#2563eb] ${
                      location.pathname === item.href ? 'text-[#2563eb] border-b-2 border-[#2563eb]' : 'text-[#1e293b]'
                    }`}
                  >
                    {item.label}
                    {item.label === 'Каталог' && <ChevronDown className="w-4 h-4" />}
                  </Link>
                </div>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
              {/* Geolocation */}
              <button
                onClick={openCityModal}
                className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors"
                title="Изменить город"
              >
                <MapPin className="w-4 h-4 text-[#2563eb]" />
                <span className="max-w-[100px] truncate">{geoState.city}</span>
              </button>

              {/* Search */}
              <button className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors">
                <Search className="w-5 h-5" />
                <span>Поиск</span>
              </button>

              {/* Garage */}
              <Link
                to="/garage"
                className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors relative"
              >
                <Home className="w-5 h-5" />
                <span>Гараж</span>
                {vehicleCount > 0 && (
                  <span className="absolute -top-2 -right-3 bg-[#2563eb] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                    {vehicleCount}
                  </span>
                )}
              </Link>

              {/* ECOM — highlighted with red square */}
              <Link
                to="/ecom"
                className="hidden md:flex items-center gap-1.5 text-sm text-white bg-[#dc2626] hover:bg-[#b91c1c] px-3 py-1.5 rounded-lg transition-colors font-medium"
              >
                <Package className="w-4 h-4" />
                <span>ECOM</span>
              </Link>

              {/* Auth */}
              {authState.isAuthenticated ? (
                <div className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b]">
                  <User className="w-5 h-5" />
                  <span>{authState.user?.name}</span>
                </div>
              ) : (
                <button
                  onClick={() => openModal('login')}
                  className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors"
                >
                  <User className="w-5 h-5" />
                  <span>Войти</span>
                </button>
              )}

              {/* Cashback Points */}
              {authState.isAuthenticated && (
                <div className="hidden md:flex items-center gap-1.5 text-sm text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                  <Award className="w-4 h-4 text-amber-500" />
                  <span className="font-medium">{cashbackState.points.toLocaleString('ru-RU')}</span>
                </div>
              )}

              {/* Cart */}
              <Link to="/cart" className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors relative">
                <ShoppingCart className="w-5 h-5" />
                <span>Корзина</span>
                {totalCount > 0 && (
                  <span className="absolute -top-2 -right-3 bg-[#2563eb] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                    {totalCount}
                  </span>
                )}
              </Link>

              {/* Commercial Offer */}
              <Link
                to="/commercial-offer"
                className="hidden md:flex items-center gap-1.5 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors"
              >
                <FileText className="w-5 h-5" />
                <span>Получить КП</span>
              </Link>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mega Menu */}
        <MegaMenu isOpen={showMegaMenu} onClose={() => setShowMegaMenu(false)} />
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[109px] bg-white z-40 p-5">
          <nav className="flex flex-col gap-4">
            {/* City */}
            <button
              onClick={() => { openCityModal(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-lg py-2 border-b border-[#e2e8f0] text-[#1e293b]"
            >
              <MapPin className="w-5 h-5 text-[#2563eb]" />
              {geoState.city}
            </button>
            {mainNav.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`text-lg py-2 border-b border-[#e2e8f0] ${
                  location.pathname === item.href ? 'text-[#2563eb]' : 'text-[#1e293b]'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/garage"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 text-lg py-2 border-b border-[#e2e8f0] text-[#1e293b]"
            >
              <Home className="w-5 h-5" />
              Гараж {vehicleCount > 0 && `(${vehicleCount})`}
            </Link>
            <Link
              to="/ecom"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 text-lg py-2 border-b border-[#e2e8f0] text-white bg-[#dc2626] px-3 rounded-lg"
            >
              <Package className="w-5 h-5" />
              ECOM
            </Link>
            <Link
              to="/cart"
              onClick={() => setMobileMenuOpen(false)}
              className="text-lg py-2 text-[#1e293b]"
            >
              Корзина {totalCount > 0 && `(${totalCount})`}
            </Link>
          </nav>
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal />

      {/* City Modal */}
      <CityModal />

      {/* Spacer for sticky header */}
      {isSticky && <div className="h-20" />}
    </>
  );
}
