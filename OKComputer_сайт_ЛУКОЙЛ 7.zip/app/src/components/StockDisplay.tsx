import { useState } from 'react';
import { MapPin, ChevronDown, ChevronUp, Circle } from 'lucide-react';
import { getStockForProduct } from '@/data/warehouses';
import { useGeolocation } from '@/hooks/useGeolocation';

interface StockDisplayProps {
  productId: string;
  compact?: boolean;
}

export function StockDisplay({ productId, compact = false }: StockDisplayProps) {
  const { state: geoState } = useGeolocation();
  const stocks = getStockForProduct(productId);
  const [expanded, setExpanded] = useState(false);

  const nearestStock = stocks.find(s => s.city === geoState.city) || stocks.find(s => s.quantity > 0);
  const isAvailable = nearestStock && nearestStock.quantity > 0;

  if (compact) {
    return (
      <div className="text-xs text-[#666] mt-1">
        {isAvailable ? (
          <span className="flex items-center gap-1">
            <Circle className="w-2 h-2 fill-green-500 text-green-500" />
            <span className="text-green-600 font-medium">
              {nearestStock.quantity > 20 ? '>20 шт.' : `${nearestStock.quantity} шт.`} — {nearestStock.availableDate}
            </span>
          </span>
        ) : (
          <span className="flex items-center gap-1 text-red-500">
            <Circle className="w-2 h-2 fill-red-500 text-red-500" />
            Нет в наличии
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="mt-3">
      <div className="flex items-center gap-2 text-sm mb-2">
        <MapPin className="w-3.5 h-3.5 text-[#D5141D]" />
        <span className="text-[#666]">Остатки по складам:</span>
        <span className="text-[#1A1A1A] font-medium">{geoState.city}</span>
      </div>

      {isAvailable ? (
        <div className="bg-green-50 border border-green-200 rounded px-3 py-2 text-sm mb-2">
          <span className="text-green-700 font-medium">
            {nearestStock.city} — {nearestStock.quantity > 20 ? '>20 шт.' : `${nearestStock.quantity} шт.`} ({nearestStock.availableDate})
          </span>
        </div>
      ) : (
        <div className="bg-red-50 border border-red-200 rounded px-3 py-2 text-sm mb-2">
          <span className="text-red-600 font-medium">Нет в наличии в {geoState.city}</span>
        </div>
      )}

      {/* Expandable full stock list */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1 text-xs text-[#D5141D] hover:underline"
      >
        Остатки по всем складам
        {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>

      {expanded && (
        <div className="mt-2 space-y-1 pl-2">
          {stocks.map((s) => (
            <div key={s.city} className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5">
                <Circle
                  className={`w-2 h-2 ${
                    s.quantity > 20
                      ? 'fill-green-500 text-green-500'
                      : s.quantity > 0
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'fill-red-400 text-red-400'
                  }`}
                />
                {s.city}
              </span>
              <span className={s.quantity === 0 ? 'text-red-500' : 'text-[#666]'}>
                {s.quantity > 20 ? `${s.quantity} шт.` : s.quantity > 0 ? `${s.quantity} шт.` : 'нет'} — {s.availableDate}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
