import { MessageCircle } from 'lucide-react';

export function ChatButton() {
  return (
    <button
      onClick={() => alert('Чат с менеджером скоро будет доступен!')}
      className="fixed bottom-5 right-5 z-40 w-14 h-14 bg-[#D5141D] hover:bg-[#B01018] rounded-full flex items-center justify-center shadow-lg transition-colors"
      aria-label="Открыть чат"
    >
      <MessageCircle className="w-6 h-6 text-white" />
    </button>
  );
}
