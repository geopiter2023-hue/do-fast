import { useState } from 'react';
import { X, Car, Truck, Bus, Bike, Construction } from 'lucide-react';
import { useGarage } from '@/hooks/useGarage';
import { vehicleTypeOptions, popularBrands, years } from '@/types/garage';
import type { VehicleType } from '@/types/garage';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const typeIcons: Record<VehicleType, React.ReactNode> = {
  passenger: <Car className="w-6 h-6" />,
  truck: <Truck className="w-6 h-6" />,
  bus: <Bus className="w-6 h-6" />,
  trailer: <Truck className="w-6 h-6" />,
  special: <Construction className="w-6 h-6" />,
  moto: <Bike className="w-6 h-6" />,
};

interface AddVehicleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AddVehicleModal({ isOpen, onClose }: AddVehicleModalProps) {
  const { addVehicle } = useGarage();
  const [step, setStep] = useState<'type' | 'details'>('type');
  const [selectedType, setSelectedType] = useState<VehicleType | null>(null);
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [plate, setPlate] = useState('');
  const [vin, setVin] = useState('');
  const [engineType, setEngineType] = useState<string>('');

  const handleSelectType = (type: VehicleType) => {
    setSelectedType(type);
    setStep('details');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType || !brand || !model || !year) return;

    const typeLabel = vehicleTypeOptions.find((v) => v.value === selectedType)?.label || '';
    addVehicle({
      type: selectedType,
      typeLabel,
      brand,
      model,
      year: Number(year),
      plate: plate || undefined,
      vin: vin || undefined,
      engineType: (engineType as 'gasoline' | 'diesel' | 'hybrid' | 'electric') || undefined,
    });

    // Reset
    setStep('type');
    setSelectedType(null);
    setBrand('');
    setModel('');
    setYear('');
    setPlate('');
    setVin('');
    setEngineType('');
    onClose();
  };

  const handleClose = () => {
    setStep('type');
    setSelectedType(null);
    setBrand('');
    setModel('');
    setYear('');
    setPlate('');
    setVin('');
    setEngineType('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={handleClose} />
      <div className="relative bg-white rounded-lg w-full max-w-[520px] mx-4 shadow-xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#E0E0E0]">
          <h3 className="text-lg font-semibold text-[#1A1A1A]">
            {step === 'type' ? 'Добавление авто в гараж' : 'Укажите параметры'}
          </h3>
          <button onClick={handleClose} className="text-[#999] hover:text-[#1A1A1A] transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 p-5">
          {step === 'type' ? (
            /* Step 1: Select vehicle type */
            <div className="space-y-2">
              <p className="text-sm text-[#666] mb-3">Выберите тип транспорта:</p>
              {vehicleTypeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleSelectType(option.value)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 rounded border border-[#E0E0E0] hover:border-[#D5141D] hover:bg-red-50 transition-all text-left"
                >
                  <span className="text-[#D5141D]">{typeIcons[option.value]}</span>
                  <span className="text-[#1A1A1A] font-medium">{option.label}</span>
                </button>
              ))}
            </div>
          ) : (
            /* Step 2: Vehicle details */
            <form onSubmit={handleSubmit} className="space-y-4">
              <button
                type="button"
                onClick={() => setStep('type')}
                className="text-sm text-[#D5141D] hover:underline mb-2"
              >
                ← Назад к выбору типа
              </button>

              <div>
                <label className="block text-sm text-[#666] mb-1">Марка *</label>
                <Select value={brand} onValueChange={setBrand}>
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="Выберите марку" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[200px]">
                    {popularBrands.map((b) => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm text-[#666] mb-1">Модель *</label>
                <Input
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="Например: Camry"
                  required
                  className="h-10"
                />
              </div>

              <div>
                <label className="block text-sm text-[#666] mb-1">Год выпуска *</label>
                <Select value={year} onValueChange={setYear}>
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="Выберите год" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[200px]">
                    {years.map((y) => (
                      <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm text-[#666] mb-1">Тип двигателя</label>
                <Select value={engineType} onValueChange={setEngineType}>
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="Выберите тип двигателя" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gasoline">Бензиновый</SelectItem>
                    <SelectItem value="diesel">Дизельный</SelectItem>
                    <SelectItem value="hybrid">Гибридный</SelectItem>
                    <SelectItem value="electric">Электрический</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm text-[#666] mb-1">Госномер</label>
                <Input
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  placeholder="А 000 АА 000"
                  className="h-10"
                />
              </div>

              <div>
                <label className="block text-sm text-[#666] mb-1">VIN номер</label>
                <Input
                  value={vin}
                  onChange={(e) => setVin(e.target.value)}
                  placeholder="XWB3K32EDFA000000"
                  className="h-10"
                />
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-[#D5141D] hover:bg-[#B01018] text-base mt-2"
              >
                Добавить в гараж
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
