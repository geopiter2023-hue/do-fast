import { Link, useLocation } from 'react-router-dom';
import { sidebarMenuItems } from '@/data/navigation';

interface SidebarMenuProps {
  activeId?: string;
}

export function SidebarMenu({ activeId }: SidebarMenuProps) {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <nav className="w-full lg:w-[260px] flex-shrink-0">
      <ul className="space-y-0">
        {sidebarMenuItems.map((item) => {
          const isActive = activeId === item.id || currentPath === item.href;
          return (
            <li key={item.id}>
              <Link
                to={item.href}
                className={`block px-4 py-3 text-sm transition-colors ${
                  isActive
                    ? 'bg-[#D5141D] text-white'
                    : 'text-[#1A1A1A] hover:bg-[#F5F5F5]'
                }`}
              >
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
