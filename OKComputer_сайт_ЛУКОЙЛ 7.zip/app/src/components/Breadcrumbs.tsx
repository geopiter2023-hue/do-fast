import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export function Breadcrumbs({ items }: BreadcrumbsProps) {
  return (
    <nav className="bg-white py-3">
      <div className="max-w-[1400px] mx-auto px-5">
        <ol className="flex items-center flex-wrap gap-1 text-sm">
          <li>
            <Link to="/" className="text-[#64748b] hover:text-[#2563eb] transition-colors">
              Главная страница
            </Link>
          </li>
          {items.map((item, index) => (
            <li key={index} className="flex items-center gap-1">
              <ChevronRight className="w-4 h-4 text-[#94a3b8]" />
              {item.href ? (
                <Link to={item.href} className="text-[#64748b] hover:text-[#2563eb] transition-colors">
                  {item.label}
                </Link>
              ) : (
                <span className="text-[#1e293b]">{item.label}</span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
}
