import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ChevronDown, ChevronUp, ArrowRight } from 'lucide-react';
import type { Product } from '@/types';
import { useCart } from '@/hooks/useCart';
import { useGeolocation } from '@/hooks/useGeolocation';
import { getStockForProduct } from '@/data/warehouses';
import { findAnalogs } from '@/data/analogs';
import { getStockLabel } from '@/data/stockLabels';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ProductCardProps {
  product: Product;
  compact?: boolean;
}

export function ProductCard({ product, compact = false }: ProductCardProps) {
  const { addItem } = useCart();
  const { state: geoState } = useGeolocation();
  const [selectedPackaging, setSelectedPackaging] = useState(product.packaging[0]?.id || '');
  const [showAnalogs, setShowAnalogs] = useState(false);

  const packaging = product.packaging.find((p) => p.id === selectedPackaging) || product.packaging[0];
  const stocks = getStockForProduct(product.id);
  const cityStock = stocks.find((s) => s.city === geoState.city);
  const hasStock = cityStock ? cityStock.quantity > 0 : stocks.some((s) => s.quantity > 0);
  const analogs = findAnalogs(product.id, 3);

  // Text-based stock label
  const stockLabel = getStockLabel(cityStock?.quantity || 0);

  const handleAddToCart = () => {
    if (packaging && hasStock) {
      addItem(product, packaging, 1);
    }
  };

  if (compact) {
    return (
      <div className="bg-white border border-[#e2e8f0] rounded p-4 hover:shadow-[0_4px_12px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 flex flex-col">
        <Link to={`/product/${product.id}`} className="block flex-1">
          <div className="aspect-square mb-3 flex items-center justify-center bg-white rounded relative">
            <img src={product.image} alt={product.name} className="max-h-full max-w-full object-contain p-2" />
            {!hasStock && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded">
                <span className="text-white text-xs font-medium bg-[#94a3b8] px-2 py-1 rounded">Нет в наличии</span>
              </div>
            )}
          </div>
          <span className="text-xs text-[#64748b]">Артикул: {product.article}</span>
          <h3 className="text-sm font-medium text-[#1e293b] mt-1 line-clamp-2 min-h-[40px]">{product.name}</h3>
          <div className="mt-2 text-xs text-[#64748b]">
            <span>Вид: {product.type === 'synthetic' ? 'Синтетические' : product.type === 'semi-synthetic' ? 'Полусинтетические' : 'Минеральные'}</span>
          </div>

          {/* Text stock label */}
          <div className="mt-2">
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${stockLabel.bgColor} ${stockLabel.color}`}>
              {stockLabel.text}
            </span>
          </div>
        </Link>

        {/* Analogs when no stock */}
        {analogs.length > 0 && !hasStock && (
          <div className="mt-2">
            <button onClick={() => setShowAnalogs(!showAnalogs)} className="text-xs text-[#2563eb] hover:underline flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Возможные замены
              {showAnalogs ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {showAnalogs && (
              <div className="mt-2 space-y-2">
                {analogs.map(({ product: aProduct, matchScore }) => (
                  <Link key={aProduct.id} to={`/product/${aProduct.id}`} className="flex items-center gap-2 p-2 bg-[#FFF8F0] rounded hover:bg-[#FFF0E0] transition-colors">
                    <img src={aProduct.image} alt="" className="w-8 h-8 object-contain" />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-[#1e293b] truncate">{aProduct.name}</div>
                      <div className="text-xs text-[#2563eb]">{matchScore}% совпадение</div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-[#94a3b8] flex-shrink-0" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="mt-3">
          {product.packaging.length > 1 && (
            <Select value={selectedPackaging} onValueChange={setSelectedPackaging}>
              <SelectTrigger className="h-8 text-xs mb-2"><SelectValue /></SelectTrigger>
              <SelectContent>
                {product.packaging.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold text-[#1e293b]">
              {packaging?.price?.toLocaleString('ru-RU') || product.price.toLocaleString('ru-RU')} ₽
            </span>
            <Button onClick={handleAddToCart} disabled={!hasStock} className="h-8 px-4 text-sm bg-[#2563eb] hover:bg-[#1d4ed8] disabled:bg-[#cbd5e1]">
              {hasStock ? 'Купить' : 'Нет в наличии'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[#e2e8f0] rounded p-4 flex flex-col sm:flex-row gap-4 hover:shadow-[0_4px_12px_rgba(0,0,0,0.08)] transition-all duration-300">
      <Link to={`/product/${product.id}`} className="flex-shrink-0">
        <div className="w-full sm:w-40 h-40 flex items-center justify-center bg-white rounded relative">
          <img src={product.image} alt={product.name} className="max-h-full max-w-full object-contain p-2" />
          {!hasStock && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center rounded">
              <span className="text-white text-sm font-medium">Нет в наличии</span>
            </div>
          )}
        </div>
      </Link>

      <div className="flex-1">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-base font-medium text-[#1e293b] hover:text-[#2563eb] transition-colors">{product.name}</h3>
        </Link>
        <span className="text-xs text-[#64748b]">Артикул: {product.article}</span>

        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm text-[#64748b]">
          <span>Вид: {product.type === 'synthetic' ? 'Синтетические' : product.type === 'semi-synthetic' ? 'Полусинтетические' : 'Минеральные'}</span>
          <span>Вид транспорта: {product.vehicleType === 'passenger' ? 'Легковые автомобили' : product.vehicleType === 'commercial' ? 'Коммерческий транспорт' : 'Индустриальное'}</span>
        </div>

        {/* Text stock label */}
        <div className="mt-2">
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${stockLabel.bgColor} ${stockLabel.color}`}>
            {stockLabel.text}
          </span>
        </div>

        {analogs.length > 0 && !hasStock && (
          <div className="mt-2">
            <button onClick={() => setShowAnalogs(!showAnalogs)} className="text-xs text-[#2563eb] hover:underline flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Возможные замены ({analogs.length})
              {showAnalogs ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {showAnalogs && (
              <div className="mt-2 space-y-2">
                {analogs.map(({ product: aProduct, matchScore }) => (
                  <Link key={aProduct.id} to={`/product/${aProduct.id}`} className="flex items-center gap-3 p-3 bg-[#FFF8F0] rounded hover:bg-[#FFF0E0] transition-colors">
                    <img src={aProduct.image} alt="" className="w-10 h-10 object-contain" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-[#1e293b]">{aProduct.name}</div>
                      <div className="text-xs text-[#64748b]">Вязкость {aProduct.viscosity}, {aProduct.api}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-sm font-bold text-[#2563eb]">{matchScore}%</div>
                      <div className="text-xs text-[#64748b]">совпадение</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#94a3b8]" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="mt-3">
          <span className="text-xs text-[#64748b]">Фасовка:</span>
          <div className="flex flex-wrap gap-2 mt-1">
            {product.packaging.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedPackaging(p.id)}
                className={`px-3 py-1.5 text-xs rounded border transition-colors ${
                  selectedPackaging === p.id ? 'border-[#2563eb] text-[#2563eb] bg-red-50' : 'border-[#e2e8f0] text-[#1e293b] hover:border-[#2563eb]'
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-col justify-between items-end min-w-[140px]">
        <div className="text-right">
          <div className="text-2xl font-bold text-[#1e293b]">
            {packaging?.price?.toLocaleString('ru-RU') || product.price.toLocaleString('ru-RU')} ₽
          </div>
          {product.pricePerUnit !== packaging?.price && (
            <div className="text-sm text-[#64748b]">{product.pricePerUnit.toLocaleString('ru-RU')} ₽/{product.unit}</div>
          )}
        </div>
        <Button onClick={handleAddToCart} disabled={!hasStock} className="mt-3 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:bg-[#cbd5e1] px-6">
          {hasStock ? 'Купить' : 'Нет в наличии'}
        </Button>
      </div>
    </div>
  );
}
