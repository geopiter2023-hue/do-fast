import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Phone, Mail, Clock } from 'lucide-react';
import { footerCatalog, footerBusiness, footerCompany } from '@/data/navigation';

export function Footer() {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Спасибо за подписку!');
    setEmail('');
  };

  return (
    <footer className="bg-[#2B2F3B] text-white">
      <div className="max-w-[1400px] mx-auto px-5 pt-16 pb-8">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Catalog */}
          <div>
            <h4 className="font-semibold text-base mb-5">Каталог продукции</h4>
            <ul className="space-y-3">
              {footerCatalog.map((item) => (
                <li key={item.label}>
                  <Link to={item.href} className="text-sm text-gray-300 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* For Business */}
          <div>
            <h4 className="font-semibold text-base mb-5">Для бизнеса</h4>
            <ul className="space-y-3">
              {footerBusiness.map((item) => (
                <li key={item.label}>
                  <Link to={item.href} className="text-sm text-gray-300 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-base mb-5">Компания</h4>
            <ul className="space-y-3">
              {footerCompany.map((item) => (
                <li key={item.label}>
                  <Link to={item.href} className="text-sm text-gray-300 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-semibold text-base mb-5">Будьте в курсе новостей</h4>
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-mail"
                className="flex-1 h-10 px-3 rounded bg-white/10 border border-white/20 text-white placeholder:text-gray-400 text-sm focus:outline-none focus:border-[#2563eb]"
                required
              />
              <button
                type="submit"
                className="h-10 w-10 rounded bg-[#2563eb] hover:bg-[#1d4ed8] transition-colors flex items-center justify-center flex-shrink-0"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
            <p className="text-xs text-gray-400 mt-3">
              Подписываясь на рассылку, я даю согласие на{' '}
              <a href="/about" className="text-[#2563eb] hover:underline">
                обработку персональных данных
              </a>
              , на получение рекламных сообщений и новостей.
            </p>
          </div>
        </div>

        {/* Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8 border-t border-white/10">
          <div className="flex items-center gap-3">
            <Phone className="w-5 h-5 text-[#2563eb]" />
            <div>
              <span className="text-xs text-gray-400 block">Бесплатная горячая линия:</span>
              <a href="tel:88007008700" className="text-sm font-medium hover:text-[#2563eb] transition-colors">
                8 800 700-8-700
              </a>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="w-5 h-5 text-[#2563eb]" />
            <div>
              <span className="text-xs text-gray-400 block">Электронная почта:</span>
              <a href="mailto:help@b2b.lukoil-shop.ru" className="text-sm font-medium hover:text-[#2563eb] transition-colors">
                help@b2b.lukoil-shop.ru
              </a>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-[#2563eb]" />
            <div>
              <span className="text-xs text-gray-400 block">Обработка заказов и отгрузка товара:</span>
              <span className="text-sm font-medium">9:00 – 18:00, будние дни</span>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-6 border-t border-white/10 gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[#2563eb] flex items-center justify-center">
              <span className="text-white font-bold text-xs">Л</span>
            </div>
            <span className="font-bold text-sm">ЛУКОЙЛ</span>
            <span className="text-[10px] text-gray-400 ml-1">СМАЗОЧНЫЕ МАТЕРИАЛЫ</span>
          </div>

          <p className="text-xs text-gray-400 text-center">
            © 2026 ЛУКОЙЛ. Официальный интернет-магазин смазочных материалов ЛУКОЙЛ для юридических лиц
          </p>

          <Link to="/about" className="text-xs text-gray-400 hover:text-white transition-colors">
            Политика обработки персональных данных
          </Link>
        </div>
      </div>
    </footer>
  );
}
