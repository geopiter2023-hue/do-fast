import { useState } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { SidebarMenu } from '@/components/SidebarMenu';
import { useGarage } from '@/hooks/useGarage';
import { AddVehicleModal } from '@/components/AddVehicleModal';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Car, Truck, Construction, Bike, Bus, Trash2, Wrench, Plus } from 'lucide-react';

const vehicleTypeIcons: Record<string, React.ReactNode> = {
  passenger: <Car className="w-6 h-6" />,
  truck: <Truck className="w-6 h-6" />,
  bus: <Bus className="w-6 h-6" />,
  trailer: <Truck className="w-6 h-6" />,
  special: <Construction className="w-6 h-6" />,
  moto: <Bike className="w-6 h-6" />,
};

export function OilSelectorPage() {
  const { state, removeVehicle } = useGarage();
  const [tab, setTab] = useState<'plate' | 'vin'>('plate');
  const [query, setQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Подбор масла' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <SidebarMenu />

          <div className="flex-1">
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-4">Подбор масла</h1>

            {/* Warning */}
            <div className="bg-[#FFF5F5] border border-[#FFDEDE] rounded p-4 mb-8">
              <p className="text-sm text-[#D5141D]">
                ВНИМАНИЕ! ИДЕТ ОБНОВЛЕНИЕ БАЗЫ ДАННЫХ. ПРИ ВОЗНИКНОВЕНИИ ВОПРОСОВ ОБРАЩАЙТЕСЬ К СПЕЦИАЛИСТАМ ТЕХНИЧЕСКОЙ ПОДДЕРЖКИ:{' '}
                <a href="mailto:MASCLA-SUPPORT@LUKOIL.COM" className="underline">
                  MASLA-SUPPORT@LUKOIL.COM
                </a>
              </p>
            </div>

            {/* My Garage Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-[#1A1A1A]">Мой гараж</h2>
                <Button
                  onClick={() => setShowAddModal(true)}
                  variant="outline"
                  className="h-9 text-sm"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Добавить авто
                </Button>
              </div>

              {state.vehicles.length === 0 ? (
                <div className="bg-[#F5F5F5] rounded-lg p-6 text-center">
                  <Car className="w-10 h-10 text-[#CCC] mx-auto mb-3" />
                  <p className="text-sm text-[#666] mb-3">
                    В гараже нет автомобилей. Добавьте авто для быстрого подбора масел.
                  </p>
                  <Button
                    onClick={() => setShowAddModal(true)}
                    className="bg-[#D5141D] hover:bg-[#B01018] h-9 text-sm"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Добавить автомобиль
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {state.vehicles.map((vehicle) => (
                    <div
                      key={vehicle.id}
                      className="border border-[#E0E0E0] rounded-lg p-4 flex items-start gap-3 hover:border-[#D5141D] transition-colors"
                    >
                      <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center flex-shrink-0 text-[#D5141D]">
                        {vehicleTypeIcons[vehicle.type] || <Car className="w-5 h-5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-[#1A1A1A] truncate">
                          {vehicle.brand} {vehicle.model}
                        </div>
                        <div className="text-xs text-[#666] mt-0.5">
                          {vehicle.typeLabel} &middot; {vehicle.year}
                          {vehicle.engineType && ` &middot; ${vehicle.engineType === 'gasoline' ? 'Бензин' : vehicle.engineType === 'diesel' ? 'Дизель' : vehicle.engineType === 'hybrid' ? 'Гибрид' : 'Электро'}`}
                        </div>
                        <div className="flex gap-2 mt-2">
                          <Button
                            size="sm"
                            className="h-7 text-xs bg-[#D5141D] hover:bg-[#B01018]"
                            onClick={() => alert(`Подбор масла для ${vehicle.brand} ${vehicle.model} ${vehicle.year} г.`)}
                          >
                            <Wrench className="w-3 h-3 mr-1" />
                            Подобрать
                          </Button>
                          <button
                            onClick={() => removeVehicle(vehicle.id)}
                            className="h-7 px-2 text-[#CCC] hover:text-[#D5141D] transition-colors"
                            title="Удалить"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Manual Search */}
            <h2 className="text-lg font-semibold text-[#1A1A1A] mb-4">Ручной поиск</h2>

            {/* Search Tabs */}
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setTab('plate')}
                className={`px-5 py-2.5 rounded text-sm font-medium transition-colors ${
                  tab === 'plate'
                    ? 'bg-[#D5141D] text-white'
                    : 'bg-[#F5F5F5] text-[#1A1A1A] hover:bg-[#EBEBEB]'
                }`}
              >
                Госномер
              </button>
              <button
                onClick={() => setTab('vin')}
                className={`px-5 py-2.5 rounded text-sm font-medium transition-colors ${
                  tab === 'vin'
                    ? 'bg-[#D5141D] text-white'
                    : 'bg-[#F5F5F5] text-[#1A1A1A] hover:bg-[#EBEBEB]'
                }`}
              >
                VIN
              </button>
            </div>

            {/* Search Input */}
            <div className="flex gap-2 mb-8">
              <Input
                placeholder={tab === 'plate' ? 'А 000 АА 000' : 'Введите VIN номер'}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="h-12 text-base"
              />
              <Button className="h-12 px-6 bg-[#D5141D] hover:bg-[#B01018]">
                <Search className="w-5 h-5" />
              </Button>
            </div>

            <Input placeholder="Быстрый поиск" className="h-12 mb-8" />

            {/* Vehicle Types */}
            <h2 className="text-lg font-semibold text-[#1A1A1A] mb-4">Подбор по типу транспорта</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { id: 'passenger', name: 'Легковые автомобили', icon: <Car className="w-6 h-6" /> },
                { id: 'commercial-small', name: 'Малые коммерческие', subtitle: 'до 7,5 т', icon: <Truck className="w-6 h-6" /> },
                { id: 'commercial-large', name: 'Грузовые автомобили', subtitle: 'от 7,5 т', icon: <Truck className="w-6 h-6" /> },
                { id: 'special', name: 'Спецтехника', icon: <Construction className="w-6 h-6" /> },
                { id: 'moto', name: 'Мототехника', icon: <Bike className="w-6 h-6" /> },
                { id: 'bus', name: 'Автобусы', icon: <Bus className="w-6 h-6" /> },
              ].map((vt) => (
                <button
                  key={vt.id}
                  onClick={() => alert('Функция подбора по типу транспорта в разработке')}
                  className="bg-[#F5F5F5] hover:bg-[#EBEBEB] rounded-lg p-4 flex items-center gap-3 transition-colors text-left"
                >
                  <span className="text-[#D5141D]">{vt.icon}</span>
                  <div>
                    <div className="font-medium text-[#1A1A1A] text-sm">{vt.name}</div>
                    {vt.subtitle && <div className="text-xs text-[#666]">{vt.subtitle}</div>}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <AddVehicleModal isOpen={showAddModal} onClose={() => setShowAddModal(false)} />
    </main>
  );
}
