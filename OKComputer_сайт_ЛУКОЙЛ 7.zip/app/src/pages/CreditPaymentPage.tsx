import { useState, useRef, useEffect } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowRight, RefreshCw, CreditCard, ShieldCheck, Clock, Info } from 'lucide-react';

// Sber Widget SDK types
declare global {
  interface Window {
    SberWidgetsSDK?: {
      create: (config: SberWidgetConfig) => void;
    };
  }
}

interface SberWidgetConfig {
  widgetId: string;
  key: string;
  partnerId: string;
  container: HTMLElement | null;
  orderData: {
    extDataId: string;
    orderNumber: string;
    amount: string;
    isPartPayment: boolean;
    purpose: string;
    name: string;
    accountData: {
      accountNumber: string;
      inn: string;
      kpp: string;
      corrAccount: string;
      bic: string;
      nameBank: string;
    };
    vatData: {
      amount: string;
      calcMethod: string;
      rate: number;
    };
  };
  onReceivedOrderDataStatuses?: (data: unknown) => Promise<void>;
  debugMode?: boolean;
}

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

// Demo receiver data (should come from backend in production)
const RECEIVER_DATA = {
  name: 'ООО "ЛУКОЙЛ-Смазочные материалы"',
  accountNumber: '40702810100000004512',
  inn: '7704500789',
  kpp: '770401001',
  corrAccount: '30101810400000000225',
  bic: '044525225',
  nameBank: 'ПАО СБЕРБАНК РОССИИ, г. Москва',
};

export function CreditPaymentPage() {
  const [orderNumber, setOrderNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('Оплата заказа на смазочные материалы ЛУКОЙЛ');
  const [step, setStep] = useState<'form' | 'widget' | 'success'>('form');
  const currentExtIdRef = useRef('');
  const widgetContainerRef = useRef<HTMLDivElement>(null);
  const sdkLoaded = useRef(false);

  // Load Sber SDK
  useEffect(() => {
    if (sdkLoaded.current) return;
    if (window.SberWidgetsSDK) {
      sdkLoaded.current = true;
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://widgetecom.ru/widgets-sdk.js';
    script.async = true;
    script.onload = () => { sdkLoaded.current = true; };
    document.head.appendChild(script);
    return () => { document.head.removeChild(script); };
  }, []);

  const handleNext = () => {
    if (!orderNumber.trim() || !amount.trim() || Number(amount) <= 0) return;

    const extId = generateUUID();
    currentExtIdRef.current = extId;
    setStep('widget');

    // Calculate VAT (20% on top)
    const amountNum = Number(amount);
    const vatAmount = (amountNum * 0.2).toFixed(2);

    // Wait for SDK to be ready
    const initWidget = () => {
      if (!window.SberWidgetsSDK || !widgetContainerRef.current) {
        setTimeout(initWidget, 200);
        return;
      }

      window.SberWidgetsSDK.create({
        widgetId: 'kvk',
        key: 'DEMO-KEY-PLACEHOLDER',
        partnerId: 'DEMO-PARTNER',
        container: widgetContainerRef.current,
        orderData: {
          extDataId: extId,
          orderNumber: orderNumber.trim(),
          amount: amountNum.toFixed(2),
          isPartPayment: true,
          purpose: purpose.trim() || `Оплата заказа ${orderNumber.trim()}`,
          name: RECEIVER_DATA.name,
          accountData: {
            accountNumber: RECEIVER_DATA.accountNumber,
            inn: RECEIVER_DATA.inn,
            kpp: RECEIVER_DATA.kpp,
            corrAccount: RECEIVER_DATA.corrAccount,
            bic: RECEIVER_DATA.bic,
            nameBank: RECEIVER_DATA.nameBank,
          },
          vatData: {
            amount: vatAmount,
            calcMethod: 'ONTOP',
            rate: 20,
          },
        },
        onReceivedOrderDataStatuses: async (data) => {
          console.log('Sber widget statuses:', data);
          return Promise.resolve();
        },
        debugMode: true,
      });
    };

    // Small delay to ensure container is rendered
    setTimeout(initWidget, 100);
  };

  const handleNewOrder = () => {
    setOrderNumber('');
    setAmount('');
    setPurpose('Оплата заказа на смазочные материалы ЛУКОЙЛ');
    setStep('form');
    currentExtIdRef.current = '';
    if (widgetContainerRef.current) {
      widgetContainerRef.current.innerHTML = '';
    }
  };

  const formatAmount = (val: string) => {
    const num = val.replace(/[^0-9.]/g, '');
    return num;
  };

  return (
    <main className="min-h-screen bg-[#f8fafc]">
      <Breadcrumbs items={[{ label: 'Оплата в кредит' }]} />

      <div className="max-w-[900px] mx-auto px-5 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#1e293b]">
            Оплата заказа в кредит
          </h1>
          <p className="text-sm text-[#64748b] mt-1">
            Оформление кредита от СберБанка на оплату заказа смазочных материалов
          </p>
        </div>

        {/* Info banner */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
          <Info className="w-5 h-5 text-[#2563eb] flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-[#1e293b] font-medium">Как это работает</p>
            <p className="text-xs text-[#64748b] mt-1">
              1. Заполните данные заказа ниже &rarr; 2. Нажмите "Далее" &rarr; 3. Виджет Сбер откроется для оформления кредита &rarr; 4. После одобрения — оплата производится автоматически. Сумма заказа от 100 000 ₽.
            </p>
          </div>
        </div>

        {/* Order summary (if in widget step) */}
        {step !== 'form' && (
          <div className="bg-white rounded-xl border border-[#e2e8f0] p-5 mb-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <p className="text-xs text-[#94a3b8]">Номер заказа</p>
                <p className="text-sm font-semibold text-[#1e293b]">{orderNumber}</p>
              </div>
              <div>
                <p className="text-xs text-[#94a3b8]">Сумма заказа</p>
                <p className="text-xl font-bold text-[#1e293b]">{Number(amount).toLocaleString('ru-RU')} ₽</p>
              </div>
              <div>
                <p className="text-xs text-[#94a3b8]">НДС 20%</p>
                <p className="text-sm font-medium text-[#64748b]">{(Number(amount) * 0.2).toLocaleString('ru-RU')} ₽</p>
              </div>
              <div>
                <p className="text-xs text-[#94a3b8]">Итого с НДС</p>
                <p className="text-lg font-bold text-[#2563eb]">{(Number(amount) * 1.2).toLocaleString('ru-RU')} ₽</p>
              </div>
            </div>
          </div>
        )}

        {/* Form */}
        {step === 'form' && (
          <div className="bg-white rounded-xl border border-[#e2e8f0] p-6">
            <h2 className="text-lg font-semibold text-[#1e293b] mb-5 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#2563eb]" />
              Данные заказа
            </h2>

            <div className="space-y-4 max-w-[500px]">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Номер заказа</label>
                <Input
                  type="text"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="Например: 25386549"
                  className="h-11"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Сумма заказа (₽)</label>
                <Input
                  type="text"
                  value={amount}
                  onChange={(e) => setAmount(formatAmount(e.target.value))}
                  placeholder="Минимум 100 000 ₽"
                  className="h-11"
                />
                {amount && Number(amount) < 100000 && (
                  <p className="text-xs text-amber-600 mt-1">Минимальная сумма для кредита — 100 000 ₽</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Назначение платежа</label>
                <Input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="Например: Оплата заказа №12345"
                  className="h-11"
                />
              </div>

              <Button
                onClick={handleNext}
                disabled={!orderNumber.trim() || !amount.trim() || Number(amount) < 100000}
                className="mt-2 h-11 px-8 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:bg-[#cbd5e1]"
              >
                Далее
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Widget container */}
        {step === 'widget' && (
          <div>
            <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 mb-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-[#1e293b] flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-green-600" />
                  Оплата через СберБанк
                </h2>
                <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Решение за 3 минуты</span>
                </div>
              </div>

              {/* Sber widget container */}
              <div
                ref={widgetContainerRef}
                id="sber-widget"
                className="min-h-[400px] border border-dashed border-[#e2e8f0] rounded-lg flex items-center justify-center"
              >
                {!window.SberWidgetsSDK && (
                  <div className="text-center py-12">
                    <div className="w-10 h-10 border-2 border-[#e2e8f0] border-t-[#2563eb] rounded-full animate-spin mx-auto mb-3" />
                    <p className="text-sm text-[#64748b]">Загрузка виджета СберБанка...</p>
                  </div>
                )}
              </div>

              {/* Demo mode notice */}
              <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">
                  <strong>Демо-режим.</strong> Для реальной работы необходимо подписать договор со СберБанком и получить production key и partnerId. Текущие данные — тестовые.
                </p>
              </div>
            </div>

            <Button
              onClick={handleNewOrder}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Оплатить новый заказ
            </Button>
          </div>
        )}

        {/* Receiver info */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 mt-6">
          <h2 className="text-lg font-semibold text-[#1e293b] mb-4">Реквизиты получателя</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            {[
              ['Получатель', RECEIVER_DATA.name],
              ['Р/с', RECEIVER_DATA.accountNumber],
              ['ИНН', RECEIVER_DATA.inn],
              ['КПП', RECEIVER_DATA.kpp],
              ['Банк', RECEIVER_DATA.nameBank],
              ['БИК', RECEIVER_DATA.bic],
              ['К/с', RECEIVER_DATA.corrAccount],
            ].map(([label, value]) => (
              <div key={label} className="flex gap-2">
                <span className="text-[#94a3b8] w-20 flex-shrink-0">{label}</span>
                <span className="text-[#1e293b] font-medium">{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
