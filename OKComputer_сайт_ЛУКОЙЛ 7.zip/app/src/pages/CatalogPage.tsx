import { useState, useMemo } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { ProductCard } from '@/components/ProductCard';
import { products } from '@/data/products';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, ArrowUpDown } from 'lucide-react';

type SortOrder = 'asc' | 'desc';

export function CatalogPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedVehicleTypes, setSelectedVehicleTypes] = useState<string[]>([]);
  const [selectedViscosity, setSelectedViscosity] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });

  const vehicleTypeOptions = [
    { value: 'passenger', label: 'Легковые автомобили' },
    { value: 'commercial', label: 'Коммерческий транспорт' },
    { value: 'industrial', label: 'Индустриальное' },
  ];

  const typeOptions = [
    { value: 'synthetic', label: 'Синтетические' },
    { value: 'semi-synthetic', label: 'Полусинтетические' },
    { value: 'mineral', label: 'Минеральные' },
  ];

  const viscosityOptions = ['0W-20', '0W-30', '5W-30', '5W-40', '10W-40', '15W-40'];

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.article.includes(q) ||
          p.viscosity.toLowerCase().includes(q)
      );
    }

    if (selectedTypes.length > 0) {
      result = result.filter((p) => selectedTypes.includes(p.type));
    }

    if (selectedVehicleTypes.length > 0) {
      result = result.filter((p) => selectedVehicleTypes.includes(p.vehicleType));
    }

    if (selectedViscosity.length > 0) {
      result = result.filter((p) => selectedViscosity.includes(p.viscosity));
    }

    if (priceRange.min) {
      result = result.filter((p) => p.price >= Number(priceRange.min));
    }
    if (priceRange.max) {
      result = result.filter((p) => p.price <= Number(priceRange.max));
    }

    result.sort((a, b) =>
      sortOrder === 'asc' ? a.price - b.price : b.price - a.price
    );

    return result;
  }, [searchQuery, sortOrder, selectedTypes, selectedVehicleTypes, selectedViscosity, priceRange]);

  const toggleFilter = (
    value: string,
    _selected: string[],
    setSelected: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setSelected((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]
    );
  };

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Каталог' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <h1 className="text-2xl md:text-[32px] font-bold text-[#1e293b] mb-8">Каталог</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <aside className="w-full lg:w-[280px] flex-shrink-0">
            <div className="bg-[#f8fafc] rounded p-5 space-y-6">
              {/* Price */}
              <div>
                <h4 className="font-medium text-[#1e293b] mb-3">Цена</h4>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    placeholder="От"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange((p) => ({ ...p, min: e.target.value }))}
                    className="h-9 text-sm"
                  />
                  <span className="text-[#94a3b8]">–</span>
                  <Input
                    type="number"
                    placeholder="До"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange((p) => ({ ...p, max: e.target.value }))}
                    className="h-9 text-sm"
                  />
                </div>
              </div>

              {/* Vehicle Type */}
              <div>
                <h4 className="font-medium text-[#1e293b] mb-3">Вид транспорта</h4>
                <div className="space-y-2">
                  {vehicleTypeOptions.map((opt) => (
                    <label key={opt.value} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox
                        checked={selectedVehicleTypes.includes(opt.value)}
                        onCheckedChange={() =>
                          toggleFilter(opt.value, selectedVehicleTypes, setSelectedVehicleTypes)
                        }
                      />
                      <span className="text-[#1e293b]">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Type */}
              <div>
                <h4 className="font-medium text-[#1e293b] mb-3">Вид</h4>
                <div className="space-y-2">
                  {typeOptions.map((opt) => (
                    <label key={opt.value} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox
                        checked={selectedTypes.includes(opt.value)}
                        onCheckedChange={() =>
                          toggleFilter(opt.value, selectedTypes, setSelectedTypes)
                        }
                      />
                      <span className="text-[#1e293b]">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Viscosity */}
              <div>
                <h4 className="font-medium text-[#1e293b] mb-3">Вязкость</h4>
                <div className="space-y-2">
                  {viscosityOptions.map((v) => (
                    <label key={v} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox
                        checked={selectedViscosity.includes(v)}
                        onCheckedChange={() =>
                          toggleFilter(v, selectedViscosity, setSelectedViscosity)
                        }
                      />
                      <span className="text-[#1e293b]">{v}</span>
                    </label>
                  ))}
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full text-sm"
                onClick={() => {
                  setSelectedTypes([]);
                  setSelectedVehicleTypes([]);
                  setSelectedViscosity([]);
                  setPriceRange({ min: '', max: '' });
                  setSearchQuery('');
                }}
              >
                Сбросить фильтры
              </Button>
            </div>
          </aside>

          {/* Content */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#94a3b8]" />
                <Input
                  placeholder="Быстрый поиск"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 h-10"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#64748b]">Сортировать по:</span>
                <button
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                  className="flex items-center gap-1 text-sm text-[#1e293b] hover:text-[#2563eb] transition-colors"
                >
                  Цене
                  <ArrowUpDown className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="space-y-4">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-lg text-[#64748b]">Товары не найдены</p>
                <p className="text-sm text-[#94a3b8] mt-1">Попробуйте изменить параметры фильтрации</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
