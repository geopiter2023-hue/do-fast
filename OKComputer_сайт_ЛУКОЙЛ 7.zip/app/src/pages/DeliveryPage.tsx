import { useState, useMemo } from 'react';
import { SidebarMenu } from '@/components/SidebarMenu';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useGeolocation } from '@/hooks/useGeolocation';
import { transportCompanies, getDeliveryOptions } from '@/data/transport';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Truck, MapPin, Clock, CheckCircle2,
  Building2, Weight
} from 'lucide-react';

const cities = ['Москва', 'Санкт-Петербург', 'Казань', 'Нижний Новгород', 'Екатеринбург', 'Новосибирск', 'Ростов-на-Дону', 'Краснодар'];

export function DeliveryPage() {
  const { state: geoState } = useGeolocation();
  const [fromCity, setFromCity] = useState(geoState.city);
  const [toCity, setToCity] = useState('Екатеринбург');
  const [weight, setWeight] = useState('100');
  const [volume, setVolume] = useState('0.5');
  const [selectedTC, setSelectedTC] = useState<string>('');

  const options = useMemo(() => {
    return getDeliveryOptions(Number(weight) || 0, Number(volume) || 0, fromCity, toCity);
  }, [weight, volume, fromCity, toCity]);

  const selectedOption = options.find(o => o.companyId === selectedTC);

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Доставка и самовывоз' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <SidebarMenu activeId="delivery" />

          <div className="flex-1">
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-6">
              Доставка и самовывоз
            </h1>

            <p className="text-[#1A1A1A] leading-relaxed mb-8">
              Клиентам интернет-магазина мы предоставляем широкий выбор способов доставки нашей
              высококачественной продукции по всей России. Выберите транспортную компанию и рассчитайте стоимость.
            </p>

            {/* Calculator */}
            <div className="bg-white border border-[#E0E0E0] rounded-lg p-5 mb-8">
              <h2 className="text-lg font-semibold text-[#1A1A1A] mb-4 flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#D5141D]" />
                Калькулятор доставки
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Откуда</label>
                  <Select value={fromCity} onValueChange={setFromCity}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Куда</label>
                  <Select value={toCity} onValueChange={setToCity}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Вес (кг)</label>
                  <Input type="number" value={weight} onChange={e => setWeight(e.target.value)} min={1} />
                </div>
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Объём (м³)</label>
                  <Input type="number" value={volume} onChange={e => setVolume(e.target.value)} min={0.01} step={0.01} />
                </div>
              </div>

              {/* Results */}
              <div className="space-y-2 mt-4">
                {options.map((opt, i) => (
                  <button
                    key={opt.companyId}
                    onClick={() => setSelectedTC(opt.companyId)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
                      selectedTC === opt.companyId
                        ? 'border-[#D5141D] bg-red-50 shadow-sm'
                        : i === 0
                        ? 'border-green-300 bg-green-50/50'
                        : 'border-[#E0E0E0] hover:border-[#D5141D]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#F5F5F5] rounded flex items-center justify-center">
                        <Truck className="w-5 h-5 text-[#666]" />
                      </div>
                      <div>
                        <div className="font-medium text-[#1A1A1A] flex items-center gap-2">
                          {opt.company.name}
                          {i === 0 && <span className="text-[10px] px-1.5 py-0.5 bg-green-500 text-white rounded">Лучшая цена</span>}
                          {selectedTC === opt.companyId && <CheckCircle2 className="w-4 h-4 text-[#D5141D]" />}
                        </div>
                        <div className="text-xs text-[#666] flex items-center gap-2">
                          <Clock className="w-3 h-3" />
                          {opt.days} {opt.days === 1 ? 'день' : opt.days < 5 ? 'дня' : 'дней'}
                          <Weight className="w-3 h-3 ml-1" />
                          Стандарт
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-[#1A1A1A]">{opt.cost.toLocaleString('ru-RU')} ₽</div>
                      <div className="text-xs text-[#666]">мин. {opt.company.minCost} ₽</div>
                    </div>
                  </button>
                ))}
              </div>

              {selectedOption && (
                <div className="mt-4 p-4 bg-[#2B2F3B] text-white rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-gray-300">Выбрана доставка:</div>
                      <div className="font-semibold">{selectedOption.company.name}</div>
                      <div className="text-sm text-gray-300">
                        {fromCity} → {toCity}, {selectedOption.days} {selectedOption.days === 1 ? 'день' : selectedOption.days < 5 ? 'дня' : 'дней'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold">{selectedOption.cost.toLocaleString('ru-RU')} ₽</div>
                      <Button className="mt-2 bg-[#D5141D] hover:bg-[#B01018] h-8 text-xs">
                        Оформить доставку
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 mb-10 p-6 bg-[#F5F5F5] rounded-lg">
              <div className="text-5xl font-bold text-[#D5141D]">89</div>
              <div className="text-lg text-[#1A1A1A]">
                регионов<br />доставки
              </div>
              <img
                src="/images/about-barrels.jpg"
                alt="Доставка"
                className="h-24 w-auto ml-auto rounded opacity-60 hidden md:block"
              />
            </div>

            {/* Delivery methods */}
            <h2 className="text-xl font-bold text-[#1A1A1A] mb-6">Способы доставки</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-10">
              <div className="border border-[#E0E0E0] rounded p-5 text-center">
                <Truck className="w-10 h-10 text-[#D5141D] mx-auto mb-3" />
                <h3 className="font-semibold text-[#1A1A1A] mb-2">Курьерская доставка</h3>
                <p className="text-sm text-[#666666]">Доставка до двери в удобное время. Доступна для заказов до 200 кг.</p>
              </div>
              <div className="border border-[#E0E0E0] rounded p-5 text-center">
                <Building2 className="w-10 h-10 text-[#D5141D] mx-auto mb-3" />
                <h3 className="font-semibold text-[#1A1A1A] mb-2">Терминалы и постаматы</h3>
                <p className="text-sm text-[#666666]">Получение в ближайшем терминале транспортной компании.</p>
              </div>
              <div className="border border-[#E0E0E0] rounded p-5 text-center">
                <MapPin className="w-10 h-10 text-[#D5141D] mx-auto mb-3" />
                <h3 className="font-semibold text-[#1A1A1A] mb-2">Пункты самовывоза</h3>
                <p className="text-sm text-[#666666]">Более 80 точек самовывоза по всей России.</p>
              </div>
            </div>

            {/* TC list */}
            <h2 className="text-xl font-bold text-[#1A1A1A] mb-4">Транспортные компании-партнёры</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-8">
              {transportCompanies.map(tc => (
                <div key={tc.id} className="border border-[#E0E0E0] rounded p-4 flex items-start gap-3">
                  <div className="w-10 h-10 bg-[#F5F5F5] rounded flex items-center justify-center flex-shrink-0">
                    <Truck className="w-5 h-5 text-[#666]" />
                  </div>
                  <div>
                    <h4 className="font-medium text-[#1A1A1A]">{tc.name}</h4>
                    <div className="text-xs text-[#666] mt-1 space-y-0.5">
                      <div>от {tc.minCost} ₽</div>
                      <div>{tc.minDays}-{tc.maxDays} дней</div>
                      <div>{tc.services.join(', ')}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Info */}
            <div className="bg-[#F5F5F5] rounded p-6">
              <h3 className="font-semibold text-[#1A1A1A] mb-3">Информация о доставке</h3>
              <p className="text-sm text-[#666666] leading-relaxed">
                Доставка и самовывоз официального интернет-магазина смазочных материалов ЛУКОЙЛ
                осуществляются фулфилмент-оператором ООО «ИндигоЛаб Рус», Транспортными компаниями,
                а также авторизованными партнёрами – дилерами.
              </p>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-sm text-[#666666]">Стоимость доставки:</span>
                  <p className="font-medium text-[#1A1A1A]">Рассчитывается индивидуально</p>
                </div>
                <div>
                  <span className="text-sm text-[#666666]">Сроки доставки:</span>
                  <p className="font-medium text-[#1A1A1A]">1–12 рабочих дней</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
