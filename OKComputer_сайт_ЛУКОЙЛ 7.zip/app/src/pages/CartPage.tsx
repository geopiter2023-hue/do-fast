import { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/hooks/useAuth';
import { useCashback } from '@/hooks/useCashback';
import { useGeolocation } from '@/hooks/useGeolocation';
import { getStockLabel } from '@/data/stockLabels';
import { transportCompanies, calculateDeliveryCost, estimateDays } from '@/data/transport';
import { volumeTiers, getDiscountForVolume, getNextTier, getProgressToNextTier } from '@/data/volumeDiscounts';
import { Button } from '@/components/ui/button';
import {
  Minus, Plus, Trash2, ShoppingCart, Truck, MapPin,
  Award, TrendingDown, CheckCircle
} from 'lucide-react';

type DeliveryType = 'pickup' | 'transport';

interface OrderSummary {
  orderNumber: string;
  total: number;
  itemCount: number;
  discount: number;
  deliveryType: string;
}

export function CartPage() {
  const { state, removeItem, updateQuantity, clearCart, totalCount, totalPrice, totalWeight } = useCart();
  const { state: authState } = useAuth();
  const { state: cashbackState, earnPoints } = useCashback();
  const { state: geoState } = useGeolocation();

  const [deliveryType, setDeliveryType] = useState<DeliveryType>('pickup');
  const [selectedTransport, setSelectedTransport] = useState(transportCompanies[0].id);
  const [showConfirm, setShowConfirm] = useState(false);
  const [orderSummary, setOrderSummary] = useState<OrderSummary | null>(null);

  // Volume discount
  const discountTier = getDiscountForVolume(totalPrice);
  const discountAmount = Math.round(totalPrice * (discountTier.discount / 100));
  const priceAfterDiscount = totalPrice - discountAmount;
  const nextTier = getNextTier(totalPrice);
  const progressPercent = getProgressToNextTier(totalPrice);

  // Delivery
  const volumeM3 = totalWeight * 0.0015;
  const selectedCompany = transportCompanies.find(c => c.id === selectedTransport) || transportCompanies[0];
  const deliveryCost = deliveryType === 'transport'
    ? calculateDeliveryCost(selectedCompany, totalWeight, volumeM3, 500)
    : 0;
  const finalTotal = priceAfterDiscount + deliveryCost;
  const orderCashback = Math.round(priceAfterDiscount / 10);

  // Earn cashback for all items
  const handleOrder = useCallback(() => {
    if (authState.isAuthenticated) {
      state.items.forEach(item => {
        earnPoints(item.product.name, item.packaging.price * item.quantity);
      });
    }

    const summary: OrderSummary = {
      orderNumber: `LK-${Math.floor(100000 + Math.random() * 900000)}`,
      total: finalTotal,
      itemCount: totalCount,
      discount: discountAmount,
      deliveryType: deliveryType === 'pickup' ? 'Самовывоз' : selectedCompany.name,
    };

    setOrderSummary(summary);
    setShowConfirm(true);
  }, [authState.isAuthenticated, state.items, earnPoints, finalTotal, totalCount, discountAmount, deliveryType, selectedCompany.name]);

  const closeConfirm = useCallback(() => {
    clearCart();
    setShowConfirm(false);
  }, [clearCart]);

  // ========== ORDER CONFIRMATION MODAL ==========
  if (showConfirm && orderSummary) {
    return (
      <main className="min-h-screen bg-[#f8fafc]">
        <Breadcrumbs items={[{ label: 'Корзина' }]} />
        <div className="max-w-[600px] mx-auto px-5 py-16 text-center">
          <div className="bg-white rounded-2xl border border-green-200 shadow-xl p-10">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-[#1e293b] mb-2">Заказ оформлен!</h2>
            <p className="text-sm text-[#64748b] mb-6">Менеджер свяжется с вами для подтверждения</p>

            <div className="bg-[#f8fafc] rounded-xl p-5 text-left space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-[#94a3b8]">Номер заказа</span>
                <span className="font-bold text-[#1e293b]">{orderSummary.orderNumber}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#94a3b8]">Позиций</span>
                <span className="font-medium text-[#1e293b]">{orderSummary.itemCount}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#94a3b8]">Скидка</span>
                <span className="font-medium text-green-600">-{orderSummary.discount.toLocaleString('ru-RU')} ₽</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#94a3b8]">Доставка</span>
                <span className="font-medium text-[#1e293b]">{orderSummary.deliveryType}</span>
              </div>
              <div className="border-t border-[#e2e8f0] pt-3 flex justify-between">
                <span className="text-[#1e293b] font-medium">Итого</span>
                <span className="text-2xl font-bold text-[#dc2626]">{orderSummary.total.toLocaleString('ru-RU')} ₽</span>
              </div>
              {authState.isAuthenticated && (
                <div className="flex items-center gap-1.5 text-xs text-amber-600 pt-1">
                  <Award className="w-3.5 h-3.5" />
                  <span>+{Math.round(orderSummary.total / 10)} баллов кэшбэка начислено</span>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-3">
              <Button
                onClick={closeConfirm}
                className="h-12 bg-[#2563eb] hover:bg-[#1d4ed8] text-base rounded-xl"
              >
                Перейти в каталог
              </Button>
              <Link to="/delivery" className="block">
                <Button variant="outline" className="w-full h-11 rounded-xl">
                  Информация о доставке
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>
    );
  }

  // ========== EMPTY CART ==========
  if (state.items.length === 0) {
    return (
      <main className="min-h-screen bg-[#f8fafc]">
        <Breadcrumbs items={[{ label: 'Корзина' }]} />
        <div className="max-w-[1400px] mx-auto px-5 py-16 text-center">
          <ShoppingCart className="w-16 h-16 text-[#cbd5e1] mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-[#1e293b] mb-2">Ваша корзина пуста</h2>
          <p className="text-[#64748b] mb-6">Добавьте товары из каталога</p>
          <Link to="/catalog">
            <Button className="bg-[#2563eb] hover:bg-[#1d4ed8] h-11 px-8 rounded-xl">Перейти в каталог</Button>
          </Link>
        </div>
      </main>
    );
  }

  // ========== CART WITH ITEMS ==========
  return (
    <main className="min-h-screen bg-[#f8fafc]">
      <Breadcrumbs items={[{ label: 'Корзина' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <h1 className="text-2xl md:text-3xl font-bold text-[#1e293b] mb-8">Корзина</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Column */}
          <div className="flex-1 space-y-6">
            {/* Volume Discount Banner */}
            <div className="bg-gradient-to-r from-[#1e293b] to-[#334155] rounded-xl p-5 text-white">
              <div className="flex items-center gap-2 mb-3">
                <TrendingDown className="w-5 h-5 text-green-400" />
                <h3 className="font-semibold">Ваша скидка: {discountTier.discount}%</h3>
                <span className="text-sm text-gray-400">({discountTier.label})</span>
              </div>
              {nextTier && (
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                    <span>Экономия: {discountAmount.toLocaleString('ru-RU')} ₽</span>
                    <span>До {nextTier.discount}%: {(nextTier.minVolume - totalPrice).toLocaleString('ru-RU')} ₽</span>
                  </div>
                  <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#dc2626] to-green-500 transition-all" style={{ width: `${progressPercent}%` }} />
                  </div>
                </div>
              )}
              <div className="flex gap-2 flex-wrap">
                {volumeTiers.filter(t => t.discount > 0).map(tier => (
                  <div key={tier.minVolume} className={`text-xs px-2 py-1 rounded ${tier.discount === discountTier.discount ? 'bg-[#dc2626] text-white font-medium' : 'bg-gray-700 text-gray-400'}`}>
                    {tier.discount}% от {tier.minVolume.toLocaleString('ru-RU')} ₽
                  </div>
                ))}
              </div>
            </div>

            {/* Cart Items */}
            <div className="space-y-4">
              {state.items.map((item) => {
                const stockLabel = getStockLabel(item.product.inStock ? 15 : 0);
                return (
                  <div key={`${item.productId}-${item.packagingId}`} className="bg-white border border-[#e2e8f0] rounded-xl p-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="w-24 h-24 flex-shrink-0 bg-white rounded-lg flex items-center justify-center">
                        <img src={item.product.image} alt={item.product.name} className="max-h-full max-w-full object-contain" />
                      </div>
                      <div className="flex-1">
                        <Link to={`/product/${item.productId}`}>
                          <h3 className="font-medium text-[#1e293b] hover:text-[#2563eb] transition-colors">{item.product.name}</h3>
                        </Link>
                        <p className="text-xs text-[#94a3b8]">Артикул: {item.product.article}</p>
                        <p className="text-sm text-[#64748b] mt-1">Фасовка: {item.packaging.name} × {item.quantity}</p>
                        <div className="mt-2 flex items-center gap-2">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${stockLabel.bgColor} ${stockLabel.color}`}>{stockLabel.text}</span>
                        </div>
                        <div className="mt-1 flex items-center gap-1 text-xs text-amber-600">
                          <Award className="w-3 h-3" />
                          <span>+{Math.round(item.packaging.price * item.quantity / 10)} баллов</span>
                        </div>
                      </div>
                      <div className="flex sm:flex-col items-center sm:items-end gap-3 sm:gap-2">
                        <div className="flex items-center border border-[#e2e8f0] rounded-lg">
                          <button onClick={() => updateQuantity(item.productId, item.packagingId, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center hover:bg-[#f8fafc]">
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-10 h-8 flex items-center justify-center border-x border-[#e2e8f0] text-sm font-medium">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.productId, item.packagingId, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center hover:bg-[#f8fafc]">
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-[#1e293b]">{(item.packaging.price * item.quantity).toLocaleString('ru-RU')} ₽</div>
                          <div className="text-xs text-[#94a3b8]">{item.packaging.price.toLocaleString('ru-RU')} ₽/шт</div>
                        </div>
                        <button onClick={() => removeItem(item.productId, item.packagingId)} className="w-8 h-8 flex items-center justify-center text-[#94a3b8] hover:text-red-500 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Delivery Selection */}
            <div className="bg-white border border-[#e2e8f0] rounded-xl p-6">
              <h3 className="font-semibold text-lg text-[#1e293b] mb-4">Способ получения</h3>
              <div className="flex gap-3 mb-6">
                <button onClick={() => setDeliveryType('pickup')} className={`flex-1 flex items-center gap-3 p-4 rounded-xl border-2 transition-colors ${deliveryType === 'pickup' ? 'border-[#2563eb] bg-blue-50' : 'border-[#e2e8f0]'}`}>
                  <MapPin className={`w-5 h-5 ${deliveryType === 'pickup' ? 'text-[#2563eb]' : 'text-[#94a3b8]'}`} />
                  <div className="text-left">
                    <div className={`font-medium ${deliveryType === 'pickup' ? 'text-[#2563eb]' : 'text-[#1e293b]'}`}>Самовывоз</div>
                    <div className="text-xs text-[#94a3b8]">Бесплатно</div>
                  </div>
                </button>
                <button onClick={() => setDeliveryType('transport')} className={`flex-1 flex items-center gap-3 p-4 rounded-xl border-2 transition-colors ${deliveryType === 'transport' ? 'border-[#2563eb] bg-blue-50' : 'border-[#e2e8f0]'}`}>
                  <Truck className={`w-5 h-5 ${deliveryType === 'transport' ? 'text-[#2563eb]' : 'text-[#94a3b8]'}`} />
                  <div className="text-left">
                    <div className={`font-medium ${deliveryType === 'transport' ? 'text-[#2563eb]' : 'text-[#1e293b]'}`}>Доставка ТК</div>
                    <div className="text-xs text-[#94a3b8]">От {transportCompanies[0].minCost} ₽</div>
                  </div>
                </button>
              </div>

              {deliveryType === 'transport' && (
                <div className="space-y-3">
                  <p className="text-sm text-[#64748b] mb-2">Выберите транспортную компанию:</p>
                  {transportCompanies.map((company) => {
                    const cost = calculateDeliveryCost(company, totalWeight, volumeM3, 500);
                    const days = estimateDays(company, 500);
                    const isSelected = selectedTransport === company.id;
                    return (
                      <div key={company.id} onClick={() => setSelectedTransport(company.id)} className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${isSelected ? 'border-[#2563eb] bg-blue-50' : 'border-[#e2e8f0]'}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? 'border-[#2563eb]' : 'border-[#cbd5e1]'}`}>
                              {isSelected && <div className="w-3 h-3 rounded-full bg-[#2563eb]" />}
                            </div>
                            <div>
                              <div className="font-medium text-[#1e293b]">{company.name}</div>
                              <div className="text-xs text-[#94a3b8]">{days} дн.</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-[#1e293b]">{cost.toLocaleString('ru-RU')} ₽</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {deliveryType === 'pickup' && (
                <div className="p-4 bg-green-50 rounded-xl border border-green-200">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 mt-0.5 text-green-600" />
                    <div>
                      <p className="font-medium text-[#1e293b]">Самовывоз в {geoState.city}</p>
                      <p className="text-sm text-green-600 font-medium">Бесплатно</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column - Summary */}
          <div className="w-full lg:w-[380px] flex-shrink-0">
            <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 sticky top-24 space-y-4">
              <h3 className="font-semibold text-lg text-[#1e293b]">Ваш заказ</h3>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[#94a3b8]">Товаров:</span>
                  <span className="font-medium">{totalCount} позиций</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#94a3b8]">Сумма:</span>
                  <span className="font-semibold text-[#1e293b]">{totalPrice.toLocaleString('ru-RU')} ₽</span>
                </div>
                {discountTier.discount > 0 && (
                  <div className="flex justify-between text-green-700">
                    <span className="flex items-center gap-1"><TrendingDown className="w-4 h-4" /> Скидка {discountTier.discount}%:</span>
                    <span className="font-semibold">−{discountAmount.toLocaleString('ru-RU')} ₽</span>
                  </div>
                )}
                {deliveryType === 'transport' && (
                  <div className="flex justify-between">
                    <span className="text-[#94a3b8]">Доставка ({selectedCompany.name}):</span>
                    <span className="font-semibold">{deliveryCost.toLocaleString('ru-RU')} ₽</span>
                  </div>
                )}
                {deliveryType === 'pickup' && (
                  <div className="flex justify-between">
                    <span className="text-[#94a3b8]">Самовывоз:</span>
                    <span className="font-semibold text-green-600">Бесплатно</span>
                  </div>
                )}
              </div>

              <div className="border-t border-[#e2e8f0] pt-4">
                <div className="flex justify-between items-end">
                  <span className="text-lg font-semibold text-[#1e293b]">Итого:</span>
                  <span className="text-2xl font-bold text-[#dc2626]">{finalTotal.toLocaleString('ru-RU')} ₽</span>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                <div>
                  <p className="text-sm text-amber-800 font-medium">+{orderCashback} баллов кэшбэка</p>
                  {authState.isAuthenticated && (
                    <p className="text-xs text-amber-600">Баланс: {cashbackState.points.toLocaleString('ru-RU')} баллов</p>
                  )}
                </div>
              </div>

              <Button
                onClick={handleOrder}
                className="w-full h-12 text-base bg-[#dc2626] hover:bg-[#b91c1c] rounded-xl"
              >
                Оформить заказ
              </Button>

              <Link to="/catalog" className="block">
                <Button variant="outline" className="w-full h-11 rounded-xl">Продолжить покупки</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
