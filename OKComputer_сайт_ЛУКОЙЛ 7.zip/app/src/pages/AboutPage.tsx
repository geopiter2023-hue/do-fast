import { SidebarMenu } from '@/components/SidebarMenu';
import { Breadcrumbs } from '@/components/Breadcrumbs';

export function AboutPage() {
  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'О компании' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <SidebarMenu activeId="about" />

          <div className="flex-1">
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-6">О компании</h1>

            <div className="prose max-w-none text-[#1A1A1A] leading-relaxed space-y-4">
              <p>
                <strong>ООО «ЛЛК-Интернешнл»</strong> — один из ведущих производителей масел, смазок
                и технических жидкостей, создано в 2005 году и является 100% дочерним обществом
                ПАО «ЛУКОЙЛ».
              </p>
              <p>
                Предприятие производит масла и смазки на 9 собственных производственных площадках,
                2 совместных предприятиях и 25 привлеченных заводов, расположенных на 5 континентах.
                Продажи масел и смазок «ЛУКОЙЛ» осуществляются более чем в 100 странах.
              </p>
              <p>
                Официальный интернет-магазин по оптовой продаже автомобильных масел и смазочных
                материалов ЛУКОЙЛ предлагает юридическим лицам и индивидуальным предпринимателям
                широкий ассортимент продукции на специальных условиях.
              </p>
              <p>
                Мы предлагаем оптовикам удобные варианты фасовки, отвечающие потребностям различных
                направлений бизнеса: масла в канистрах, в коробках и поштучно, в бочках, бидонах, барабанах.
              </p>
              <p>
                Контролируйте заказы и управляйте расходами на закупку смазочных материалов через
                Личный кабинет на сайте.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="bg-[#F5F5F5] rounded p-5 text-center">
                <div className="text-3xl font-bold text-[#D5141D] mb-1">800+</div>
                <div className="text-sm text-[#666666]">Наименований продукции</div>
              </div>
              <div className="bg-[#F5F5F5] rounded p-5 text-center">
                <div className="text-3xl font-bold text-[#D5141D] mb-1">100+</div>
                <div className="text-sm text-[#666666]">Стран присутствия</div>
              </div>
              <div className="bg-[#F5F5F5] rounded p-5 text-center">
                <div className="text-3xl font-bold text-[#D5141D] mb-1">20+</div>
                <div className="text-sm text-[#666666]">Лет на рынке</div>
              </div>
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold text-[#1A1A1A] mb-4">Контакты</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-[#666666]">Телефон:</span>
                  <a href="tel:88007008700" className="text-[#1A1A1A] hover:text-[#D5141D]">
                    8 800 700-8-700
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[#666666]">Email:</span>
                  <a href="mailto:help@b2b.lukoil-shop.ru" className="text-[#1A1A1A] hover:text-[#D5141D]">
                    help@b2b.lukoil-shop.ru
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[#666666]">Часы работы:</span>
                  <span className="text-[#1A1A1A]">9:00 – 18:00, будние дни</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
