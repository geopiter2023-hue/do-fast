import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { useGarage } from '@/hooks/useGarage';
import { AddVehicleModal } from '@/components/AddVehicleModal';
import { Button } from '@/components/ui/button';
import { Plus, Trash2, Car, Search, Wrench } from 'lucide-react';

const engineTypeLabels: Record<string, string> = {
  gasoline: 'Бензиновый',
  diesel: 'Дизельный',
  hybrid: 'Гибридный',
  electric: 'Электрический',
};

export function GaragePage() {
  const { state, removeVehicle } = useGarage();
  const [showAddModal, setShowAddModal] = useState(false);

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Гараж' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A]">Мой гараж</h1>
          <Button
            onClick={() => setShowAddModal(true)}
            className="bg-[#D5141D] hover:bg-[#B01018] h-10"
          >
            <Plus className="w-4 h-4 mr-2" />
            Добавить авто
          </Button>
        </div>

        {state.vehicles.length === 0 ? (
          /* Empty state */
          <div className="text-center py-16 bg-[#F5F5F5] rounded-lg">
            <Car className="w-16 h-16 text-[#CCC] mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-[#1A1A1A] mb-2">Гараж пуст</h2>
            <p className="text-[#666] mb-6 max-w-md mx-auto">
              Добавьте свои автомобили в гараж, чтобы быстро подбирать масла и технические жидкости
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                onClick={() => setShowAddModal(true)}
                className="bg-[#D5141D] hover:bg-[#B01018] h-11"
              >
                <Plus className="w-4 h-4 mr-2" />
                Добавить автомобиль
              </Button>
              <Link to="/oil-selector">
                <Button variant="outline" className="h-11">
                  <Search className="w-4 h-4 mr-2" />
                  Подбор по VIN
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          /* Vehicle list */
          <div className="space-y-4">
            {state.vehicles.map((vehicle) => (
              <div
                key={vehicle.id}
                className="bg-white border border-[#E0E0E0] rounded-lg p-5 flex flex-col sm:flex-row gap-5 hover:shadow-md transition-shadow"
              >
                {/* Vehicle icon */}
                <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center flex-shrink-0">
                  <Car className="w-8 h-8 text-[#D5141D]" />
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-[#1A1A1A]">
                        {vehicle.brand} {vehicle.model}
                      </h3>
                      <p className="text-sm text-[#666] mt-1">{vehicle.typeLabel}</p>
                    </div>
                    <button
                      onClick={() => removeVehicle(vehicle.id)}
                      className="text-[#CCC] hover:text-[#D5141D] transition-colors p-1"
                      title="Удалить"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-x-6 gap-y-1 mt-3 text-sm text-[#666]">
                    <span>Год: <strong className="text-[#1A1A1A]">{vehicle.year}</strong></span>
                    {vehicle.engineType && (
                      <span>Двигатель: <strong className="text-[#1A1A1A]">{engineTypeLabels[vehicle.engineType]}</strong></span>
                    )}
                    {vehicle.plate && (
                      <span>Госномер: <strong className="text-[#1A1A1A]">{vehicle.plate}</strong></span>
                    )}
                    {vehicle.vin && (
                      <span>VIN: <strong className="text-[#1A1A1A]">{vehicle.vin.slice(0, 8)}...{vehicle.vin.slice(-4)}</strong></span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-2 min-w-[160px]">
                  <Link to="/oil-selector">
                    <Button className="w-full bg-[#D5141D] hover:bg-[#B01018] h-10 text-sm">
                      <Wrench className="w-4 h-4 mr-2" />
                      Подобрать масло
                    </Button>
                  </Link>
                  <Link to="/catalog">
                    <Button variant="outline" className="w-full h-10 text-sm">
                      <Search className="w-4 h-4 mr-2" />
                      В каталог
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <AddVehicleModal isOpen={showAddModal} onClose={() => setShowAddModal(false)} />
    </main>
  );
}
