import { useState, useMemo } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { fulfillmentCenters, getDeliveryOptions, transportCompanies } from '@/data/transport';
import { useGeolocation } from '@/hooks/useGeolocation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Package, Truck, MapPin, Clock, FileText, CheckCircle2,
  Building2, ExternalLink, Store, ShoppingBag
} from 'lucide-react';

// Products available for ECOM pallet shipments
const ecomProducts = [
  { id: 'p1', name: 'LUKOIL GENESIS UNIVERSAL 5W-40', sku: '3148640', perPallet: 96, unitPrice: 84992, category: 'motor' },
  { id: 'p2', name: 'LUKOIL GENESIS ARMORTECH 5W-40', sku: '2255947', perPallet: 108, unitPrice: 12720, category: 'motor' },
  { id: 'p3', name: 'LUKOIL AVANTGARDE ULTRA 10W-40', sku: '3655654', perPallet: 120, unitPrice: 5910, category: 'motor' },
  { id: 'p4', name: 'LUKOIL Тормозная жидкость DOT-4', sku: '3167890', perPallet: 240, unitPrice: 890, category: 'brake' },
  { id: 'p5', name: 'LUKOIL Антифриз G11 Синий', sku: '3156789', perPallet: 180, unitPrice: 1800, category: 'coolant' },
  { id: 'p6', name: 'LUKOIL ТМ-4 80W-90', sku: '3172891', perPallet: 144, unitPrice: 4200, category: 'transmission' },
];

export function EcomPage() {
  const { state: geoState } = useGeolocation();
  const [selectedMarketplace, setSelectedMarketplace] = useState<'all' | 'ozon' | 'wildberries'>('all');
  const [selectedCity, setSelectedCity] = useState(geoState.city);
  const [selectedFC, setSelectedFC] = useState<string>('');
  const [palletCount, setPalletCount] = useState(1);
  const [selectedProducts, setSelectedProducts] = useState<Record<string, number>>({});
  const [selectedTC, setSelectedTC] = useState('');
  const filteredFCs = useMemo(() =>
    fulfillmentCenters.filter(fc =>
      (selectedMarketplace === 'all' || fc.marketplace === selectedMarketplace) &&
      fc.city === selectedCity
    ),
    [selectedMarketplace, selectedCity]
  );

  const activeFC = fulfillmentCenters.find(fc => fc.id === selectedFC);

  const tc = transportCompanies.find(t => t.id === selectedTC);

  const handleProductToggle = (productId: string) => {
    setSelectedProducts(prev => {
      const next = { ...prev };
      if (next[productId]) delete next[productId];
      else next[productId] = 1;
      return next;
    });
  };

  const handleProductQtyChange = (productId: string, qty: number) => {
    setSelectedProducts(prev => ({ ...prev, [productId]: Math.max(1, qty) }));
  };

  const totalPalletValue = useMemo(() => {
    return Object.entries(selectedProducts).reduce((sum, [pid, qty]) => {
      const p = ecomProducts.find(ep => ep.id === pid);
      return sum + (p ? p.unitPrice * p.perPallet * qty : 0);
    }, 0);
  }, [selectedProducts]);

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'ECOM — Отгрузки паллетами' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A]">
              ECOM — Отгрузки паллетами
            </h1>
            <p className="text-sm text-[#666] mt-1">
              Прямые поставки на склады Ozon и Wildberries с доставкой до распределительных центров
            </p>
          </div>
          <div className="flex items-center gap-2 bg-[#F5F5F5] rounded-lg px-3 py-2">
            <MapPin className="w-4 h-4 text-[#D5141D]" />
            <span className="text-sm">Ваш город: <strong>{geoState.city}</strong></span>
          </div>
        </div>

        {/* Marketplace selector */}
        <div className="flex gap-2 mb-6">
          {[
            { value: 'all' as const, label: 'Все маркетплейсы', icon: <Store className="w-4 h-4" /> },
            { value: 'ozon' as const, label: 'Ozon', icon: <ShoppingBag className="w-4 h-4" /> },
            { value: 'wildberries' as const, label: 'Wildberries', icon: <ShoppingBag className="w-4 h-4" /> },
          ].map(opt => (
            <button
              key={opt.value}
              onClick={() => setSelectedMarketplace(opt.value)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded text-sm font-medium transition-colors ${
                selectedMarketplace === opt.value
                  ? 'bg-[#D5141D] text-white'
                  : 'bg-white border border-[#E0E0E0] text-[#1A1A1A] hover:border-[#D5141D]'
              }`}
            >
              {opt.icon}
              {opt.label}
            </button>
          ))}
        </div>

        {/* City selector */}
        <div className="bg-white border border-[#E0E0E0] rounded-lg p-4 mb-6 flex items-center gap-4">
          <label className="text-sm text-[#666] font-medium">Город РЦ:</label>
          <Select value={selectedCity} onValueChange={(v) => { setSelectedCity(v); setSelectedFC(''); }}>
            <SelectTrigger className="w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {['Москва', 'Санкт-Петербург', 'Казань', 'Екатеринбург', 'Новосибирск', 'Краснодар'].map(c => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <span className="text-sm text-[#666]">Найдено РЦ: <strong className="text-[#1A1A1A]">{filteredFCs.length}</strong></span>
        </div>

        {/* Fulfillment Centers */}
        <h2 className="text-lg font-semibold text-[#1A1A1A] mb-4">Распределительные центры</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {filteredFCs.map(fc => (
            <button
              key={fc.id}
              onClick={() => setSelectedFC(fc.id)}
              className={`text-left border rounded-lg p-4 transition-all ${
                selectedFC === fc.id
                  ? 'border-[#D5141D] bg-red-50 shadow-md'
                  : 'border-[#E0E0E0] bg-white hover:border-[#D5141D] hover:shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className={`text-xs font-bold px-2 py-0.5 rounded ${
                  fc.marketplace === 'ozon' ? 'bg-[#005BFF] text-white' : 'bg-[#8B3FFD] text-white'
                }`}>
                  {fc.marketplace === 'ozon' ? 'OZON' : 'WILDBERRIES'}
                </div>
                {selectedFC === fc.id && <CheckCircle2 className="w-5 h-5 text-[#D5141D]" />}
              </div>
              <h3 className="font-semibold text-[#1A1A1A] mb-1">{fc.name}</h3>
              <p className="text-xs text-[#666] mb-3">{fc.address}</p>

              <div className="space-y-1.5 text-xs">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-[#999]" />
                  <span className="text-[#666]">{fc.acceptanceHours}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Package className="w-3.5 h-3.5 text-[#999]" />
                  <span className="text-[#666]">{fc.acceptingTypes.join(', ')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-3.5 h-3.5 text-[#999]" />
                  <span className="text-[#666]">От <strong className="text-[#1A1A1A]">{fc.palletPrice.toLocaleString('ru-RU')} ₽</strong> / паллета</span>
                </div>
              </div>

              <div className="mt-2 flex flex-wrap gap-1">
                {fc.requirements.map((req, i) => (
                  <span key={i} className="text-[10px] px-1.5 py-0.5 bg-[#F5F5F5] text-[#666] rounded">{req}</span>
                ))}
              </div>
            </button>
          ))}
        </div>

        {filteredFCs.length === 0 && (
          <div className="text-center py-8 bg-[#F5F5F5] rounded-lg mb-8">
            <Building2 className="w-10 h-10 text-[#CCC] mx-auto mb-2" />
            <p className="text-[#666]">РЦ выбранного маркетплейса в {selectedCity} не найдены</p>
          </div>
        )}

        {/* Product selection */}
        {activeFC && (
          <>
            <h2 className="text-lg font-semibold text-[#1A1A1A] mb-4">Ассортимент для отгрузки</h2>
            <div className="bg-white border border-[#E0E0E0] rounded-lg overflow-hidden mb-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[#F5F5F5]">
                    <th className="text-left p-3 w-10"></th>
                    <th className="text-left p-3">Продукт</th>
                    <th className="text-center p-3">SKU</th>
                    <th className="text-center p-3">Шт. на паллету</th>
                    <th className="text-right p-3">Цена за шт.</th>
                    <th className="text-center p-3">Кол-во паллет</th>
                    <th className="text-right p-3">Сумма</th>
                  </tr>
                </thead>
                <tbody>
                  {ecomProducts.map(p => {
                    const selected = !!selectedProducts[p.id];
                    const qty = selectedProducts[p.id] || 0;
                    return (
                      <tr key={p.id} className={`border-t border-[#F0F0F0] ${selected ? 'bg-red-50/30' : ''}`}>
                        <td className="p-3">
                          <Checkbox
                            checked={selected}
                            onCheckedChange={() => handleProductToggle(p.id)}
                          />
                        </td>
                        <td className="p-3 font-medium text-[#1A1A1A]">{p.name}</td>
                        <td className="p-3 text-center text-[#666]">{p.sku}</td>
                        <td className="p-3 text-center">{p.perPallet}</td>
                        <td className="p-3 text-right">{p.unitPrice.toLocaleString('ru-RU')} ₽</td>
                        <td className="p-3 text-center">
                          {selected && (
                            <Input
                              type="number"
                              min={1}
                              value={qty}
                              onChange={(e) => handleProductQtyChange(p.id, Number(e.target.value))}
                              className="w-16 h-8 text-center mx-auto"
                            />
                          )}
                        </td>
                        <td className="p-3 text-right font-medium">
                          {selected ? `${(p.unitPrice * p.perPallet * qty).toLocaleString('ru-RU')} ₽` : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pallet count + TC selection */}
            <div className="bg-white border border-[#E0E0E0] rounded-lg p-5 mb-6">
              <h3 className="font-semibold text-[#1A1A1A] mb-4 flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#D5141D]" />
                Доставка до РЦ
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Количество паллет</label>
                  <Input
                    type="number"
                    min={activeFC.minPallets}
                    value={palletCount}
                    onChange={(e) => setPalletCount(Math.max(activeFC.minPallets, Number(e.target.value)))}
                    className="h-10"
                  />
                  <span className="text-xs text-[#999]">Минимум: {activeFC.minPallets} палл.</span>
                </div>
                <div>
                  <label className="text-sm text-[#666] mb-1 block">Транспортная компания</label>
                  <Select value={selectedTC} onValueChange={setSelectedTC}>
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="Выберите ТК" />
                    </SelectTrigger>
                    <SelectContent>
                      {transportCompanies.map(tc => (
                        <SelectItem key={tc.id} value={tc.id}>{tc.name} — от {tc.minCost} ₽</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Delivery calculation */}
              {tc && (
                <div className="mt-4 p-4 bg-[#F5F5F5] rounded">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                    <div>
                      <div className="text-xs text-[#666]">Вес груза</div>
                      <div className="font-bold">{(850 * palletCount).toLocaleString('ru-RU')} кг</div>
                    </div>
                    <div>
                      <div className="text-xs text-[#666]">Объём</div>
                      <div className="font-bold">{(1.8 * palletCount).toFixed(1)} м³</div>
                    </div>
                    <div>
                      <div className="text-xs text-[#666]">Стоимость доставки</div>
                      <div className="font-bold text-[#D5141D]">
                        {calculateDeliveryCost(tc, 850 * palletCount, 1.8 * palletCount).toLocaleString('ru-RU')} ₽
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-[#666]">Срок доставки</div>
                      <div className="font-bold">
                        {estimateDays(tc)} {estimateDays(tc) === 1 ? 'день' : estimateDays(tc) < 5 ? 'дня' : 'дней'}
                      </div>
                    </div>
                  </div>

                  {/* All TC comparison */}
                  <h4 className="text-sm font-medium text-[#1A1A1A] mb-2">Сравнение всех ТК:</h4>
                  <div className="space-y-1.5">
                    {getDeliveryOptions(850 * palletCount, 1.8 * palletCount, geoState.city, activeFC.city).map((opt, i) => (
                      <div
                        key={opt.companyId}
                        className={`flex items-center justify-between p-2 rounded text-sm ${
                          i === 0 ? 'bg-green-50 border border-green-200' : 'bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-[#1A1A1A]">{opt.company.name}</span>
                          {i === 0 && <span className="text-[10px] px-1.5 py-0.5 bg-green-500 text-white rounded">Лучшая цена</span>}
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-[#666]">{opt.days} {opt.days === 1 ? 'день' : opt.days < 5 ? 'дня' : 'дней'}</span>
                          <span className="font-bold text-[#1A1A1A]">{opt.cost.toLocaleString('ru-RU')} ₽</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Summary */}
            {Object.keys(selectedProducts).length > 0 && (
              <div className="bg-[#2B2F3B] text-white rounded-lg p-5">
                <h3 className="font-semibold text-lg mb-3">Итоговый расчёт поставки</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                  <div>
                    <div className="text-xs text-gray-400">Товаров</div>
                    <div className="text-xl font-bold">{Object.keys(selectedProducts).length}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Паллет</div>
                    <div className="text-xl font-bold">{palletCount}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Стоимость товара</div>
                    <div className="text-xl font-bold">{totalPalletValue.toLocaleString('ru-RU')} ₽</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Доставка + приёмка</div>
                    <div className="text-xl font-bold text-[#FF6B6B]">
                      {tc
                        ? (calculateDeliveryCost(tc, 850 * palletCount, 1.8 * palletCount) + activeFC.palletPrice * palletCount).toLocaleString('ru-RU')
                        : activeFC.palletPrice * palletCount
                      } ₽
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button className="bg-[#D5141D] hover:bg-[#B01018] h-11">
                    <FileText className="w-4 h-4 mr-2" />
                    Сформировать заявку
                  </Button>
                  <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 h-11">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Скачать спецификацию
                  </Button>
                </div>
              </div>
            )}
          </>
        )}

        {/* Info block */}
        <div className="mt-8 bg-[#F5F5F5] rounded-lg p-5">
          <h3 className="font-semibold text-[#1A1A1A] mb-3">Как работает поставка на маркетплейсы</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex gap-3">
              <div className="w-8 h-8 bg-[#D5141D] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">1</div>
              <div>
                <h4 className="font-medium text-sm text-[#1A1A1A]">Выберите РЦ и ассортимент</h4>
                <p className="text-xs text-[#666]">Выберите распределительный центр Ozon или Wildberries и укажите нужные продукты</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 bg-[#D5141D] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">2</div>
              <div>
                <h4 className="font-medium text-sm text-[#1A1A1A]">Рассчитайте доставку</h4>
                <p className="text-xs text-[#666]">Сравните тарифы транспортных компаний и выберите оптимальный вариант</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 bg-[#D5141D] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">3</div>
              <div>
                <h4 className="font-medium text-sm text-[#1A1A1A]">Сформируйте заявку</h4>
                <p className="text-xs text-[#666]">Мы подготовим все документы и организуем доставку паллет до РЦ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

// Helper functions
function calculateDeliveryCost(company: typeof transportCompanies[0], weight: number, volume: number): number {
  const weightCost = weight * company.ratePerKg;
  const volumeCost = volume * company.ratePerM3;
  return Math.round(Math.max(Math.max(weightCost, volumeCost), company.minCost));
}

function estimateDays(company: typeof transportCompanies[0]): number {
  return company.minDays;
}
