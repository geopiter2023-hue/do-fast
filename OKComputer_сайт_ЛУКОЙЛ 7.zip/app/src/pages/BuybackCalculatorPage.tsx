import { useState, useMemo } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Plus, Trash2, TrendingUp, Truck, AlertTriangle, CheckCircle,
  XCircle, BarChart3, Medal, Info
} from 'lucide-react';

// ============ TYPES ============
interface Dealer {
  id: string;
  name: string;
  city: string;
  basePrice: number;      // БЦ
  specialPrice: number;   // СЦ
  buybackPrice: number;   // РЗ
  logistics: number;      // Лог_дил
}

interface GlobalSettings {
  retailPrice: number;    // Розница
  ownLogistics: number;   // Лог_своя
  minProfit: number;      // Мин. допустимая прибыль
}

interface DealerResult {
  dealer: Dealer;
  compensation: number;   // Компенсация = РЗ − СЦ
  profit: number;         // Прибыль = Розница − РЗ − Лог_дил
  ownProfit: number;      // Эталон = Розница − БЦ − Лог_своя
  share: number;          // Доля% = Прибыль / Эталон × 100
  decision: 'buy' | 'warn' | 'no';
  decisionText: string;
  decisionColor: string;
  logisticsTooHigh: boolean;
}

// ============ DECISION LOGIC ============
function getDecision(r: DealerResult, retail: number): { decision: 'buy' | 'warn' | 'no'; text: string; color: string } {
  if (r.logisticsTooHigh) {
    return { decision: 'no', text: 'Логистика слишком высокая', color: 'text-red-600 bg-red-50 border-red-200' };
  }
  if (r.profit < 0) {
    return { decision: 'no', text: 'Не выкупать (убыток)', color: 'text-red-600 bg-red-50 border-red-200' };
  }
  if (r.profit >= 0 && r.profit < 0.05 * retail) {
    return { decision: 'warn', text: 'Выкупать для удержания клиента', color: 'text-amber-700 bg-amber-50 border-amber-200' };
  }
  if (r.compensation < 0) {
    return { decision: 'warn', text: 'Дилер может отказаться', color: 'text-amber-700 bg-amber-50 border-amber-200' };
  }
  return { decision: 'buy', text: 'Выкупать', color: 'text-green-700 bg-green-50 border-green-200' };
}

// ============ PAGE COMPONENT ============
export function BuybackCalculatorPage() {
  // Global settings
  const [settings, setSettings] = useState<GlobalSettings>({
    retailPrice: 1800,
    ownLogistics: 100,
    minProfit: 0,
  });

  // Dealers
  const [dealers, setDealers] = useState<Dealer[]>([
    { id: 'd1', name: 'Дилер А', city: 'Москва', basePrice: 1000, specialPrice: 850, buybackPrice: 1200, logistics: 200 },
    { id: 'd2', name: 'Дилер Б', city: 'Санкт-Петербург', basePrice: 1050, specialPrice: 900, buybackPrice: 1250, logistics: 250 },
    { id: 'd3', name: 'Дилер В', city: 'Казань', basePrice: 980, specialPrice: 980, buybackPrice: 1100, logistics: 400 },
    { id: 'd4', name: 'Дилер Г', city: 'Новосибирск', basePrice: 1020, specialPrice: 750, buybackPrice: 1000, logistics: 500 },
  ]);

  // Auto-calculate results
  const results: DealerResult[] = useMemo(() => {
    return dealers.map(d => {
      const compensation = d.buybackPrice - d.specialPrice;
      const profit = settings.retailPrice - d.buybackPrice - d.logistics;
      const ownProfit = settings.retailPrice - d.basePrice - settings.ownLogistics;
      const share = ownProfit > 0 ? (profit / ownProfit) * 100 : 0;
      const logisticsTooHigh = d.logistics > 0.4 * settings.retailPrice;

      const r: DealerResult = {
        dealer: d,
        compensation,
        profit,
        ownProfit,
        share,
        logisticsTooHigh,
        decision: 'no',
        decisionText: '',
        decisionColor: '',
      };
      const dec = getDecision(r, settings.retailPrice);
      r.decision = dec.decision;
      r.decisionText = dec.text;
      r.decisionColor = dec.color;
      return r;
    });
  }, [dealers, settings]);

  // Best dealers
  const bestByProfit = useMemo(() => {
    const valid = results.filter(r => r.decision === 'buy');
    if (valid.length === 0) return null;
    return valid.reduce((best, r) => r.profit > best.profit ? r : best, valid[0]);
  }, [results]);

  const bestByLogistics = useMemo(() => {
    const valid = results.filter(r => r.decision !== 'no');
    if (valid.length === 0) return null;
    return valid.reduce((best, r) => r.dealer.logistics < best.dealer.logistics ? r : best, valid[0]);
  }, [results]);

  const bestByBalance = useMemo(() => {
    const valid = results.filter(r => r.decision === 'buy');
    if (valid.length === 0) return null;
    return valid.reduce((best, r) => r.compensation > best.compensation ? r : best, valid[0]);
  }, [results]);

  const finalRecommendation = bestByProfit || bestByBalance || bestByLogistics;

  // Handlers
  const addDealer = () => {
    const id = `d${Date.now()}`;
    setDealers(prev => [...prev, { id, name: '', city: '', basePrice: 0, specialPrice: 0, buybackPrice: 0, logistics: 0 }]);
  };

  const removeDealer = (id: string) => {
    setDealers(prev => prev.filter(d => d.id !== id));
  };

  const updateDealer = (id: string, field: keyof Dealer, value: string | number) => {
    setDealers(prev => prev.map(d => d.id === id ? { ...d, [field]: value } : d));
  };

  const updateSetting = (field: keyof GlobalSettings, value: number) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const setBuybackForAll = (percentOfRetail: number) => {
    setDealers(prev => prev.map(d => ({
      ...d,
      buybackPrice: Math.round(settings.retailPrice * percentOfRetail),
    })));
  };

  return (
    <main className="min-h-screen bg-[#f8fafc]">
      <Breadcrumbs items={[{ label: 'Калькулятор выкупа' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#1e293b]">
            Калькулятор обратного выкупа
          </h1>
          <p className="text-sm text-[#64748b] mt-1">
            Оценка экономической целесообразности выкупа товара у дилеров, когда товара нет на вашем складе
          </p>
        </div>

        {/* ===== GLOBAL SETTINGS ===== */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 mb-6">
          <h2 className="text-lg font-semibold text-[#1e293b] mb-4 flex items-center gap-2">
            <Info className="w-5 h-5 text-[#2563eb]" />
            Глобальные настройки
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1">Цена розницы (₽)</label>
              <Input
                type="number"
                value={settings.retailPrice}
                onChange={e => updateSetting('retailPrice', Number(e.target.value))}
                className="h-10"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1">Логистика со своего склада (₽)</label>
              <Input
                type="number"
                value={settings.ownLogistics}
                onChange={e => updateSetting('ownLogistics', Number(e.target.value))}
                className="h-10"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1">Мин. допустимая прибыль (₽)</label>
              <Input
                type="number"
                value={settings.minProfit}
                onChange={e => updateSetting('minProfit', Number(e.target.value))}
                className="h-10"
              />
            </div>
          </div>

          {/* Quick preset buttons */}
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="text-sm text-[#64748b] mr-2">Быстрая установка РЗ (% от розницы):</span>
            {[0.5, 0.55, 0.6, 0.65, 0.7].map(pct => (
              <button
                key={pct}
                onClick={() => setBuybackForAll(pct)}
                className="text-xs px-3 py-1 rounded-lg border border-[#e2e8f0] hover:border-[#2563eb] hover:text-[#2563eb] transition-colors"
              >
                {Math.round(pct * 100)}% ({Math.round(settings.retailPrice * pct)} ₽)
              </button>
            ))}
          </div>

          {/* Reference metrics */}
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Розница', value: `${settings.retailPrice.toLocaleString('ru-RU')} ₽`, color: 'text-[#1e293b]' },
              { label: 'Лог. своя', value: `${settings.ownLogistics.toLocaleString('ru-RU')} ₽`, color: 'text-[#64748b]' },
              { label: 'Макс. РЗ', value: `${(settings.retailPrice - settings.ownLogistics).toLocaleString('ru-RU')} ₽`, color: 'text-amber-600' },
              { label: 'Лимит лог.', value: `${Math.round(0.4 * settings.retailPrice).toLocaleString('ru-RU')} ₽`, color: 'text-red-500' },
            ].map(item => (
              <div key={item.label} className="bg-[#f1f5f9] rounded-lg px-3 py-2">
                <div className="text-xs text-[#94a3b8]">{item.label}</div>
                <div className={`text-sm font-bold ${item.color}`}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ===== RECOMMENDATION BANNER ===== */}
        {finalRecommendation && (
          <div className={`rounded-xl border p-5 mb-6 ${finalRecommendation.decisionColor}`}>
            <div className="flex items-center gap-3">
              {finalRecommendation.decision === 'buy' ? (
                <CheckCircle className="w-8 h-8 text-green-600 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-8 h-8 text-amber-600 flex-shrink-0" />
              )}
              <div>
                <p className="font-bold text-lg">
                  Рекомендация: выкупать у «{finalRecommendation.dealer.name}»
                </p>
                <p className="text-sm opacity-80">
                  Прибыль: {finalRecommendation.profit.toLocaleString('ru-RU')} ₽
                  {' | '}Компенсация дилеру: {finalRecommendation.compensation.toLocaleString('ru-RU')} ₽
                  {' | '}Логистика: {finalRecommendation.dealer.logistics.toLocaleString('ru-RU')} ₽
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ===== DEALERS TABLE ===== */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] overflow-hidden mb-6">
          <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between">
            <h2 className="text-lg font-semibold text-[#1e293b] flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#2563eb]" />
              Сравнение дилеров
            </h2>
            <span className="text-sm text-[#94a3b8]">{dealers.length} дилеров</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-[#f1f5f9]">
                <tr>
                  <th className="px-3 py-3 text-left font-medium text-[#64748b] w-10">#</th>
                  <th className="px-3 py-3 text-left font-medium text-[#64748b]">Дилер / Город</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">БЦ (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">СЦ (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b] min-w-[100px]">РЗ (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">Лог (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">Компенс. (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">Прибыль (₽)</th>
                  <th className="px-3 py-3 text-right font-medium text-[#64748b]">Доля %</th>
                  <th className="px-3 py-3 text-center font-medium text-[#64748b]">Решение</th>
                  <th className="px-3 py-3 w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {results.map((r, idx) => (
                  <tr key={r.dealer.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="px-3 py-3 text-[#94a3b8]">{idx + 1}</td>
                    <td className="px-3 py-3">
                      <Input
                        value={r.dealer.name}
                        onChange={e => updateDealer(r.dealer.id, 'name', e.target.value)}
                        className="h-8 text-sm mb-1"
                        placeholder="Название"
                      />
                      <Input
                        value={r.dealer.city}
                        onChange={e => updateDealer(r.dealer.id, 'city', e.target.value)}
                        className="h-7 text-xs text-[#94a3b8]"
                        placeholder="Город"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <Input
                        type="number"
                        value={r.dealer.basePrice}
                        onChange={e => updateDealer(r.dealer.id, 'basePrice', Number(e.target.value))}
                        className="h-8 text-sm text-right"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <Input
                        type="number"
                        value={r.dealer.specialPrice}
                        onChange={e => updateDealer(r.dealer.id, 'specialPrice', Number(e.target.value))}
                        className="h-8 text-sm text-right"
                      />
                      {r.dealer.buybackPrice < r.dealer.specialPrice && (
                        <p className="text-[10px] text-red-500 mt-0.5">Меньше СЦ!</p>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <Input
                        type="number"
                        value={r.dealer.buybackPrice}
                        onChange={e => updateDealer(r.dealer.id, 'buybackPrice', Number(e.target.value))}
                        className="h-8 text-sm text-right font-semibold"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <Input
                        type="number"
                        value={r.dealer.logistics}
                        onChange={e => updateDealer(r.dealer.id, 'logistics', Number(e.target.value))}
                        className={`h-8 text-sm text-right ${r.logisticsTooHigh ? 'border-red-300 bg-red-50' : ''}`}
                      />
                      {r.logisticsTooHigh && (
                        <p className="text-[10px] text-red-500 mt-0.5">&gt; 40% розницы</p>
                      )}
                    </td>
                    <td className={`px-3 py-3 text-right font-medium ${r.compensation >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                      {r.compensation.toLocaleString('ru-RU')}
                    </td>
                    <td className={`px-3 py-3 text-right font-bold ${r.profit >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                      {r.profit.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-3 text-right">
                      <span className={`font-medium ${r.share >= 80 ? 'text-green-600' : r.share >= 50 ? 'text-amber-600' : 'text-red-500'}`}>
                        {r.share.toFixed(0)}%
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium border ${r.decisionColor}`}>
                        {r.decision === 'buy' && <CheckCircle className="w-3 h-3" />}
                        {r.decision === 'warn' && <AlertTriangle className="w-3 h-3" />}
                        {r.decision === 'no' && <XCircle className="w-3 h-3" />}
                        {r.decisionText}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <button
                        onClick={() => removeDealer(r.dealer.id)}
                        className="text-[#94a3b8] hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 border-t border-[#e2e8f0]">
            <Button
              onClick={addDealer}
              variant="outline"
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Добавить дилера
            </Button>
          </div>
        </div>

        {/* ===== SUMMARY CARDS ===== */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {/* Best by profit */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] p-5">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <h3 className="font-semibold text-[#1e293b]">Лучший по прибыли</h3>
            </div>
            {bestByProfit ? (
              <div>
                <p className="text-lg font-bold text-green-600">{bestByProfit.dealer.name}</p>
                <p className="text-sm text-[#64748b]">{bestByProfit.dealer.city}</p>
                <p className="text-2xl font-bold text-[#1e293b] mt-2">
                  {bestByProfit.profit.toLocaleString('ru-RU')} ₽
                </p>
                <p className="text-xs text-[#94a3b8]">прибыль</p>
              </div>
            ) : (
              <p className="text-sm text-[#94a3b8]">Нет допустимых вариантов</p>
            )}
          </div>

          {/* Best by logistics */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Truck className="w-5 h-5 text-[#2563eb]" />
              <h3 className="font-semibold text-[#1e293b]">Лучший по логистике</h3>
            </div>
            {bestByLogistics ? (
              <div>
                <p className="text-lg font-bold text-[#2563eb]">{bestByLogistics.dealer.name}</p>
                <p className="text-sm text-[#64748b]">{bestByLogistics.dealer.city}</p>
                <p className="text-2xl font-bold text-[#1e293b] mt-2">
                  {bestByLogistics.dealer.logistics.toLocaleString('ru-RU')} ₽
                </p>
                <p className="text-xs text-[#94a3b8]">доставка</p>
              </div>
            ) : (
              <p className="text-sm text-[#94a3b8]">Нет допустимых вариантов</p>
            )}
          </div>

          {/* Best balance */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Medal className="w-5 h-5 text-amber-600" />
              <h3 className="font-semibold text-[#1e293b]">Лучший баланс</h3>
            </div>
            {bestByBalance ? (
              <div>
                <p className="text-lg font-bold text-amber-600">{bestByBalance.dealer.name}</p>
                <p className="text-sm text-[#64748b]">{bestByBalance.dealer.city}</p>
                <p className="text-2xl font-bold text-[#1e293b] mt-2">
                  {bestByBalance.compensation.toLocaleString('ru-RU')} ₽
                </p>
                <p className="text-xs text-[#94a3b8]">компенсация дилеру</p>
              </div>
            ) : (
              <p className="text-sm text-[#94a3b8]">Нет допустимых вариантов</p>
            )}
          </div>
        </div>

        {/* ===== DECISION RULES REFERENCE ===== */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6">
          <h2 className="text-lg font-semibold text-[#1e293b] mb-4">Правила принятия решений</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { color: 'green', title: 'Выкупать', text: 'Прибыль > 0 и компенсация ≥ 0', icon: CheckCircle },
              { color: 'amber', title: 'Дилер откажется', text: 'Прибыль > 0, но компенсация < 0', icon: AlertTriangle },
              { color: 'amber', title: 'Для удержания клиента', text: 'Прибыль ≥ 0, но < 5% от розницы', icon: AlertTriangle },
              { color: 'red', title: 'Не выкупать', text: 'Прибыль < 0 — убыток', icon: XCircle },
            ].map(rule => (
              <div key={rule.title} className={`rounded-lg p-3 border ${
                rule.color === 'green' ? 'bg-green-50 border-green-200' :
                rule.color === 'amber' ? 'bg-amber-50 border-amber-200' :
                'bg-red-50 border-red-200'
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  <rule.icon className={`w-4 h-4 ${
                    rule.color === 'green' ? 'text-green-600' :
                    rule.color === 'amber' ? 'text-amber-600' :
                    'text-red-600'
                  }`} />
                  <span className={`font-medium text-sm ${
                    rule.color === 'green' ? 'text-green-700' :
                    rule.color === 'amber' ? 'text-amber-700' :
                    'text-red-700'
                  }`}>{rule.title}</span>
                </div>
                <p className="text-xs text-[#64748b]">{rule.text}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 p-3 bg-[#f1f5f9] rounded-lg text-xs text-[#64748b]">
            <p className="font-medium mb-1">Формулы расчёта:</p>
            <p>Компенсация дилеру = РЗ − СЦ | Ваша прибыль = Розница − РЗ − Лог_дил | Доля% = Прибыль / (Розница − БЦ − Лог_своя) × 100</p>
            <p className="mt-1">Логистика считается слишком высокой, если {'>'} 40% от розничной цены</p>
          </div>
        </div>
      </div>
    </main>
  );
}
