import { useState } from 'react';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { FileText } from 'lucide-react';

export function CommercialOfferPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <main className="min-h-screen">
        <Breadcrumbs items={[{ label: 'Получить КП' }]} />
        <div className="max-w-[600px] mx-auto px-5 py-16 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-[#1A1A1A] mb-2">Заявка отправлена!</h2>
          <p className="text-[#666666]">Наш менеджер свяжется с вами в ближайшее время.</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Получить КП' }]} />

      <div className="max-w-[600px] mx-auto px-5 py-8">
        <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-6">
          Получить коммерческое предложение
        </h1>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm text-[#666666] mb-1">Название компании *</label>
            <Input required className="h-11" placeholder="ООО «Компания»" />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">ИНН</label>
            <Input className="h-11" placeholder="7701234567" />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">Контактное лицо *</label>
            <Input required className="h-11" placeholder="Иванов Иван Иванович" />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">Телефон *</label>
            <Input required type="tel" className="h-11" placeholder="+7 (999) 999-99-99" />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">Email *</label>
            <Input required type="email" className="h-11" placeholder="email@company.ru" />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">
              Список интересующих товаров
            </label>
            <Textarea
              className="min-h-[100px]"
              placeholder="Укажите наименования и объёмы необходимой продукции"
            />
          </div>

          <div>
            <label className="block text-sm text-[#666666] mb-1">Комментарий</label>
            <Textarea className="min-h-[80px]" placeholder="Дополнительная информация" />
          </div>

          <Button
            type="submit"
            className="w-full h-12 bg-[#D5141D] hover:bg-[#B01018] text-base"
          >
            Отправить заявку
          </Button>
        </form>
      </div>
    </main>
  );
}
