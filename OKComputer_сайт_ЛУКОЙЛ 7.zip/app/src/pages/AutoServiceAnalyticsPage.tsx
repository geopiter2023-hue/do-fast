import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, Legend
} from 'recharts';
import {
  Car, Droplets, Fuel, TrendingUp, MapPin, Wrench,
  Factory, Users, Target
} from 'lucide-react';

// ========== DATA FROM AUTOSTAT REPORT ==========

// Age structure of fleet
const ageData = [
  { age: '0-3 года (гарантия)', count: 3.73, share: 8.0, service: 'У оф. дилера' },
  { age: '4-7 лет', count: 6.54, share: 14.0, service: 'СТО + дилер' },
  { age: '8-10 лет', count: 4.85, share: 10.4, service: 'СТО' },
  { age: 'Старше 10 лет', count: 31.69, share: 67.7, service: 'СТО, механики' },
];

// Brand structure
const brandData = [
  { name: 'LADA', count: 13.38, share: 28.6, color: '#dc2626' },
  { name: 'Toyota', count: 4.30, share: 9.2, color: '#2563eb' },
  { name: 'Kia', count: 2.66, share: 5.7, color: '#7c3aed' },
  { name: 'Hyundai', count: 2.64, share: 5.6, color: '#0891b2' },
  { name: 'Nissan', count: 2.24, share: 4.8, color: '#ea580c' },
  { name: 'Renault', count: 2.23, share: 4.8, color: '#eab308' },
  { name: 'Другие', count: 19.36, share: 41.3, color: '#94a3b8' },
];

// Service market structure
const serviceData = [
  { name: 'Официальные дилеры', count: 4579, share: 3.9, color: '#dc2626' },
  { name: 'Независимые СТО', count: 43210, share: 36.8, color: '#2563eb' },
  { name: 'Узкая специализация', count: 69729, share: 59.3, color: '#64748b' },
];

// Top 5 regions
const regionData = [
  { region: 'Москва + МО', fleet: 6.98, dealers: 818, sto: 7380 },
  { region: 'СПб + ЛО', fleet: 2.40, dealers: 347, sto: 2925 },
  { region: 'Краснодарский край', fleet: 2.03, dealers: 164, sto: 2168 },
  { region: 'Татарстан', fleet: 1.38, dealers: 206, sto: 1144 },
  { region: 'Свердловская обл.', fleet: 1.41, dealers: 144, sto: 1330 },
];

// Fluid consumption calculation (annual, million liters)
const fluidConsumption = [
  {
    fluid: 'Моторное масло',
    icon: Fuel,
    frequency: '2 раза/год (активные)',
    volumePerChange: 4.5,
    activeFleet: 33.15,
    annualVolume: 298.4,
    lukoilShare: 29.8,
    revenue: 65.6,
    color: '#dc2626',
    note: 'Основной продукт — высокая частота замены'
  },
  {
    fluid: 'Тормозная жидкость',
    icon: Droplets,
    frequency: 'Раз в 2-3 года',
    volumePerChange: 1.0,
    activeFleet: 16.57,
    annualVolume: 55.2,
    lukoilShare: 5.5,
    revenue: 6.6,
    color: '#7c3aed',
    note: 'DOT-4/DOT-5.1 — рынок растёт с электромобилями'
  },
  {
    fluid: 'Антифриз/Тосол',
    icon: Wrench,
    frequency: 'Раз в 2-3 года',
    volumePerChange: 6.0,
    activeFleet: 16.57,
    annualVolume: 331.4,
    lukoilShare: 33.1,
    revenue: 23.2,
    color: '#0891b2',
    note: 'Сезонный спрос — пик в апреле-мае'
  },
  {
    fluid: 'Трансмиссионное масло',
    icon: Factory,
    frequency: 'Раз в 3-5 лет',
    volumePerChange: 5.0,
    activeFleet: 9.94,
    annualVolume: 49.7,
    lukoilShare: 5.0,
    revenue: 12.4,
    color: '#ea580c',
    note: 'ATF, МКПП — растёт с долей АКПП'
  },
  {
    fluid: 'Гидравлическое масло',
    icon: TrendingUp,
    frequency: 'Раз в 3-5 лет',
    volumePerChange: 2.0,
    activeFleet: 9.94,
    annualVolume: 19.9,
    lukoilShare: 2.0,
    revenue: 5.0,
    color: '#16a34a',
    note: 'ГУР, подвеска — стабильный спрос'
  },
];

const totalLukoilRevenue = fluidConsumption.reduce((s, f) => s + f.revenue, 0);
const totalMarketVolume = fluidConsumption.reduce((s, f) => s + f.annualVolume, 0);

// Monthly consumption seasonality
const seasonalityData = [
  { month: 'Янв', oil: 18, antifreeze: 5, brake: 3, trans: 3 },
  { month: 'Фев', oil: 16, antifreeze: 4, brake: 3, trans: 3 },
  { month: 'Мар', oil: 20, antifreeze: 8, brake: 4, trans: 4 },
  { month: 'Апр', oil: 28, antifreeze: 45, brake: 5, trans: 5 },
  { month: 'Май', oil: 30, antifreeze: 42, brake: 6, trans: 5 },
  { month: 'Июн', oil: 28, antifreeze: 25, brake: 5, trans: 5 },
  { month: 'Июл', oil: 27, antifreeze: 18, brake: 5, trans: 5 },
  { month: 'Авг', oil: 27, antifreeze: 15, brake: 5, trans: 5 },
  { month: 'Сен', oil: 26, antifreeze: 20, brake: 5, trans: 5 },
  { month: 'Окт', oil: 25, antifreeze: 35, brake: 5, trans: 5 },
  { month: 'Ноя', oil: 20, antifreeze: 38, brake: 4, trans: 4 },
  { month: 'Дек', oil: 18, antifreeze: 32, brake: 3, trans: 3 },
];

export function AutoServiceAnalyticsPage() {
  return (
    <main className="min-h-screen bg-[#f8fafc]">
      <Breadcrumbs items={[{ label: 'Аналитика автосервиса' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Car className="w-6 h-6 text-[#dc2626]" />
            <span className="text-sm text-[#64748b]">Данные: АВТОСТАТ, 2024</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-[#1e293b]">
            Рынок автосервиса России
          </h1>
          <p className="text-sm text-[#64748b] mt-1">
            Анализ потребления автомобильных жидкостей и потенциала для ЛУКОЙЛ
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-5">
              <div className="text-3xl font-bold text-[#1e293b]">46,8</div>
              <div className="text-sm text-[#64748b]">млн авто в РФ</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-3xl font-bold text-[#dc2626]">13,4</div>
              <div className="text-sm text-[#64748b]">млн LADA (28,6%)</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-3xl font-bold text-[#1e293b]">117 518</div>
              <div className="text-sm text-[#64748b]">сервисных точек</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-3xl font-bold text-[#dc2626]">68%</div>
              <div className="text-sm text-[#64748b]">авто старше 10 лет</div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Age Structure */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-4 h-4 text-[#2563eb]" />
                Возрастная структура парка (млн шт.)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={ageData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" stroke="#94a3b8" fontSize={12} />
                  <YAxis dataKey="age" type="category" width={140} stroke="#64748b" fontSize={12} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0' }} />
                  <Bar dataKey="count" fill="#2563eb" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Brand Structure */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="w-4 h-4 text-[#dc2626]" />
                Марочная структура парка
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={brandData}
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    dataKey="share"
                    nameKey="name"
                    label={({ name, share }) => `${name}: ${share}%`}
                  >
                    {brandData.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0' }} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Service Market Structure */}
        <Card className="mb-8">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Wrench className="w-4 h-4 text-[#2563eb]" />
              Структура рынка автосервиса — 117 518 точек
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              {serviceData.map(item => (
                <div key={item.name} className="text-center p-4 bg-[#f8fafc] rounded-xl">
                  <div className="text-2xl font-bold" style={{ color: item.color }}>
                    {item.count.toLocaleString('ru-RU')}
                  </div>
                  <div className="text-sm text-[#64748b]">{item.name}</div>
                  <div className="text-xs text-[#94a3b8]">{item.share}%</div>
                </div>
              ))}
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={serviceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="count" fill="#2563eb" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* ====== FLUID CONSUMPTION ANALYSIS ====== */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-[#1e293b] flex items-center gap-2 mb-4">
            <Droplets className="w-5 h-5 text-[#dc2626]" />
            Потребление автомобильных жидкостей (ежегодно)
          </h2>
          <p className="text-sm text-[#64748b] mb-4">
            Расчёт на основе активного парка 33,15 млн автомобилей с учётом среднегодового пробега 14-18 тыс. км
          </p>
        </div>

        {/* Fluid Consumption Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {fluidConsumption.map((fluid) => (
            <Card key={fluid.fluid} className="border-l-4" style={{ borderLeftColor: fluid.color }}>
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <fluid.icon className="w-5 h-5" style={{ color: fluid.color }} />
                  <h3 className="font-semibold text-[#1e293b]">{fluid.fluid}</h3>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-[#94a3b8]">Частота</span>
                    <span className="font-medium">{fluid.frequency}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#94a3b8]">Объём рынка</span>
                    <span className="font-bold text-[#1e293b]">{fluid.annualVolume.toFixed(1)} млн л/год</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#94a3b8]">Потенциал ЛУКОЙЛ (10%)</span>
                    <span className="font-bold" style={{ color: fluid.color }}>{fluid.lukoilShare.toFixed(1)} млн л/год</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#94a3b8]">Выручка ЛУКОЙЛ</span>
                    <span className="font-bold text-[#1e293b]">{fluid.revenue.toFixed(1)} млрд ₽/год</span>
                  </div>
                  <p className="text-xs text-[#94a3b8] pt-1 border-t border-[#e2e8f0]">{fluid.note}</p>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Total Card */}
          <Card className="bg-gradient-to-br from-[#dc2626] to-[#b91c1c] text-white border-0">
            <CardContent className="p-5">
              <h3 className="font-bold text-lg mb-3">Итого для ЛУКОЙЛ</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-red-100">Общий объём рынка</span>
                  <span className="font-bold">{totalMarketVolume.toFixed(1)} млн л/год</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-red-100">Потенциал ЛУКОЙЛ</span>
                  <span className="font-bold">{(totalMarketVolume * 0.1).toFixed(1)} млн л/год</span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t border-white/20 pt-2 mt-2">
                  <span>Выручка</span>
                  <span>{totalLukoilRevenue.toFixed(1)} млрд ₽/год</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Seasonality Chart */}
        <Card className="mb-8">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#2563eb]" />
              Сезонность потребления жидкостей (млн л/месяц)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={seasonalityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0' }} />
                <Legend />
                <Area type="monotone" dataKey="oil" name="Моторное масло" stackId="1" stroke="#dc2626" fill="#fecaca" />
                <Area type="monotone" dataKey="antifreeze" name="Антифриз" stackId="1" stroke="#0891b2" fill="#a5f3fc" />
                <Area type="monotone" dataKey="brake" name="Тормозная жидкость" stackId="1" stroke="#7c3aed" fill="#ddd6fe" />
                <Area type="monotone" dataKey="trans" name="Трансмиссионное" stackId="1" stroke="#ea580c" fill="#fed7aa" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Regional Data */}
        <Card className="mb-8">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#2563eb]" />
              Топ-5 регионов по потенциалу
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#f1f5f9]">
                  <tr>
                    <th className="px-4 py-3 text-left font-medium text-[#64748b]">Регион</th>
                    <th className="px-4 py-3 text-right font-medium text-[#64748b]">Парк, млн</th>
                    <th className="px-4 py-3 text-right font-medium text-[#64748b]">Оф. дилеры</th>
                    <th className="px-4 py-3 text-right font-medium text-[#64748b]">Независимые СТО</th>
                    <th className="px-4 py-3 text-right font-medium text-[#64748b]">Потенциал масла, млн л</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {regionData.map((r) => (
                    <tr key={r.region} className="hover:bg-[#f8fafc]">
                      <td className="px-4 py-3 font-medium text-[#1e293b]">{r.region}</td>
                      <td className="px-4 py-3 text-right">{r.fleet}</td>
                      <td className="px-4 py-3 text-right">{r.dealers}</td>
                      <td className="px-4 py-3 text-right">{r.sto.toLocaleString('ru-RU')}</td>
                      <td className="px-4 py-3 text-right font-bold text-[#dc2626]">{(r.fleet * 4.27).toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Key Insights for LUKOIL */}
        <Card className="mb-8">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4 text-[#dc2626]" />
              Ключевые выводы для ЛУКОЙЛ
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <h4 className="font-semibold text-[#1e293b]">Рынок</h4>
                <ul className="space-y-2 text-sm text-[#64748b]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#dc2626] font-bold">1.</span>
                    68% парка старше 10 лет — максимальная потребность в качественных маслах и расходниках
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#dc2626] font-bold">2.</span>
                    LADA — 13,4 млн авто (28,6%) — ключевой сегмент для массовых продуктов
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#dc2626] font-bold">3.</span>
                    117 518 сервисных точек — канал сбыта через независимые СТО
                  </li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold text-[#1e293b]">Потенциал</h4>
                <ul className="space-y-2 text-sm text-[#64748b]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#2563eb] font-bold">1.</span>
                    Рынок моторного масла — 298 млн л/год, потенциал ЛУКОЙЛ — 29,8 млн л (65,6 млрд ₽)
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#2563eb] font-bold">2.</span>
                    Пик антифриза — апрель-май, моторного масла — май-июнь
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#2563eb] font-bold">3.</span>
                    Москва + МО — 19 817 точек, потенциал масла 29,8 млн л/год
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer note */}
        <p className="text-xs text-[#94a3b8] text-center">
          Источник данных: Аналитическое агентство «АВТОСТАТ», «Рынок автосервиса в России», 2024.
          Расчёты потребления выполнены на основе методологии АВТОСТАТ с учётом активного парка и среднегодовой трудоёмкости.
        </p>
      </div>
    </main>
  );
}
