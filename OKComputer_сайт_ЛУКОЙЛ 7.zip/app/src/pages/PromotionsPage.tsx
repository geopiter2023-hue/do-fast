import { Breadcrumbs } from '@/components/Breadcrumbs';
import { SidebarMenu } from '@/components/SidebarMenu';

const promotions = [
  {
    id: '1',
    title: 'Покупайте больше и платите меньше',
    description: 'Специальные цены при заказе от 10 бочек моторного масла. Чем больше объём – тем выгоднее условия!',
    image: '/images/slide1-genesis.jpg',
    badge: 'Оптовые цены',
  },
  {
    id: '2',
    title: 'Дарим скидку до 10%',
    description: 'Дарим скидку до 10% на весь ассортимент каждому клиенту при первом заказе. Регистрируйтесь и получайте выгодные условия!',
    image: '/images/slide2-welcome.jpg',
    badge: 'Скидка 10%',
  },
];

export function PromotionsPage() {
  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Акции' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <SidebarMenu activeId="promotions" />

          <div className="flex-1">
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-8">Акции</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {promotions.map((promo) => (
                <div
                  key={promo.id}
                  className="group bg-white border border-[#E0E0E0] rounded overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={promo.image}
                      alt={promo.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3 bg-[#D5141D] text-white text-xs font-medium px-3 py-1 rounded">
                      {promo.badge}
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-lg font-semibold text-[#1A1A1A] mb-2 group-hover:text-[#D5141D] transition-colors">
                      {promo.title}
                    </h3>
                    <p className="text-sm text-[#666666] leading-relaxed">{promo.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
