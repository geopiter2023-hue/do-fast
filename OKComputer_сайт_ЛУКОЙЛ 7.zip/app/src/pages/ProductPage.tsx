import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { getProductById, getPopularProducts } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { ProductCard } from '@/components/ProductCard';
import { StockDisplay } from '@/components/StockDisplay';
import { StockAnalogs } from '@/components/StockAnalogs';
import { AIChat } from '@/components/AIChat';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Minus, Plus, Sparkles } from 'lucide-react';

export function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const product = getProductById(id || '');
  const { addItem } = useCart();
  const [selectedPackaging, setSelectedPackaging] = useState(product?.packaging[0]?.id || '');
  const [quantity, setQuantity] = useState(1);
  const [showAIChat, setShowAIChat] = useState(false);

  if (!product) {
    return (
      <main className="min-h-screen py-16">
        <div className="max-w-[1400px] mx-auto px-5 text-center">
          <h1 className="text-2xl font-bold text-[#1e293b] mb-4">Товар не найден</h1>
          <Link to="/catalog" className="text-[#2563eb] hover:underline">
            Вернуться в каталог
          </Link>
        </div>
      </main>
    );
  }

  const packaging = product.packaging.find((p) => p.id === selectedPackaging) || product.packaging[0];
  const popularProducts = getPopularProducts().filter((p) => p.id !== product.id).slice(0, 4);

  const handleAddToCart = () => {
    if (packaging) {
      addItem(product, packaging, quantity);
    }
  };

  return (
    <main className="min-h-screen">
      <Breadcrumbs
        items={[
          { label: 'Каталог', href: '/catalog' },
          { label: 'Моторные масла', href: '/catalog?category=motor' },
          { label: product.name },
        ]}
      />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        {/* Product Info */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
          {/* Image */}
          <div className="bg-[#f8fafc] rounded-lg p-8 flex items-center justify-center relative">
            <img
              src={product.image}
              alt={product.name}
              className="max-h-[400px] max-w-full object-contain"
            />
            {/* AI Chat button on image */}
            <button
              onClick={() => setShowAIChat(true)}
              className="absolute bottom-4 right-4 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg transition-colors"
              title="AI-консультант"
            >
              <Sparkles className="w-5 h-5" />
            </button>
          </div>

          {/* Details */}
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-[#1e293b] mb-4">
              Моторное масло {product.name} {packaging?.volume}
            </h1>

            <div className="space-y-3 mb-6">
              <div className="text-sm">
                <span className="text-[#64748b]">Артикул: </span>
                <span className="text-[#1e293b]">{product.article}</span>
              </div>
              {Object.entries(product.specs).map(([key, value]) => (
                <div key={key} className="text-sm">
                  <span className="text-[#64748b]">{key}: </span>
                  <span className="text-[#1e293b]">{value}</span>
                </div>
              ))}
            </div>

            {/* Region */}
            <div className="bg-[#FFF5F5] border border-[#FFDEDE] rounded p-4 mb-6">
              <h4 className="text-sm font-medium text-[#2563eb] mb-2">Укажите регион поставки</h4>
              <Input placeholder="Введите регион" className="h-10 text-sm" />
            </div>

            {/* Stock display */}
            <StockDisplay productId={product.id} />

            {/* Packaging Selection */}
            <div className="mb-6 mt-6">
              <h4 className="text-sm font-medium text-[#1e293b] mb-3">Фасовка:</h4>
              <div className="flex flex-wrap gap-2">
                {product.packaging.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPackaging(p.id)}
                    className={`px-4 py-2 text-sm rounded border transition-colors ${
                      selectedPackaging === p.id
                        ? 'border-[#2563eb] text-[#2563eb] bg-red-50'
                        : 'border-[#e2e8f0] text-[#1e293b] hover:border-[#2563eb]'
                    }`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-sm text-[#64748b]">Количество:</span>
              <div className="flex items-center border border-[#e2e8f0] rounded">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 flex items-center justify-center hover:bg-[#f8fafc] transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 h-10 flex items-center justify-center border-x border-[#e2e8f0] text-sm font-medium">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center hover:bg-[#f8fafc] transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="text-3xl font-bold text-[#1e293b]">
                {packaging?.price?.toLocaleString('ru-RU') || product.price.toLocaleString('ru-RU')} ₽
              </div>
              <div className="text-sm text-[#64748b]">
                за {packaging?.name || 'шт'}
              </div>
            </div>

            <Button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="w-full h-12 text-base bg-[#2563eb] hover:bg-[#1d4ed8]"
            >
              {product.inStock ? 'Добавить в корзину' : 'Нет в наличии'}
            </Button>

            {/* AI Consultant inline button */}
            <button
              onClick={() => setShowAIChat(true)}
              className="w-full mt-3 h-10 border border-[#2563eb] text-[#2563eb] rounded text-sm font-medium hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              AI-консультант по продукту
            </button>
          </div>
        </div>

        {/* Description Tabs */}
        <Tabs defaultValue="description" className="mb-12">
          <TabsList className="border-b border-[#e2e8f0] w-full justify-start rounded-none bg-transparent h-auto p-0">
            <TabsTrigger
              value="description"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563eb] data-[state=active]:text-[#2563eb] data-[state=active]:shadow-none px-6 py-3 bg-transparent"
            >
              Описание
            </TabsTrigger>
            <TabsTrigger
              value="documents"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563eb] data-[state=active]:text-[#2563eb] data-[state=active]:shadow-none px-6 py-3 bg-transparent"
            >
              Документы
            </TabsTrigger>
            <TabsTrigger
              value="analogs"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563eb] data-[state=active]:text-[#2563eb] data-[state=active]:shadow-none px-6 py-3 bg-transparent"
            >
              Аналоги
            </TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="pt-6">
            <div className="prose max-w-none text-[#1e293b] leading-relaxed">
              <p>{product.description}</p>
              <h4 className="font-semibold mt-4 mb-2">Характеристики:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {Object.entries(product.specs).map(([key, value]) => (
                  <li key={key}>
                    {key}: {value}
                  </li>
                ))}
              </ul>
            </div>
          </TabsContent>
          <TabsContent value="documents" className="pt-6">
            <p className="text-[#64748b]">
              Паспорт качества и сертификаты доступны по запросу. Свяжитесь с менеджером для получения документации.
            </p>
          </TabsContent>
          <TabsContent value="analogs" className="pt-6">
            <StockAnalogs productId={product.id} />
          </TabsContent>
        </Tabs>

        {/* Stock & Analogs section */}
        <StockAnalogs productId={product.id} />

        {/* Similar Products */}
        {popularProducts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-xl font-bold text-[#1e293b] mb-6">Популярные товары</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {popularProducts.map((p) => (
                <ProductCard key={p.id} product={p} compact />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* AI Chat Modal */}
      <AIChat product={product} isOpen={showAIChat} onClose={() => setShowAIChat(false)} />
    </main>
  );
}
