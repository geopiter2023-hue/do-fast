import { HeroSection } from '@/sections/HeroSection';
import { CategoryGrid } from '@/sections/CategoryGrid';
import { CategoryProducts } from '@/sections/CategoryProducts';
import { HowItWorks } from '@/sections/HowItWorks';
import { Advantages } from '@/sections/Advantages';
import { AboutBlock } from '@/sections/AboutBlock';

export function HomePage() {
  return (
    <main className="bg-[#f8fafc] min-h-screen">
      <HeroSection />
      <CategoryGrid />
      <CategoryProducts />
      <Advantages />
      <HowItWorks />
      <AboutBlock />
    </main>
  );
}
