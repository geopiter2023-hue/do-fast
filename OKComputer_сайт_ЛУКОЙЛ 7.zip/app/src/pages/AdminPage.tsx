import { useState } from 'react';
import { useGeolocation } from '@/hooks/useGeolocation';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import {
  BarChart3, Package, TrendingUp, TrendingDown, Truck,
  AlertTriangle, Clock, MapPin
} from 'lucide-react';

// Mock order data
const mockOrders = [
  {
    id: 'ORD-2026-0542',
    date: '2026-06-04',
    client: 'ООО «АвтоСервисПро»',
    inn: '7701234567',
    status: 'processing' as const,
    items: [
      { productId: 'lukoil-genesis-universal-5w40-barrel', name: 'GENESIS UNIVERSAL 5W-40', packaging: 'бочка 216.5 л', qty: 5, price: 84992, cost: 68000, weight: 170, from: 'Москва' },
      { productId: 'lukoil-brake-dot4', name: 'Тормозная жидкость DOT-4', packaging: 'канистра 0.455 кг', qty: 100, price: 890, cost: 650, weight: 0.5, from: 'Москва' },
      { productId: 'lukoil-transmission-80w90', name: 'ТМ-4 80W-90', packaging: 'канистра 4 л', qty: 20, price: 4200, cost: 3200, weight: 4, from: 'Санкт-Петербург' },
    ],
  },
  {
    id: 'ORD-2026-0541',
    date: '2026-06-03',
    client: 'ИП Петров А.В.',
    inn: '772512345678',
    status: 'shipped' as const,
    items: [
      { productId: 'lukoil-genesis-armortech-5w40', name: 'GENESIS ARMORTECH 5W-40', packaging: 'канистра 1 л x 12', qty: 10, price: 12720, cost: 9800, weight: 12, from: 'Екатеринбург' },
    ],
  },
  {
    id: 'ORD-2026-0540',
    date: '2026-06-03',
    client: 'ООО «ТрансЛогистика»',
    inn: '5401234567',
    status: 'pending' as const,
    items: [
      { productId: 'lukoil-coolant-blue', name: 'Антифриз G11 Синий', packaging: 'канистра 5 кг', qty: 50, price: 1800, cost: 1300, weight: 5, from: 'Казань' },
      { productId: 'lukoil-geyser-universal', name: 'ГЕЙЗЕР УНИВЕРСАЛ', packaging: 'бочка 20 л', qty: 8, price: 6462, cost: 5100, weight: 20, from: 'Нижний Новгород' },
    ],
  },
];

const statusLabels: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending: { label: 'Ожидает', color: 'bg-yellow-50 text-yellow-700', icon: <Clock className="w-4 h-4" /> },
  processing: { label: 'В обработке', color: 'bg-blue-50 text-blue-700', icon: <Package className="w-4 h-4" /> },
  shipped: { label: 'Отгружен', color: 'bg-green-50 text-green-700', icon: <Truck className="w-4 h-4" /> },
};

function OrderEfficiencyCard({ order }: { order: typeof mockOrders[0] }) {
  const { state: geoState } = useGeolocation();
  const [expanded, setExpanded] = useState(false);

  const totalRevenue = order.items.reduce((s, i) => s + i.price * i.qty, 0);
  const totalCost = order.items.reduce((s, i) => s + i.cost * i.qty, 0);
  const totalMargin = totalRevenue - totalCost;

  // Calculate logistics cost
  const logisticsCost = order.items.reduce((s, item) => {
    const distance = item.from === geoState.city ? 0 : item.from === 'Москва' ? 500 : 1200;
    const ratePerKm = 45; // rub per km per ton
    const weightTons = (item.weight * item.qty) / 1000;
    return s + (distance * ratePerKm * weightTons);
  }, 0);

  const netMargin = totalMargin - logisticsCost;
  const netMarginPercent = (netMargin / totalRevenue * 100).toFixed(1);

  const status = statusLabels[order.status];

  return (
    <div className="bg-white border border-[#E0E0E0] rounded-lg overflow-hidden">
      {/* Order header */}
      <div
        className="p-4 flex items-center justify-between cursor-pointer hover:bg-[#F9F9F9] transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-4">
          <div className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1 ${status.color}`}>
            {status.icon}
            {status.label}
          </div>
          <div>
            <div className="font-semibold text-[#1A1A1A]">{order.id}</div>
            <div className="text-xs text-[#666]">{order.date} — {order.client} (ИНН: {order.inn})</div>
          </div>
        </div>
        <div className="text-right">
          <div className="font-bold text-[#1A1A1A]">{totalRevenue.toLocaleString('ru-RU')} ₽</div>
          <div className={`text-xs ${Number(netMarginPercent) > 15 ? 'text-green-600' : Number(netMarginPercent) > 5 ? 'text-yellow-600' : 'text-red-600'}`}>
            Маржа: {netMarginPercent}%
          </div>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-[#E0E0E0] p-4">
          {/* Efficiency summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <div className="bg-[#F5F5F5] rounded p-3">
              <div className="text-xs text-[#666] mb-1">Выручка</div>
              <div className="font-bold text-[#1A1A1A]">{totalRevenue.toLocaleString('ru-RU')} ₽</div>
            </div>
            <div className="bg-[#F5F5F5] rounded p-3">
              <div className="text-xs text-[#666] mb-1">Себестоимость</div>
              <div className="font-bold text-[#1A1A1A]">{totalCost.toLocaleString('ru-RU')} ₽</div>
            </div>
            <div className="bg-[#F5F5F5] rounded p-3">
              <div className="text-xs text-[#666] mb-1">Логистика</div>
              <div className="font-bold text-[#D5141D]">{Math.round(logisticsCost).toLocaleString('ru-RU')} ₽</div>
            </div>
            <div className="bg-green-50 rounded p-3">
              <div className="text-xs text-green-700 mb-1">Чистая маржа</div>
              <div className="font-bold text-green-700">{Math.round(netMargin).toLocaleString('ru-RU')} ₽</div>
            </div>
          </div>

          {/* Items table */}
          <h4 className="text-sm font-semibold text-[#1A1A1A] mb-2">Позиции заказа</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E0E0E0]">
                  <th className="text-left py-2 pr-3 font-medium text-[#666]">Продукт</th>
                  <th className="text-left py-2 pr-3 font-medium text-[#666]">Фасовка</th>
                  <th className="text-center py-2 pr-3 font-medium text-[#666]">Кол-во</th>
                  <th className="text-right py-2 pr-3 font-medium text-[#666]">Цена</th>
                  <th className="text-right py-2 pr-3 font-medium text-[#666]">Себест.</th>
                  <th className="text-right py-2 font-medium text-[#666]">Маржа</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map((item, idx) => {
                  const itemRevenue = item.price * item.qty;
                  const itemCost = item.cost * item.qty;
                  const itemMargin = itemRevenue - itemCost;
                  const itemMarginPct = (itemMargin / itemRevenue * 100).toFixed(1);
                  const isGoodMargin = Number(itemMarginPct) > 18;

                  return (
                    <tr key={idx} className="border-b border-[#F0F0F0]">
                      <td className="py-2 pr-3">
                        <div className="font-medium text-[#1A1A1A]">{item.name}</div>
                        <div className="text-xs text-[#666] flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {item.from} → {geoState.city}
                        </div>
                      </td>
                      <td className="py-2 pr-3 text-[#666]">{item.packaging}</td>
                      <td className="py-2 pr-3 text-center">{item.qty}</td>
                      <td className="py-2 pr-3 text-right">{itemRevenue.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2 pr-3 text-right text-[#666]">{itemCost.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2 text-right">
                        <span className={isGoodMargin ? 'text-green-600' : 'text-yellow-600'}>
                          {itemMarginPct}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Analogs suggestion for low-margin items */}
          {order.items.some(i => (i.price - i.cost) / i.price * 100 < 15) && (
            <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded p-3">
              <div className="flex items-center gap-2 text-sm">
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
                <span className="font-medium text-yellow-800">Рекомендация по оптимизации</span>
              </div>
              <p className="text-xs text-yellow-700 mt-1">
                Некоторые позиции имеют низкую маржинальность (&lt;15%). Рассмотрите альтернативные продукты
                с лучшим соотношением цена/себестоимость или пересмотрите ценообразование.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function AdminPage() {
  const [activeTab, setActiveTab] = useState<'orders' | 'analytics'>('orders');

  // Totals
  const totalRevenue = mockOrders.reduce((s, o) => s + o.items.reduce((si, i) => si + i.price * i.qty, 0), 0);
  const totalCost = mockOrders.reduce((s, o) => s + o.items.reduce((si, i) => si + i.cost * i.qty, 0), 0);
  const totalMargin = totalRevenue - totalCost;

  return (
    <main className="min-h-screen bg-[#F5F5F5]">
      <Breadcrumbs items={[{ label: 'Админ-панель' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Панель управления</h1>
          <div className="flex items-center gap-1 text-sm text-[#666]">
            <BarChart3 className="w-4 h-4" />
            Аналитика B2B
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg p-4 border border-[#E0E0E0]">
            <div className="text-xs text-[#666] mb-1">Всего заказов</div>
            <div className="text-2xl font-bold text-[#1A1A1A]">{mockOrders.length}</div>
            <div className="text-xs text-green-600 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" /> +12% к прошлому месяцу
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border border-[#E0E0E0]">
            <div className="text-xs text-[#666] mb-1">Выручка</div>
            <div className="text-2xl font-bold text-[#1A1A1A]">{(totalRevenue / 1000).toFixed(0)} тыс. ₽</div>
            <div className="text-xs text-green-600 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" /> +8.5%
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border border-[#E0E0E0]">
            <div className="text-xs text-[#666] mb-1">Средняя маржа</div>
            <div className="text-2xl font-bold text-[#1A1A1A]">{(totalMargin / totalRevenue * 100).toFixed(1)}%</div>
            <div className="text-xs text-yellow-600 flex items-center gap-1 mt-1">
              <TrendingDown className="w-3 h-3" /> -1.2%
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border border-[#E0E0E0]">
            <div className="text-xs text-[#666] mb-1">Затраты на логистику</div>
            <div className="text-2xl font-bold text-[#D5141D]">45.2 тыс. ₽</div>
            <div className="text-xs text-[#666] mt-1">3.2% от выручки</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded text-sm font-medium transition-colors ${
              activeTab === 'orders' ? 'bg-[#D5141D] text-white' : 'bg-white text-[#1A1A1A] hover:bg-[#F0F0F0]'
            }`}
          >
            <Package className="w-4 h-4 inline mr-1.5" />
            Заказы
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-2 rounded text-sm font-medium transition-colors ${
              activeTab === 'analytics' ? 'bg-[#D5141D] text-white' : 'bg-white text-[#1A1A1A] hover:bg-[#F0F0F0]'
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-1.5" />
            Эффективность
          </button>
        </div>

        {activeTab === 'orders' ? (
          <div className="space-y-3">
            {mockOrders.map((order) => (
              <OrderEfficiencyCard key={order.id} order={order} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-[#E0E0E0] p-6">
            <h3 className="text-lg font-semibold text-[#1A1A1A] mb-4">Аналитика эффективности</h3>

            {/* Product efficiency chart (table) */}
            <h4 className="text-sm font-semibold text-[#1A1A1A] mb-3">Эффективность по продуктам</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-[#333]">
                    <th className="text-left py-2 pr-3 font-medium">Продукт</th>
                    <th className="text-center py-2 pr-3 font-medium">Заказов</th>
                    <th className="text-right py-2 pr-3 font-medium">Выручка</th>
                    <th className="text-right py-2 pr-3 font-medium">Себест.</th>
                    <th className="text-right py-2 pr-3 font-medium">Логистика</th>
                    <th className="text-right py-2 pr-3 font-medium">Маржа</th>
                    <th className="text-right py-2 font-medium">Маржа %</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: 'GENESIS UNIVERSAL 5W-40', orders: 12, revenue: 425000, cost: 340000, logistics: 8500, margin: 76500 },
                    { name: 'GENESIS ARMORTECH 5W-40', orders: 8, revenue: 102000, cost: 78400, logistics: 3200, margin: 20400 },
                    { name: 'Тормозная жидкость DOT-4', orders: 15, revenue: 89000, cost: 65000, logistics: 1200, margin: 22800 },
                    { name: 'Антифриз G11', orders: 6, revenue: 90000, cost: 65000, logistics: 4500, margin: 20500 },
                    { name: 'ГЕЙЗЕР УНИВЕРСАЛ', orders: 4, revenue: 51700, cost: 40800, logistics: 2800, margin: 8100 },
                  ].map((row, i) => (
                    <tr key={i} className="border-b border-[#E0E0E0]">
                      <td className="py-2.5 pr-3 font-medium text-[#1A1A1A]">{row.name}</td>
                      <td className="py-2.5 pr-3 text-center">{row.orders}</td>
                      <td className="py-2.5 pr-3 text-right">{row.revenue.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2.5 pr-3 text-right text-[#666]">{row.cost.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2.5 pr-3 text-right text-[#D5141D]">{row.logistics.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2.5 pr-3 text-right text-green-600">{row.margin.toLocaleString('ru-RU')} ₽</td>
                      <td className="py-2.5 text-right font-medium">
                        <span className={row.margin / row.revenue > 0.18 ? 'text-green-600' : row.margin / row.revenue > 0.12 ? 'text-yellow-600' : 'text-red-600'}>
                          {(row.margin / row.revenue * 100).toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Logistics breakdown */}
            <h4 className="text-sm font-semibold text-[#1A1A1A] mt-6 mb-3">Затраты на логистику по направлениям</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-[#F5F5F5] rounded p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="w-4 h-4 text-[#D5141D]" />
                  <span className="text-sm font-medium">Москва → регионы</span>
                </div>
                <div className="text-lg font-bold">18.5 тыс. ₽</div>
                <div className="text-xs text-[#666]">41% от общих затрат</div>
                <div className="w-full h-2 bg-[#E0E0E0] rounded mt-2">
                  <div className="h-full bg-[#D5141D] rounded" style={{ width: '41%' }} />
                </div>
              </div>
              <div className="bg-[#F5F5F5] rounded p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">СПб → Северо-Запад</span>
                </div>
                <div className="text-lg font-bold">12.3 тыс. ₽</div>
                <div className="text-xs text-[#666]">27% от общих затрат</div>
                <div className="w-full h-2 bg-[#E0E0E0] rounded mt-2">
                  <div className="h-full bg-yellow-500 rounded" style={{ width: '27%' }} />
                </div>
              </div>
              <div className="bg-[#F5F5F5] rounded p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="w-4 h-4 text-green-500" />
                  <span className="text-sm font-medium">Урал → Сибирь</span>
                </div>
                <div className="text-lg font-bold">14.4 тыс. ₽</div>
                <div className="text-xs text-[#666]">32% от общих затрат</div>
                <div className="w-full h-2 bg-[#E0E0E0] rounded mt-2">
                  <div className="h-full bg-green-500 rounded" style={{ width: '32%' }} />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
