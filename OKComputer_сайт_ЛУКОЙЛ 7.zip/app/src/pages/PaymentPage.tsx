import { SidebarMenu } from '@/components/SidebarMenu';
import { Breadcrumbs } from '@/components/Breadcrumbs';

export function PaymentPage() {
  return (
    <main className="min-h-screen">
      <Breadcrumbs items={[{ label: 'Оплата' }]} />

      <div className="max-w-[1400px] mx-auto px-5 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <SidebarMenu activeId="payment" />

          <div className="flex-1">
            <h1 className="text-2xl md:text-[32px] font-bold text-[#1A1A1A] mb-6">Оплата</h1>

            <div className="prose max-w-none text-[#1A1A1A] leading-relaxed space-y-4">
              <p>
                В интернет-магазине смазочных материалов ЛУКОЙЛ доступен способ оплаты —{' '}
                <strong>оплата по выставленному счету</strong>.
              </p>
              <p>
                Счёт по заказу генерируется автоматически после оформления Заказа. При генерации
                счёта направляется письмо со ссылкой на скачивание счёта (проверьте спам, если
                письмо не поступило). Для скачивания счёт доступен в Заказе личного кабинета клиента
                интернет-магазина.
              </p>
              <p>
                Для корректного выставления счёта, проверки поступления денежных средств и
                формирования сопроводительных документов, пожалуйста корректно указывайте реквизиты
                плательщика (клиента), а также прикрепляйте скан-копии необходимых документов к
                профилю плательщика (клиента) в личном кабинете.
              </p>
              <p>
                Продавцом является компания <strong>ООО «ЛЛК-Интернешнл»</strong> — производитель
                смазочных материалов ЛУКОЙЛ.
              </p>
              <p>
                Предоплата за заказ производится полной суммой на р/с поставщика{' '}
                <strong>ООО «ИндигоЛаб Рус»</strong>.
              </p>
            </div>

            <div className="mt-8 bg-[#F5F5F5] rounded p-6">
              <h3 className="font-semibold text-[#1A1A1A] mb-4">Реквизиты компании:</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="text-[#666666]">ИНН: </span>
                  <span className="text-[#1A1A1A]">7725287963</span>
                </div>
                <div>
                  <span className="text-[#666666]">КПП: </span>
                  <span className="text-[#1A1A1A]">772601001</span>
                </div>
                <div>
                  <span className="text-[#666666]">Банк получателя: </span>
                  <span className="text-[#1A1A1A]">ПАО «Сбербанк России» г. Москва</span>
                </div>
                <div>
                  <span className="text-[#666666]">Расчетный счет: </span>
                  <span className="text-[#1A1A1A]">40702810338000073476</span>
                </div>
                <div>
                  <span className="text-[#666666]">БИК: </span>
                  <span className="text-[#1A1A1A]">044525225</span>
                </div>
                <div>
                  <span className="text-[#666666]">Корр. счет: </span>
                  <span className="text-[#1A1A1A]">30101810400000000225</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
