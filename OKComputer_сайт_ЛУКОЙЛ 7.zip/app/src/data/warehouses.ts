export interface WarehouseStock {
  city: string;
  quantity: number;
  availableDate: string;
}

export const warehouses: Record<string, WarehouseStock[]> = {
  'lukoil-avantgarde-ultra-10w40': [
    { city: 'Москва', quantity: 45, availableDate: 'завтра 10:00' },
    { city: 'Санкт-Петербург', quantity: 23, availableDate: 'послезавтра 14:00' },
    { city: 'Казань', quantity: 12, availableDate: 'через 3 дня' },
    { city: 'Нижний Новгород', quantity: 8, availableDate: 'послезавтра 12:00' },
    { city: 'Екатеринбург', quantity: 6, availableDate: 'через 5 дней' },
    { city: 'Новосибирск', quantity: 3, availableDate: 'через 6 дней' },
    { city: 'Ростов-на-Дону', quantity: 0, availableDate: 'нет' },
  ],
  'lukoil-genesis-armortech-5w40': [
    { city: 'Москва', quantity: 120, availableDate: 'сегодня 16:00' },
    { city: 'Санкт-Петербург', quantity: 67, availableDate: 'завтра 12:00' },
    { city: 'Нижний Новгород', quantity: 56, availableDate: 'завтра 14:00' },
    { city: 'Казань', quantity: 34, availableDate: 'через 3 дня' },
    { city: 'Ростов-на-Дону', quantity: 21, availableDate: 'через 3 дня' },
    { city: 'Екатеринбург', quantity: 15, availableDate: 'через 4 дня' },
    { city: 'Новосибирск', quantity: 9, availableDate: 'через 5 дней' },
  ],
  'lukoil-genesis-universal-10w40': [
    { city: 'Москва', quantity: 89, availableDate: 'сегодня 18:00' },
    { city: 'Санкт-Петербург', quantity: 45, availableDate: 'завтра 10:00' },
    { city: 'Нижний Новгород', quantity: 22, availableDate: 'завтра 16:00' },
    { city: 'Ростов-на-Дону', quantity: 11, availableDate: 'через 3 дня' },
    { city: 'Екатеринбург', quantity: 7, availableDate: 'через 4 дня' },
    { city: 'Новосибирск', quantity: 4, availableDate: 'через 5 дней' },
    { city: 'Казань', quantity: 0, availableDate: 'нет' },
  ],
  'lukoil-genesis-armortech-jp-5w30': [
    { city: 'Москва', quantity: 67, availableDate: 'сегодня 15:00' },
    { city: 'Санкт-Петербург', quantity: 34, availableDate: 'завтра 11:00' },
    { city: 'Нижний Новгород', quantity: 29, availableDate: 'завтра 13:00' },
    { city: 'Казань', quantity: 18, availableDate: 'через 3 дня' },
    { city: 'Екатеринбург', quantity: 10, availableDate: 'через 4 дня' },
    { city: 'Новосибирск', quantity: 5, availableDate: 'через 5 дней' },
    { city: 'Ростов-на-Дону', quantity: 0, availableDate: 'нет' },
  ],
  'lukoil-genesis-universal-5w40-barrel': [
    { city: 'Москва', quantity: 200, availableDate: 'сегодня 12:00' },
    { city: 'Санкт-Петербург', quantity: 85, availableDate: 'завтра 09:00' },
    { city: 'Екатеринбург', quantity: 5, availableDate: 'через 4 дня' },
    { city: 'Казань', quantity: 0, availableDate: 'нет' },
    { city: 'Новосибирск', quantity: 0, availableDate: 'нет' },
  ],
  'lukoil-geyser-universal': [
    { city: 'Москва', quantity: 30, availableDate: 'завтра 11:00' },
    { city: 'Санкт-Петербург', quantity: 15, availableDate: 'через 2 дня' },
    { city: 'Нижний Новгород', quantity: 8, availableDate: 'через 3 дня' },
    { city: 'Екатеринбург', quantity: 0, availableDate: 'нет' },
  ],
  'lukoil-stabio-68': [
    { city: 'Москва', quantity: 50, availableDate: 'сегодня 14:00' },
    { city: 'Санкт-Петербург', quantity: 25, availableDate: 'завтра 10:00' },
    { city: 'Казань', quantity: 12, availableDate: 'через 3 дня' },
  ],
  'lukoil-transmission-80w90': [
    { city: 'Москва', quantity: 80, availableDate: 'сегодня 13:00' },
    { city: 'Санкт-Петербург', quantity: 40, availableDate: 'завтра 12:00' },
    { city: 'Нижний Новгород', quantity: 20, availableDate: 'через 2 дня' },
  ],
  'lukoil-coolant-blue': [
    { city: 'Москва', quantity: 200, availableDate: 'сегодня 10:00' },
    { city: 'Санкт-Петербург', quantity: 150, availableDate: 'завтра 09:00' },
    { city: 'Казань', quantity: 80, availableDate: 'завтра 15:00' },
  ],
  'lukoil-brake-dot4': [
    { city: 'Москва', quantity: 500, availableDate: 'сегодня 11:00' },
    { city: 'Санкт-Петербург', quantity: 300, availableDate: 'завтра 10:00' },
    { city: 'Екатеринбург', quantity: 100, availableDate: 'через 3 дня' },
  ],
  'lukoil-genesis-racing-5w50': [
    { city: 'Москва', quantity: 0, availableDate: 'нет' },
    { city: 'Санкт-Петербург', quantity: 0, availableDate: 'нет' },
    { city: 'Екатеринбург', quantity: 0, availableDate: 'нет' },
  ],
};

export function getStockForProduct(productId: string): WarehouseStock[] {
  return warehouses[productId] || [
    { city: 'Москва', quantity: Math.floor(Math.random() * 100) + 10, availableDate: 'сегодня 14:00' },
    { city: 'Санкт-Петербург', quantity: Math.floor(Math.random() * 50) + 5, availableDate: 'завтра 10:00' },
    { city: 'Екатеринбург', quantity: Math.floor(Math.random() * 20), availableDate: 'через 4 дня' },
  ];
}

export function getNearestStock(productId: string, city: string = 'Москва'): WarehouseStock | undefined {
  const stocks = getStockForProduct(productId);
  return stocks.find(s => s.city === city) || stocks.find(s => s.quantity > 0);
}
