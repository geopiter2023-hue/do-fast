export interface TransportCompany {
  id: string;
  name: string;
  logo: string;
  ratePerKg: number;
  ratePerM3: number;
  minCost: number;
  maxDays: number;
  minDays: number;
  trackingUrl: string;
  services: string[];
}

export interface DeliveryOption {
  companyId: string;
  company: TransportCompany;
  cost: number;
  days: number;
  weight: number;
  volume: number;
}

export const transportCompanies: TransportCompany[] = [
  {
    id: 'cdek',
    name: 'СДЭК',
    logo: '/images/tc/cdek.png',
    ratePerKg: 45,
    ratePerM3: 3200,
    minCost: 450,
    minDays: 2,
    maxDays: 5,
    trackingUrl: 'https://www.cdek.ru/ru/tracking',
    services: ['До двери', 'До пункта выдачи', 'Экспресс'],
  },
  {
    id: 'delovye_linii',
    name: 'Деловые Линии',
    logo: '/images/tc/dl.png',
    ratePerKg: 38,
    ratePerM3: 2800,
    minCost: 650,
    minDays: 3,
    maxDays: 7,
    trackingUrl: 'https://www.dellin.ru/tracking/',
    services: ['Терминал-терминал', 'Терминал-дверь', 'Дверь-дверь'],
  },
  {
    id: 'pek',
    name: 'ПЭК',
    logo: '/images/tc/pek.png',
    ratePerKg: 42,
    ratePerM3: 3000,
    minCost: 550,
    minDays: 3,
    maxDays: 6,
    trackingUrl: 'https://pecom.ru/tracking/',
    services: ['Склад-склад', 'Склад-дверь', 'Дверь-дверь'],
  },
  {
    id: 'baikal',
    name: 'Байкал-Сервис',
    logo: '/images/tc/baikal.png',
    ratePerKg: 35,
    ratePerM3: 2500,
    minCost: 500,
    minDays: 3,
    maxDays: 8,
    trackingUrl: 'https://baikalsr.ru/tracking/',
    services: ['До терминала', 'До двери'],
  },
  {
    id: 'zheldorekspeditsia',
    name: 'ЖелДорЭкспедиция',
    logo: '/images/tc/zde.png',
    ratePerKg: 28,
    ratePerM3: 2200,
    minCost: 800,
    minDays: 5,
    maxDays: 12,
    trackingUrl: 'https://www.jde.ru/online/tracking',
    services: ['Ж/Д перевозка', 'Авто', 'Мультимодальная'],
  },
  {
    id: 'dostavista',
    name: 'Достависта (B2B)',
    logo: '/images/tc/dostavista.png',
    ratePerKg: 85,
    ratePerM3: 5500,
    minCost: 1200,
    minDays: 1,
    maxDays: 2,
    trackingUrl: 'https://dostavista.ru/tracking',
    services: ['Экспресс', 'Сверхсрочная'],
  },
];

export interface ECOMFulfillmentCenter {
  id: string;
  marketplace: 'ozon' | 'wildberries';
  name: string;
  city: string;
  address: string;
  acceptingTypes: string[];
  palletPrice: number;
  minPallets: number;
  acceptanceHours: string;
  requirements: string[];
}

export const fulfillmentCenters: ECOMFulfillmentCenter[] = [
  // OZON
  {
    id: 'ozon-sc-moscow-1',
    marketplace: 'ozon',
    name: 'OZON СЦ Хоругвино',
    city: 'Москва',
    address: 'г. Москва, ул. Сходненская, д. 18, стр. 1',
    acceptingTypes: ['Паллеты', 'Короба', 'Монопаллеты'],
    palletPrice: 2850,
    minPallets: 1,
    acceptanceHours: 'Пн-Пт 08:00–22:00, Сб 09:00–18:00',
    requirements: ['SSCC-этикетки', 'Упаковочный лист', 'Предварительное бронирование'],
  },
  {
    id: 'ozon-sc-spb-1',
    marketplace: 'ozon',
    name: 'OZON СЦ Шушары',
    city: 'Санкт-Петербург',
    address: 'г. Санкт-Петербург, пос. Шушары, Приклонское ш., д. 1',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 3100,
    minPallets: 1,
    acceptanceHours: 'Пн-Пт 09:00–21:00',
    requirements: ['SSCC-этикетки', 'Штрихкоды Ozon'],
  },
  {
    id: 'ozon-sc-kazan-1',
    marketplace: 'ozon',
    name: 'OZON СЦ Казань',
    city: 'Казань',
    address: 'г. Казань, ул. Техническая, д. 12',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 2950,
    minPallets: 1,
    acceptanceHours: 'Пн-Пт 08:00–20:00',
    requirements: ['SSCC-этикетки'],
  },
  {
    id: 'ozon-sc-ekb-1',
    marketplace: 'ozon',
    name: 'OZON СЦ Екатеринбург',
    city: 'Екатеринбург',
    address: 'г. Екатеринбург, ул. Промышленная, д. 5',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 3200,
    minPallets: 1,
    acceptanceHours: 'Пн-Пт 09:00–19:00',
    requirements: ['SSCC-этикетки', 'Предварительное бронирование'],
  },
  {
    id: 'ozon-sc-novosib-1',
    marketplace: 'ozon',
    name: 'OZON СЦ Новосибирск',
    city: 'Новосибирск',
    address: 'г. Новосибирск, ул. Складская, д. 8',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 3400,
    minPallets: 2,
    acceptanceHours: 'Пн-Пт 08:00–18:00',
    requirements: ['SSCC-этикетки', 'Минимум 2 паллеты'],
  },
  // Wildberries
  {
    id: 'wb-sc-moscow-1',
    marketplace: 'wildberries',
    name: 'WB СЦ Подольск',
    city: 'Москва',
    address: 'г. Подольск, ул. Большая Серпуховская, д. 50',
    acceptingTypes: ['Паллеты', 'Короба', 'Монопаллеты'],
    palletPrice: 2650,
    minPallets: 1,
    acceptanceHours: 'Пн-Вс 08:00–23:00',
    requirements: ['WB-штрихкоды', 'Упаковочный лист', 'QR-код поставки'],
  },
  {
    id: 'wb-sc-spb-1',
    marketplace: 'wildberries',
    name: 'WB СЦ Шушары',
    city: 'Санкт-Петербург',
    address: 'г. Санкт-Петербург, пос. Шушары, Московское ш., д. 14',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 2900,
    minPallets: 1,
    acceptanceHours: 'Пн-Вс 09:00–22:00',
    requirements: ['WB-штрихкоды', 'QR-код поставки'],
  },
  {
    id: 'wb-sc-kazan-1',
    marketplace: 'wildberries',
    name: 'WB СЦ Казань',
    city: 'Казань',
    address: 'г. Казань, ул. Логистическая, д. 3',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 2800,
    minPallets: 1,
    acceptanceHours: 'Пн-Вс 08:00–21:00',
    requirements: ['WB-штрихкоды'],
  },
  {
    id: 'wb-sc-ekb-1',
    marketplace: 'wildberries',
    name: 'WB СЦ Екатеринбург',
    city: 'Екатеринбург',
    address: 'г. Екатеринбург, ул. Тепловозная, д. 22',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 3050,
    minPallets: 1,
    acceptanceHours: 'Пн-Вс 09:00–20:00',
    requirements: ['WB-штрихкоды', 'QR-код поставки'],
  },
  {
    id: 'wb-sc-krasnodar-1',
    marketplace: 'wildberries',
    name: 'WB СЦ Краснодар',
    city: 'Краснодар',
    address: 'г. Краснодар, ул. Северная, д. 300',
    acceptingTypes: ['Паллеты', 'Короба'],
    palletPrice: 2950,
    minPallets: 1,
    acceptanceHours: 'Пн-Вс 08:00–22:00',
    requirements: ['WB-штрихкоды'],
  },
];

export function calculateDeliveryCost(
  company: TransportCompany,
  weightKg: number,
  volumeM3: number,
  distanceKm: number = 500
): number {
  const weightCost = weightKg * company.ratePerKg;
  const volumeCost = volumeM3 * company.ratePerM3;
  const distanceMultiplier = 1 + (distanceKm / 5000);
  const cost = Math.max(weightCost, volumeCost) * distanceMultiplier;
  return Math.round(Math.max(cost, company.minCost));
}

export function estimateDays(company: TransportCompany, distanceKm: number = 500): number {
  const extraDays = Math.floor(distanceKm / 1500);
  return Math.min(company.minDays + extraDays, company.maxDays);
}

export function getDeliveryOptions(
  weightKg: number,
  volumeM3: number,
  _fromCity: string = 'Москва',
  toCity: string = 'Екатеринбург'
): DeliveryOption[] {
  const distances: Record<string, number> = {
    'Москва': 0,
    'Санкт-Петербург': 700,
    'Казань': 800,
    'Нижний Новгород': 400,
    'Екатеринбург': 1800,
    'Новосибирск': 3300,
    'Ростов-на-Дону': 1100,
    'Краснодар': 1350,
  };

  const distance = distances[toCity] || 500;

  return transportCompanies.map((company) => ({
    companyId: company.id,
    company,
    cost: calculateDeliveryCost(company, weightKg, volumeM3, distance),
    days: estimateDays(company, distance),
    weight: weightKg,
    volume: volumeM3,
  })).sort((a, b) => a.cost - b.cost);
}
