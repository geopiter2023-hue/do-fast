import { products } from './products';
import { getStockForProduct } from './warehouses';
import type { Product } from '@/types';

export interface AnalogMatch {
  product: Product;
  matchScore: number;
  matchReasons: string[];
}

export function findAnalogs(productId: string, limit: number = 3): AnalogMatch[] {
  const source = products.find(p => p.id === productId);
  if (!source) return [];

  const scored = products
    .filter(p => p.id !== productId && p.inStock)
    .map(p => {
      let score = 0;
      const reasons: string[] = [];

      // Same viscosity = strong match (35 pts)
      if (p.viscosity === source.viscosity) {
        score += 35;
        reasons.push(`Вязкость ${p.viscosity}`);
      }

      // Same API classification (25 pts)
      if (p.api === source.api) {
        score += 25;
        reasons.push(`Класс ${p.api}`);
      }

      // Same type (synthetic/semi/mineral) (20 pts)
      if (p.type === source.type) {
        score += 20;
        reasons.push(p.type === 'synthetic' ? 'Синтетическое' : p.type === 'semi-synthetic' ? 'Полусинтетическое' : 'Минеральное');
      }

      // Same category (15 pts)
      if (p.category === source.category) {
        score += 15;
        reasons.push('Тот же тип');
      }

      // Similar price range (+/- 30%) (5 pts)
      const priceRatio = p.price / source.price;
      if (priceRatio >= 0.7 && priceRatio <= 1.3) {
        score += 5;
        reasons.push('Схожая цена');
      }

      return { product: p, matchScore: score, matchReasons: reasons };
    })
    .filter(m => m.matchScore >= 20)
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, limit);

  return scored;
}

export function findLowStockAnalogs(productId: string, city: string = 'Москва', limit: number = 3): AnalogMatch[] {
  const stocks = getStockForProduct(productId);
  const cityStock = stocks.find(s => s.city === city);

  if (!cityStock || cityStock.quantity === 0 || cityStock.quantity < 5) {
    return findAnalogs(productId, limit);
  }

  return [];
}
