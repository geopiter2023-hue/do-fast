// Stock level labels — textual instead of numeric

export interface StockLabel {
  text: string;
  color: string;
  bgColor: string;
}

export function getStockLabel(stockTotal: number): StockLabel {
  if (stockTotal >= 50) {
    return { text: 'Много', color: 'text-green-700', bgColor: 'bg-green-50' };
  } else if (stockTotal >= 20) {
    return { text: 'Достаточно', color: 'text-emerald-600', bgColor: 'bg-emerald-50' };
  } else if (stockTotal >= 5) {
    return { text: 'Мало', color: 'text-orange-600', bgColor: 'bg-orange-50' };
  } else if (stockTotal > 0) {
    return { text: 'Осталось мало', color: 'text-red-600', bgColor: 'bg-red-50' };
  } else {
    return { text: 'Под заказ', color: 'text-gray-500', bgColor: 'bg-gray-100' };
  }
}

// Category banner configs — inline CSS gradients (NOT Tailwind classes)
export const categoryBannerConfig: Record<string, {
  background: string;
  textColor: string;
  accentColor: string;
  iconBg: string;
}> = {
  'motor': {
    background: 'linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%)',
    textColor: '#ffffff',
    accentColor: '#bfdbfe',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'industrial': {
    background: 'linear-gradient(135deg, #92400e 0%, #d97706 50%, #f59e0b 100%)',
    textColor: '#ffffff',
    accentColor: '#fde68a',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'transmission': {
    background: 'linear-gradient(135deg, #374151 0%, #6b7280 50%, #9ca3af 100%)',
    textColor: '#ffffff',
    accentColor: '#d1d5db',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'coolant': {
    background: 'linear-gradient(135deg, #0e7490 0%, #06b6d4 50%, #22d3ee 100%)',
    textColor: '#ffffff',
    accentColor: '#a5f3fc',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'brake': {
    background: 'linear-gradient(135deg, #9a3412 0%, #ea580c 50%, #fb923c 100%)',
    textColor: '#ffffff',
    accentColor: '#fed7aa',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'greases': {
    background: 'linear-gradient(135deg, #166534 0%, #16a34a 50%, #4ade80 100%)',
    textColor: '#ffffff',
    accentColor: '#bbf7d0',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'chemistry': {
    background: 'linear-gradient(135deg, #6b21a8 0%, #a855f7 50%, #c084fc 100%)',
    textColor: '#ffffff',
    accentColor: '#e9d5ff',
    iconBg: 'rgba(255,255,255,0.2)',
  },
  'coolant-grease': {
    background: 'linear-gradient(135deg, #0f766e 0%, #14b8a6 50%, #2dd4bf 100%)',
    textColor: '#ffffff',
    accentColor: '#99f6e4',
    iconBg: 'rgba(255,255,255,0.2)',
  },
};
