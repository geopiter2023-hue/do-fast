import type { Category, NavItem, SidebarMenuItem, SliderSlide, Advantage, HowItWorkStep } from '@/types';

export const mainNav: NavItem[] = [
  { label: 'Каталог', href: '/catalog' },
  { label: 'Доставка', href: '/delivery' },
  { label: 'Оплата', href: '/payment' },
  { label: 'О компании', href: '/about' },
  { label: 'Подбор масла', href: '/oil-selector' },
  { label: 'Акции', href: '/promotions' },
  { label: 'Кредит', href: '/credit-payment.html' },
  { label: 'Аналитика', href: '/analytics' },
];

export const categories: Category[] = [
  {
    id: 'motor',
    name: 'Моторные масла',
    image: '/images/canister-genesis.png',
    href: '/catalog?category=motor',
    subcategories: [
      { id: '5w30', name: '5W30', href: '/catalog?viscosity=5W-30' },
      { id: '5w40', name: '5W40', href: '/catalog?viscosity=5W-40' },
      { id: '10w40', name: '10W40', href: '/catalog?viscosity=10W-40' },
      { id: '0w20', name: '0W20', href: '/catalog?viscosity=0W-20' },
    ],
  },
  {
    id: 'transmission',
    name: 'Трансмиссионные масла',
    image: '/images/canister-transmission.png',
    href: '/catalog?category=transmission',
    subcategories: [
      { id: '80w90', name: '80W90', href: '/catalog?viscosity=80W-90' },
      { id: '75w90', name: '75W90', href: '/catalog?viscosity=75W-90' },
      { id: '85w140', name: '85W140', href: '/catalog?viscosity=85W-140' },
    ],
  },
  {
    id: 'industrial',
    name: 'Индустриальные масла',
    image: '/images/barrel-industrial.png',
    href: '/catalog?category=industrial',
    subcategories: [
      { id: 'visc-68', name: 'Вязкость 68', href: '/catalog?viscosity=68' },
      { id: 'visc-46', name: 'Вязкость 46', href: '/catalog?viscosity=46' },
      { id: 'visc-32', name: 'Вязкость 32', href: '/catalog?viscosity=32' },
    ],
  },
];

export const allCategories = [
  { id: 'motor', name: 'Моторные масла', href: '/catalog?category=motor' },
  { id: 'industrial', name: 'Индустриальные масла', href: '/catalog?category=industrial' },
  { id: 'transmission', name: 'Трансмиссионные масла', href: '/catalog?category=transmission' },
  { id: 'coolant', name: 'Охлаждающие жидкости', href: '/catalog?category=coolant' },
  { id: 'brake', name: 'Тормозные жидкости', href: '/catalog?category=brake' },
  { id: 'greases', name: 'Пластичные смазки', href: '/catalog?category=greases' },
  { id: 'chemistry', name: 'Автомобильная химия', href: '/catalog?category=chemistry' },
  { id: 'coolant-grease', name: 'Пластично-охлаждающие жидкости', href: '/catalog?category=coolant-grease' },
];

export const sidebarMenuItems: SidebarMenuItem[] = [
  { id: 'promotions', label: 'Акции', href: '/promotions' },
  { id: 'analytics', label: 'Аналитика рынка', href: '/analytics' },
  { id: 'credit', label: 'Оплата в кредит', href: '/credit-payment.html' },
  { id: 'buyback', label: 'Калькулятор выкупа', href: '/buyback-calculator' },
  { id: 'about', label: 'О нас', href: '/about' },
  { id: 'delivery', label: 'Доставка и самовывоз', href: '/delivery' },
  { id: 'payment', label: 'Оплата', href: '/payment' },
  { id: 'receiving', label: 'Как принимать товар', href: '/delivery' },
  { id: 'privacy', label: 'Конфиденциальность', href: '/about' },
  { id: 'contacts', label: 'Контакты', href: '/about' },
  { id: 'offer', label: 'Оферта', href: '/about' },
];

export const footerCatalog = [
  { label: 'Моторные масла', href: '/catalog?category=motor' },
  { label: 'Индустриальные масла', href: '/catalog?category=industrial' },
  { label: 'Трансмиссионные масла', href: '/catalog?category=transmission' },
  { label: 'Охлаждающие жидкости', href: '/catalog?category=coolant' },
  { label: 'Тормозные жидкости', href: '/catalog?category=brake' },
  { label: 'Пластичные смазки', href: '/catalog?category=greases' },
  { label: 'Автомобильная химия', href: '/catalog?category=chemistry' },
];

export const footerBusiness = [
  { label: 'Условия продажи товаров', href: '/about' },
  { label: 'Подбор масла', href: '/oil-selector' },
  { label: 'Как принимать товар', href: '/delivery' },
  { label: 'Оплата заказа', href: '/payment' },
  { label: 'Доставка и самовывоз', href: '/delivery' },
  { label: 'Аналитика рынка', href: '/analytics' },
  { label: 'Оплата в кредит', href: '/credit-payment.html' },
  { label: 'Калькулятор выкупа', href: '/buyback-calculator.html' },
];

export const footerCompany = [
  { label: 'О компании', href: '/about' },
  { label: 'Контакты', href: '/about' },
];

export const slides: SliderSlide[] = [
  {
    id: '1',
    image: '/images/slide1-genesis.jpg',
    title: 'GENESIS SPECIAL',
    subtitle: 'ЭФФЕКТИВНОЕ РЕШЕНИЕ ДЛЯ СТАНЦИЙ ТЕХОБСЛУЖИВАНИЯ',
    description: 'ЭКСКЛЮЗИВНО – ТОЛЬКО ДЛЯ КЛИЕНТОВ ИНТЕРНЕТ-МАГАЗИНА',
    buttonText: 'КУПИТЬ',
    buttonHref: '/catalog?category=motor',
  },
  {
    id: '2',
    image: '/images/slide2-welcome.jpg',
    title: 'ДОБРО ПОЖАЛОВАТЬ В B2B ИНТЕРНЕТ-МАГАЗИН',
    subtitle: 'ДЛЯ ЮРИДИЧЕСКИХ ЛИЦ',
    buttonText: 'СМОТРЕТЬ КАТАЛОГ',
    buttonHref: '/catalog',
  },
];

export const howItWorks: HowItWorkStep[] = [
  {
    id: '1',
    icon: 'cart',
    title: 'Наполните корзину товарами',
    description: 'и перейдите к оформлению заказа. Заполните реквизиты вашей компании',
  },
  {
    id: '2',
    icon: 'truck',
    title: 'Выберите способ доставки',
    description: 'и отправьте заказ в обработку. Менеджер свяжется с вами в течение одного рабочего дня',
  },
  {
    id: '3',
    icon: 'credit-card',
    title: 'Оплатите счёт',
    description: 'После подтверждения наличия товара и способа доставки будет выставлен счёт в личном кабинете и продублирован на почту',
  },
  {
    id: '4',
    icon: 'package',
    title: 'Получите заказ',
    description: 'Отслеживайте заказ от комплектации до готовности к получению в личном кабинете',
  },
];

export const advantages: Advantage[] = [
  {
    id: '1',
    icon: 'zap',
    title: 'Быстрая сделка',
    description: 'Регистрация и оформление заказа менее 8 минут',
  },
  {
    id: '2',
    icon: 'shield',
    title: 'Гарантия качества продукции',
    description: 'Каждая партия проходит паспортизацию. Паспорт качества на продукцию предоставляется по запросу',
  },
  {
    id: '3',
    icon: 'box',
    title: 'Разнообразие фасовок',
    description: 'Доступна крупная и мелкая фасовка: в бочках, канистрах, вёдрах и коробах',
  },
  {
    id: '4',
    icon: 'database',
    title: 'Доступно для заказа',
    description: 'Складские остатки на витрине интернет-магазина актуализируются в режиме реального времени',
  },
  {
    id: '5',
    icon: 'map-pin',
    title: 'Удобная доставка',
    description: 'Более 80 точек самовывоза по всей России',
  },
  {
    id: '6',
    icon: 'file-text',
    title: 'Упрощённый документооборот',
    description: 'Оферта, электронные документы в личном кабинете, оригиналы при получении заказа',
  },
];

export const categoryCards = [
  {
    id: 'motor-5w40',
    title: 'Моторные масла 5W-40',
    subtitle: 'Бочки 60/200 л',
    image: '/images/barrel-genesis.png',
    href: '/catalog?category=motor&viscosity=5W-40',
  },
  {
    id: 'motor-5w30',
    title: 'Моторные масла 5W-30',
    subtitle: 'Бочки 60/200 л',
    image: '/images/barrel-genesis.png',
    href: '/catalog?category=motor&viscosity=5W-30',
  },
  {
    id: 'motor-genesis',
    title: 'Моторные масла Genesis',
    subtitle: 'Премиум синтетика',
    image: '/images/canister-genesis.png',
    href: '/catalog?category=motor&line=genesis',
  },
  {
    id: 'motor-avantgarde',
    title: 'Моторные масла Avantgarde',
    subtitle: 'Коммерческий транспорт',
    image: '/images/canister-avantgarde.png',
    href: '/catalog?category=motor&line=avantgarde',
  },
  {
    id: 'hydraulic',
    title: 'Гидравлические масла',
    subtitle: 'Индустриальные',
    image: '/images/barrel-hydraulic.png',
    href: '/catalog?category=industrial&purpose=hydraulic',
  },
  {
    id: 'compressor',
    title: 'Компрессорные масла',
    subtitle: 'Индустриальные',
    image: '/images/barrel-compressor.png',
    href: '/catalog?category=industrial&purpose=compressor',
  },
];
