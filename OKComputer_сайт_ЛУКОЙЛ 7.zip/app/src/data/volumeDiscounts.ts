// Volume-based discount tiers
// 12% | 14% | 16% | 18%

export interface VolumeTier {
  minVolume: number;
  maxVolume: number | null;
  label: string;
  discount: number;
  color: string;
}

export const volumeTiers: VolumeTier[] = [
  { minVolume: 0, maxVolume: 999, label: 'Розница', discount: 0, color: '#666666' },
  { minVolume: 1000, maxVolume: 4999, label: 'Мелкий опт', discount: 12, color: '#4CAF50' },
  { minVolume: 5000, maxVolume: 14999, label: 'Средний опт', discount: 14, color: '#2196F3' },
  { minVolume: 15000, maxVolume: 49999, label: 'Крупный опт', discount: 16, color: '#9C27B0' },
  { minVolume: 50000, maxVolume: null, label: 'Максимум', discount: 18, color: '#D5141D' },
];

export function getDiscountForVolume(totalRubles: number): VolumeTier {
  for (let i = volumeTiers.length - 1; i >= 0; i--) {
    if (totalRubles >= volumeTiers[i].minVolume) {
      return volumeTiers[i];
    }
  }
  return volumeTiers[0];
}

export function getDiscountedPrice(originalPrice: number, totalVolume: number): number {
  const tier = getDiscountForVolume(totalVolume);
  return Math.round(originalPrice * (1 - tier.discount / 100));
}

export function getNextTier(currentTotal: number): VolumeTier | null {
  for (const tier of volumeTiers) {
    if (tier.minVolume > currentTotal) {
      return tier;
    }
  }
  return null;
}

export function getProgressToNextTier(currentTotal: number): number {
  const currentTier = getDiscountForVolume(currentTotal);
  const nextTier = getNextTier(currentTotal);
  if (!nextTier) return 100;
  const range = nextTier.minVolume - currentTier.minVolume;
  const progress = currentTotal - currentTier.minVolume;
  return Math.min(100, Math.round((progress / range) * 100));
}
