export interface Product {
  id: string;
  name: string;
  article: string;
  image: string;
  detailImage?: string;
  price: number;
  pricePerUnit: number;
  unit: string;
  category: string;
  categoryName: string;
  viscosity: string;
  api: string;
  type: 'mineral' | 'semi-synthetic' | 'synthetic';
  vehicleType: string;
  vehicleTypeFull?: string;
  packaging: PackagingOption[];
  description: string;
  previewDescription?: string;
  specs: Record<string, string>;
  inStock: boolean;
  line?: string;
  brand?: string;
  isHit?: boolean;
  isNew?: boolean;
  isSpecial?: boolean;
  weight?: number;
}

export interface PackagingOption {
  id: string;
  name: string;
  volume: string;
  quantity: number;
  price: number;
}

export interface Category {
  id: string;
  name: string;
  subcategories: SubCategory[];
  image: string;
  href: string;
}

export interface SubCategory {
  id: string;
  name: string;
  count?: number;
  href: string;
}

export interface CartItem {
  productId: string;
  packagingId: string;
  quantity: number;
  product: Product;
  packaging: PackagingOption;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface SliderSlide {
  id: string;
  image: string;
  title: string;
  subtitle?: string;
  description?: string;
  buttonText?: string;
  buttonHref?: string;
}

export interface Advantage {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface HowItWorkStep {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface SidebarMenuItem {
  id: string;
  label: string;
  href: string;
}
