export type VehicleType = 'passenger' | 'truck' | 'bus' | 'trailer' | 'special' | 'moto';

export interface Vehicle {
  id: string;
  type: VehicleType;
  typeLabel: string;
  brand: string;
  model: string;
  year: number;
  vin?: string;
  plate?: string;
  engine?: string;
  engineType?: 'gasoline' | 'diesel' | 'hybrid' | 'electric';
  createdAt: number;
}

export const vehicleTypeOptions: { value: VehicleType; label: string; icon: string }[] = [
  { value: 'passenger', label: 'Легковой автомобиль', icon: 'car' },
  { value: 'truck', label: 'Грузовой автомобиль', icon: 'truck' },
  { value: 'bus', label: 'Автобус', icon: 'bus' },
  { value: 'trailer', label: 'Прицеп / полуприцеп', icon: 'trailer' },
  { value: 'special', label: 'Спецтехника', icon: 'construction' },
  { value: 'moto', label: 'Мототехника', icon: 'bike' },
];

export const popularBrands = [
  'Toyota', 'Volkswagen', 'Hyundai', 'Kia', 'Skoda',
  'Renault', 'Nissan', 'Ford', 'Chevrolet', 'BMW',
  'Mercedes-Benz', 'Audi', 'Lada (ВАЗ)', 'Mazda', 'Honda',
  'Mitsubishi', 'Peugeot', 'Citroen', 'Volvo', 'MAN',
  'Scania', 'KAMAZ', 'GAZ', 'UAZ', 'Daewoo',
];

export const currentYear = new Date().getFullYear();
export const years = Array.from({ length: 40 }, (_, i) => currentYear - i);
