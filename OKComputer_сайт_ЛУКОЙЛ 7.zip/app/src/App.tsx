import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { TopBar } from '@/components/TopBar';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ChatButton } from '@/components/ChatButton';
import { CartProvider } from '@/hooks/useCart';
import { AuthProvider } from '@/hooks/useAuth';
import { GarageProvider } from '@/hooks/useGarage';
import { GeoProvider } from '@/hooks/useGeolocation';
import { CashbackProvider } from '@/hooks/useCashback';
import { HomePage } from '@/pages/HomePage';
import { CatalogPage } from '@/pages/CatalogPage';
import { ProductPage } from '@/pages/ProductPage';
import { DeliveryPage } from '@/pages/DeliveryPage';
import { PaymentPage } from '@/pages/PaymentPage';
import { AboutPage } from '@/pages/AboutPage';
import { OilSelectorPage } from '@/pages/OilSelectorPage';
import { PromotionsPage } from '@/pages/PromotionsPage';
import { CartPage } from '@/pages/CartPage';
import { CommercialOfferPage } from '@/pages/CommercialOfferPage';
import { GaragePage } from '@/pages/GaragePage';
import { AdminPage } from '@/pages/AdminPage';
import { EcomPage } from '@/pages/EcomPage';
import { BuybackCalculatorPage } from '@/pages/BuybackCalculatorPage';
import { CreditPaymentPage } from '@/pages/CreditPaymentPage';
import { AutoServiceAnalyticsPage } from '@/pages/AutoServiceAnalyticsPage';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CartProvider>
          <GarageProvider>
            <GeoProvider>
              <CashbackProvider>
              <div className="min-h-screen flex flex-col bg-white">
                <TopBar />
                <Header />
                <div className="flex-1">
                  <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/catalog" element={<CatalogPage />} />
                    <Route path="/product/:id" element={<ProductPage />} />
                    <Route path="/delivery" element={<DeliveryPage />} />
                    <Route path="/payment" element={<PaymentPage />} />
                    <Route path="/about" element={<AboutPage />} />
                    <Route path="/oil-selector" element={<OilSelectorPage />} />
                    <Route path="/promotions" element={<PromotionsPage />} />
                    <Route path="/cart" element={<CartPage />} />
                    <Route path="/commercial-offer" element={<CommercialOfferPage />} />
                    <Route path="/garage" element={<GaragePage />} />
                    <Route path="/admin" element={<AdminPage />} />
                    <Route path="/ecom" element={<EcomPage />} />
                    <Route path="/buyback-calculator" element={<BuybackCalculatorPage />} />
                    <Route path="/credit-payment" element={<CreditPaymentPage />} />
                    <Route path="/credit-payment.html" element={<CreditPaymentPage />} />
                    <Route path="/analytics" element={<AutoServiceAnalyticsPage />} />
                  </Routes>
                </div>
                <Footer />
                <ChatButton />
              </div>
              </CashbackProvider>
            </GeoProvider>
          </GarageProvider>
        </CartProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
