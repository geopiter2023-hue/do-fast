import { ArrowRight, Search, Phone, Shield, Truck, Award } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <section className="w-full bg-gradient-to-br from-[#f8fafc] via-white to-[#eef2ff] py-12 md:py-20">
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="flex flex-col lg:flex-row items-center gap-10">
          {/* Left: Text + Search */}
          <div className="flex-1 max-w-[600px]">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#1e293b] leading-tight">
              Официальный магазин
              <span className="text-[#dc2626]"> ЛУКОЙЛ</span>
              <br />для бизнеса
            </h1>
            <p className="mt-4 text-base md:text-lg text-[#64748b]">
              Моторные и индустриальные масла, смазки, охлаждающие жидкости напрямую от производителя
            </p>

            {/* Search bar */}
            <form onSubmit={handleSearch} className="mt-8 relative">
              <div className="flex shadow-lg rounded-xl overflow-hidden border border-[#e2e8f0]">
                <div className="flex-1 flex items-center bg-white px-4">
                  <Search className="w-5 h-5 text-[#94a3b8] flex-shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Поиск по артикулу, названию, вязкости..."
                    className="w-full px-3 py-4 text-sm outline-none bg-transparent"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-6 py-4 font-medium text-sm transition-colors flex items-center gap-2"
                >
                  Найти
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Quick stats */}
            <div className="mt-8 flex flex-wrap gap-6">
              {[
                { icon: Shield, label: 'Оригинальная продукция' },
                { icon: Truck, label: 'Доставка по всей России' },
                { icon: Award, label: '400+ товаров в каталоге' },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-sm text-[#64748b]">
                  <Icon className="w-4 h-4 text-[#2563eb]" />
                  <span>{label}</span>
                </div>
              ))}
            </div>

            {/* Phone */}
            <div className="mt-6 flex items-center gap-2 text-sm text-[#64748b]">
              <Phone className="w-4 h-4 text-[#2563eb]" />
              <span>Поддержка: <a href="tel:88007008700" className="text-[#1e293b] font-medium hover:text-[#dc2626]">8 800 700-8-700</a></span>
            </div>
          </div>

          {/* Right: Visual */}
          <div className="flex-1 flex justify-center">
            <div className="relative">
              <div className="w-[280px] h-[280px] md:w-[360px] md:h-[360px] rounded-full bg-gradient-to-br from-[#dbeafe] to-[#bfdbfe] flex items-center justify-center shadow-inner">
                <div className="w-[200px] h-[200px] md:w-[260px] md:h-[260px] rounded-full bg-gradient-to-br from-white to-[#f1f5f9] flex items-center justify-center shadow-lg">
                  <div className="text-center">
                    <div className="w-20 h-20 md:w-24 md:h-24 bg-[#dc2626] rounded-2xl flex items-center justify-center mx-auto shadow-lg rotate-3">
                      <span className="text-white font-bold text-3xl md:text-4xl">Л</span>
                    </div>
                    <p className="mt-3 text-lg font-bold text-[#1e293b]">ЛУКОЙЛ</p>
                    <p className="text-xs text-[#64748b]">Смазочные материалы</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
