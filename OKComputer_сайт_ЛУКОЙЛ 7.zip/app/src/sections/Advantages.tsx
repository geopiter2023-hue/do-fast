import { Zap, Shield, Box, Database, MapPin, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { advantages } from '@/data/navigation';

const iconMap: Record<string, React.ReactNode> = {
  zap: <Zap className="w-7 h-7 text-[#2563eb]" />,
  shield: <Shield className="w-7 h-7 text-[#2563eb]" />,
  box: <Box className="w-7 h-7 text-[#2563eb]" />,
  database: <Database className="w-7 h-7 text-[#2563eb]" />,
  'map-pin': <MapPin className="w-7 h-7 text-[#2563eb]" />,
  'file-text': <FileText className="w-7 h-7 text-[#2563eb]" />,
};

export function Advantages() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-4">
          <h2 className="text-2xl md:text-[28px] font-bold text-[#1e293b]">
            Преимущества работы с нами
          </h2>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded transition-colors text-sm font-medium"
          >
            Стать клиентом
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {advantages.map((adv) => (
            <div key={adv.id} className="flex gap-4">
              <div className="w-14 h-14 flex-shrink-0 bg-red-50 rounded-full flex items-center justify-center">
                {iconMap[adv.icon]}
              </div>
              <div>
                <h3 className="font-semibold text-[#1e293b] mb-1">{adv.title}</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">{adv.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
