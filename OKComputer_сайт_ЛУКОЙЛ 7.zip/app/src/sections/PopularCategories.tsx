import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { categories } from '@/data/navigation';

export function PopularCategories() {
  return (
    <section className="py-16 bg-[#F5F5F5]">
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-[28px] font-bold text-[#1A1A1A]">
            Популярные категории
          </h2>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-1 text-sm text-[#D5141D] hover:text-[#B01018] transition-colors"
          >
            Перейти в каталог
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {categories.map((category) => (
            <Link
              key={category.id}
              to={category.href}
              className="group bg-white rounded p-6 flex items-center justify-between hover:shadow-md transition-shadow"
            >
              <div>
                <h3 className="font-semibold text-[#1A1A1A] group-hover:text-[#D5141D] transition-colors mb-2">
                  {category.name}
                </h3>
                <div className="space-y-1">
                  {category.subcategories.slice(0, 3).map((sub) => (
                    <span key={sub.id} className="text-sm text-[#666666] block">
                      {sub.name}
                    </span>
                  ))}
                </div>
              </div>
              <div className="w-20 h-24 flex-shrink-0 flex items-center justify-center">
                <img
                  src={category.image}
                  alt={category.name}
                  className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
