import { Link } from 'react-router-dom';
import {
  Fuel, Cog, Droplets, Thermometer, CircleDot, FlaskConical,
  Wrench, Snowflake, type LucideIcon
} from 'lucide-react';
import { getProductsByCategory } from '@/data/products';
import { allCategories } from '@/data/navigation';

const categoryIcons: Record<string, LucideIcon> = {
  'motor': Fuel,
  'industrial': Wrench,
  'transmission': Cog,
  'coolant': Thermometer,
  'brake': CircleDot,
  'greases': Droplets,
  'chemistry': FlaskConical,
  'coolant-grease': Snowflake,
};

export function CategoryGrid() {
  const categoriesWithProducts = allCategories.filter(cat => getProductsByCategory(cat.id).length > 0);

  return (
    <section className="py-10">
      <div className="max-w-[1400px] mx-auto px-5">
        <h2 className="text-xl md:text-2xl font-bold text-[#1e293b] mb-6">Каталог</h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {categoriesWithProducts.map((cat) => {
            const Icon = categoryIcons[cat.id] || Fuel;
            const count = getProductsByCategory(cat.id).length;

            return (
              <Link
                key={cat.id}
                to={cat.href}
                className="group bg-white rounded-xl p-5 border border-[#e2e8f0] hover:shadow-lg hover:border-[#bfdbfe] transition-all duration-300"
              >
                <Icon className="w-8 h-8 text-[#2563eb] group-hover:scale-110 transition-transform" strokeWidth={1.5} />
                <h3 className="mt-3 text-sm font-semibold text-[#1e293b] group-hover:text-[#2563eb] transition-colors leading-tight">
                  {cat.name}
                </h3>
                <p className="mt-1 text-xs text-[#94a3b8]">{count.toLocaleString('ru-RU')} товаров</p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
