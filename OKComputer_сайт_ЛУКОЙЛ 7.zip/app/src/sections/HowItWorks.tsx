import { ShoppingCart, Truck, CreditCard, Package, ArrowRight } from 'lucide-react';
import { howItWorks } from '@/data/navigation';

const iconMap: Record<string, React.ReactNode> = {
  cart: <ShoppingCart className="w-8 h-8 text-[#2563eb]" />,
  truck: <Truck className="w-8 h-8 text-[#2563eb]" />,
  'credit-card': <CreditCard className="w-8 h-8 text-[#2563eb]" />,
  package: <Package className="w-8 h-8 text-[#2563eb]" />,
};

export function HowItWorks() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-[1400px] mx-auto px-5">
        <h2 className="text-2xl md:text-[28px] font-bold text-[#1e293b] text-center mb-12">
          Схема работы
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {howItWorks.map((step, index) => (
            <div key={step.id} className="relative">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-red-50 rounded-full flex items-center justify-center">
                  {iconMap[step.icon]}
                </div>
                <h3 className="font-semibold text-[#1e293b] mb-2">{step.title}</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">{step.description}</p>
              </div>
              {index < howItWorks.length - 1 && (
                <div className="hidden lg:block absolute top-8 -right-3 text-[#e2e8f0]">
                  <ArrowRight className="w-6 h-6" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
