import { Link } from 'react-router-dom';

export function AboutBlock() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-2xl md:text-[28px] font-bold text-[#1e293b] leading-tight mb-6">
              Работайте с <span className="text-[#2563eb]">лидером</span> российского рынка
              автомобильных и индустриальных масел без посредников
            </h2>
            <div className="space-y-4 text-[#1e293b] leading-relaxed">
              <p>
                Официальный интернет-магазин по оптовой продаже автомобильных масел и смазочных
                материалов ЛУКОЙЛ предлагает юридическим лицам и индивидуальным предпринимателям
                широкий ассортимент продукции на специальных условиях.
              </p>
              <p>
                Мы предлагаем оптовикам удобные варианты фасовки, отвечающие потребностям различных
                направлений бизнеса: масла в канистрах, в коробках и поштучно, в бочках, бидонах, барабанах.
              </p>
              <p>
                Контролируйте заказы и управляйте расходами на закупку смазочных материалов через
                Личный кабинет на сайте.
              </p>
            </div>
            <Link
              to="/about"
              className="inline-block mt-6 px-6 py-3 border border-[#2563eb] text-[#2563eb] rounded hover:bg-[#2563eb] hover:text-white transition-colors"
            >
              Подробнее о нас
            </Link>
          </div>

          <div className="relative">
            <img
              src="/images/about-barrels.jpg"
              alt="Бочки ЛУКОЙЛ"
              className="w-full h-auto rounded-lg shadow-lg object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
