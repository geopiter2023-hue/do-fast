import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ShoppingCart, Award } from 'lucide-react';
import { useRef, useState } from 'react';
import { getProductsByCategory } from '@/data/products';
import { allCategories } from '@/data/navigation';
import { useCart } from '@/hooks/useCart';
import { useCashback } from '@/hooks/useCashback';
import { getStockLabel } from '@/data/stockLabels';
import { getDiscountedPrice } from '@/data/volumeDiscounts';

// Soft category banner backgrounds
const categoryBannerBg: Record<string, string> = {
  'motor': 'bg-gradient-to-r from-[#1e3a5f] to-[#2d5a8f]',
  'industrial': 'bg-gradient-to-r from-[#5c4033] to-[#8b6914]',
  'transmission': 'bg-gradient-to-r from-[#374151] to-[#4b5563]',
  'coolant': 'bg-gradient-to-r from-[#0e4a6e] to-[#1a7ab8]',
  'brake': 'bg-gradient-to-r from-[#7c2d12] to-[#c2410c]',
  'greases': 'bg-gradient-to-r from-[#14532d] to-[#16a34a]',
  'chemistry': 'bg-gradient-to-r from-[#581c87] to-[#7c3aed]',
  'coolant-grease': 'bg-gradient-to-r from-[#134e4a] to-[#0d9488]',
};

function QuickAddButton({ product }: { product: ReturnType<typeof getProductsByCategory>[0] }) {
  const { addItem } = useCart();
  const { earnPoints } = useCashback();
  const [selectedPkg, setSelectedPkg] = useState(0);
  const [added, setAdded] = useState(false);

  const pkg = product.packaging[selectedPkg];
  if (!pkg) return null;

  const discountedPrice = getDiscountedPrice(pkg.price, pkg.price);
  const points = Math.round(pkg.price / 10);

  const handleAdd = () => {
    addItem(product, pkg, 1);
    earnPoints(product.name, pkg.price);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="mt-2 space-y-2">
      {product.packaging.length > 1 && (
        <div className="flex gap-1 flex-wrap">
          {product.packaging.map((p, idx) => (
            <button
              key={p.id}
              onClick={(e) => { e.stopPropagation(); setSelectedPkg(idx); }}
              className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${
                selectedPkg === idx
                  ? 'border-[#2563eb] bg-[#2563eb] text-white'
                  : 'border-[#e2e8f0] text-[#64748b] hover:border-[#2563eb]'
              }`}
            >
              {p.volume}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <span className="font-bold text-[#1e293b] text-sm">{discountedPrice.toLocaleString('ru-RU')} ₽</span>
          {discountedPrice < pkg.price && (
            <span className="text-[10px] text-[#94a3b8] line-through">{pkg.price.toLocaleString('ru-RU')} ₽</span>
          )}
        </div>
        <button
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleAdd(); }}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            added
              ? 'bg-green-500 text-white'
              : 'bg-[#2563eb] text-white hover:bg-[#1d4ed8]'
          }`}
        >
          <ShoppingCart className="w-3 h-3" />
          {added ? 'Добавлено' : 'В корзину'}
        </button>
      </div>

      <div className="flex items-center gap-1 text-[10px] text-amber-600">
        <Award className="w-3 h-3" />
        <span>+{points} баллов</span>
      </div>
    </div>
  );
}

function ProductCard({ product }: { product: ReturnType<typeof getProductsByCategory>[0] }) {
  const stockLabel = getStockLabel(product.inStock ? 10 : 0);
  const [imgError, setImgError] = useState(false);

  return (
    <div className="flex-shrink-0 w-[220px] bg-white rounded-xl border border-[#e2e8f0] hover:shadow-lg hover:border-[#cbd5e1] transition-all duration-300 group overflow-hidden">
      <Link to={`/product/${product.id}`} className="block">
        <div className="h-[140px] bg-white rounded-t-xl flex items-center justify-center p-4 relative">
          {!imgError ? (
            <img
              src={product.image}
              alt={product.name}
              className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-[#f1f5f9] flex items-center justify-center">
              <span className="text-xl font-bold text-[#cbd5e1]">{product.name.charAt(0)}</span>
            </div>
          )}
          <div className={`absolute top-2 right-2 ${stockLabel.bgColor} ${stockLabel.color} text-[10px] font-medium px-2 py-0.5 rounded-full`}>
            {stockLabel.text}
          </div>
        </div>
      </Link>

      <div className="p-3">
        <Link to={`/product/${product.id}`}>
          <h4 className="text-sm font-medium text-[#1e293b] line-clamp-2 group-hover:text-[#2563eb] transition-colors min-h-[40px] leading-snug">
            {product.name}
          </h4>
        </Link>

        <div className="flex gap-1 mt-1 flex-wrap">
          {product.viscosity && (
            <span className="text-[10px] bg-[#f1f5f9] text-[#64748b] px-1.5 py-0.5 rounded">{product.viscosity}</span>
          )}
          {product.api && (
            <span className="text-[10px] bg-[#f1f5f9] text-[#64748b] px-1.5 py-0.5 rounded">{product.api}</span>
          )}
        </div>

        <QuickAddButton product={product} />
      </div>
    </div>
  );
}

function CategorySection({ category }: { category: typeof allCategories[0] }) {
  const products = getProductsByCategory(category.id).slice(0, 8);
  if (products.length === 0) return null;

  const bgClass = categoryBannerBg[category.id] || 'bg-gradient-to-r from-[#374151] to-[#4b5563]';
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === 'left' ? -520 : 520, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-6">
      {/* Banner */}
      <div className={`${bgClass} rounded-2xl overflow-hidden mb-5 relative shadow-sm`}>
        <div className="absolute right-0 top-0 w-1/3 h-full opacity-10 bg-gradient-to-l from-white to-transparent" />
        <div className="w-full mx-auto px-6 py-5 flex items-center justify-between relative z-10">
          <div>
            <h2 className="text-lg md:text-xl font-bold text-white">{category.name}</h2>
            <p className="text-blue-100 text-xs mt-1 opacity-80">{products.length} товаров</p>
          </div>
          <Link
            to={category.href}
            className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium flex-shrink-0"
          >
            Смотреть все
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* Products */}
      <div className="relative px-1">
        <button
          onClick={() => scroll('left')}
          className="absolute -left-3 top-1/2 -translate-y-1/2 z-10 w-9 h-9 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-[#f8fafc] transition-colors border border-[#e2e8f0]"
        >
          <ChevronLeft className="w-4 h-4 text-[#1e293b]" />
        </button>
        <button
          onClick={() => scroll('right')}
          className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-9 h-9 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-[#f8fafc] transition-colors border border-[#e2e8f0]"
        >
          <ChevronRight className="w-4 h-4 text-[#1e293b]" />
        </button>

        <div
          ref={scrollRef}
          className="flex gap-3 overflow-x-auto px-10 py-1 scroll-smooth"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}

export function CategoryProducts() {
  const categoriesWithProducts = allCategories.filter(cat => getProductsByCategory(cat.id).length > 0);

  return (
    <div className="bg-[#f8fafc] py-4">
      <div className="max-w-[1400px] mx-auto px-5">
        {categoriesWithProducts.map((category) => (
          <CategorySection key={category.id} category={category} />
        ))}
      </div>
    </div>
  );
}
