import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { ProductCard } from '@/components/ProductCard';
import { getPopularProducts } from '@/data/products';

export function PopularProducts() {
  const products = getPopularProducts();

  return (
    <section className="py-16 bg-white">
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-[28px] font-bold text-[#1e293b]">
            Популярные товары
          </h2>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-1 text-sm text-[#2563eb] hover:text-[#1d4ed8] transition-colors"
          >
            Смотреть все
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {products.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} compact />
          ))}
        </div>
      </div>
    </section>
  );
}
