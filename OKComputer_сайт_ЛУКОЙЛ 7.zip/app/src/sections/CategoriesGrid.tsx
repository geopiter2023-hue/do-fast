import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { categoryCards } from '@/data/navigation';

export function CategoriesGrid() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-[1400px] mx-auto px-5">
        <h2 className="text-2xl md:text-[28px] font-bold text-[#1A1A1A] text-center mb-10">
          Оптовая продажа масел и смазочных материалов
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {categoryCards.map((card) => (
            <Link
              key={card.id}
              to={card.href}
              className="group bg-[#F5F5F5] rounded p-5 flex items-center justify-between hover:bg-[#EBEBEB] transition-colors"
            >
              <div className="flex-1">
                <h3 className="font-semibold text-[#1A1A1A] group-hover:text-[#D5141D] transition-colors">
                  {card.title}
                </h3>
                <p className="text-sm text-[#666666] mt-1">{card.subtitle}</p>
                <div className="mt-3 w-10 h-10 bg-[#D5141D] rounded-full flex items-center justify-center group-hover:bg-[#B01018] transition-colors">
                  <ArrowRight className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="w-28 h-28 flex-shrink-0 flex items-center justify-center">
                <img
                  src={card.image}
                  alt={card.title}
                  className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
