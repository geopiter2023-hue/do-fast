import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export function HelpBanner() {
  return (
    <section className="px-5 mb-12">
      <div className="max-w-[1400px] mx-auto">
        <div className="bg-[#2B2F3B] rounded-lg overflow-hidden relative">
          <div className="flex flex-col md:flex-row items-center justify-between p-8 md:p-10">
            <div className="flex-1 z-10">
              <h3 className="text-xl md:text-2xl font-bold text-white mb-2">
                Нужна помощь в выборе?
              </h3>
              <p className="text-gray-300 text-sm md:text-base mb-4">
                Если вы сомневаетесь в выборе масла, воспользуйтесь нашим подборщиком
              </p>
              <Link
                to="/oil-selector"
                className="inline-flex items-center gap-2 text-[#D5141D] hover:text-[#ff3040] font-medium transition-colors"
              >
                Подобрать моторное масло
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="hidden md:block w-48 h-32 flex-shrink-0">
              <img
                src="/images/canister-genesis.png"
                alt="Моторное масло"
                className="w-full h-full object-contain opacity-80"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
