import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

interface GeoState {
  city: string;
  region: string;
}

interface GeoContextType {
  state: GeoState;
  setCity: (city: string, region?: string) => void;
  showModal: boolean;
  openModal: () => void;
  closeModal: () => void;
}

const STORAGE_KEY = 'lukoil_city';

const defaultCities = [
  'Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань',
  'Нижний Новгород', 'Челябинск', 'Самара', 'Омск', 'Ростов-на-Дону',
  'Уфа', 'Красноярск', 'Воронеж', 'Пермь', 'Волгоград',
  'Краснодар', 'Саратов', 'Тюмень', 'Тольятти', 'Ижевск',
  'Барнаул', 'Иркутск', 'Хабаровск', 'Ярославль', 'Владивосток',
  'Махачкала', 'Томск', 'Оренбург', 'Кемерово', 'Новокузнецк',
  'Рязань', 'Астрахань', 'Пенза', 'Липецк', 'Тула',
  'Киров', 'Чебоксары', 'Калининград', 'Брянск', 'Курск',
];

export { defaultCities };

function loadCity(): string {
  try {
    return localStorage.getItem(STORAGE_KEY) || 'Москва';
  } catch {
    return 'Москва';
  }
}

function saveCity(city: string) {
  localStorage.setItem(STORAGE_KEY, city);
}

const GeoContext = createContext<GeoContextType | null>(null);

export function GeoProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<GeoState>({ city: loadCity(), region: '' });
  const [showModal, setShowModal] = useState(false);

  const setCity = useCallback((city: string, region?: string) => {
    setState({ city, region: region || '' });
    saveCity(city);
  }, []);

  const openModal = useCallback(() => setShowModal(true), []);
  const closeModal = useCallback(() => setShowModal(false), []);

  return (
    <GeoContext.Provider value={{ state, setCity, showModal, openModal, closeModal }}>
      {children}
    </GeoContext.Provider>
  );
}

export function useGeolocation() {
  const context = useContext(GeoContext);
  if (!context) {
    throw new Error('useGeolocation must be used within a GeoProvider');
  }
  return context;
}
