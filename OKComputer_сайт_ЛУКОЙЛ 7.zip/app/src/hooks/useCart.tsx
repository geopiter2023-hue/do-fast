import { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { CartItem, Product, PackagingOption } from '@/types';

interface CartState {
  items: CartItem[];
  selectedRegion: string;
  selectedWarehouseIds: Record<string, string>; // productId -> warehouseId
}

type CartAction =
  | { type: 'ADD_ITEM'; payload: { product: Product; packaging: PackagingOption; quantity: number; warehouseId?: string } }
  | { type: 'REMOVE_ITEM'; payload: { productId: string; packagingId: string } }
  | { type: 'UPDATE_QUANTITY'; payload: { productId: string; packagingId: string; quantity: number } }
  | { type: 'SELECT_WAREHOUSE'; payload: { productId: string; warehouseId: string } }
  | { type: 'SET_REGION'; payload: string }
  | { type: 'CLEAR' };

const CartContext = createContext<{
  state: CartState;
  addItem: (product: Product, packaging: PackagingOption, quantity: number, warehouseId?: string) => void;
  removeItem: (productId: string, packagingId: string) => void;
  updateQuantity: (productId: string, packagingId: string, quantity: number) => void;
  selectWarehouse: (productId: string, warehouseId: string) => void;
  setRegion: (region: string) => void;
  clearCart: () => void;
  totalCount: number;
  totalPrice: number;
  totalWeight: number;
} | null>(null);

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'ADD_ITEM': {
      const { product, packaging, quantity, warehouseId } = action.payload;
      const existingIndex = state.items.findIndex(
        item => item.productId === product.id && item.packagingId === packaging.id
      );
      const newItems = [...state.items];
      if (existingIndex >= 0) {
        newItems[existingIndex] = {
          ...newItems[existingIndex],
          quantity: newItems[existingIndex].quantity + quantity,
        };
      } else {
        newItems.push({ productId: product.id, packagingId: packaging.id, quantity, product, packaging });
      }
      const newWarehouseIds = warehouseId
        ? { ...state.selectedWarehouseIds, [product.id]: warehouseId }
        : state.selectedWarehouseIds;
      return { ...state, items: newItems, selectedWarehouseIds: newWarehouseIds };
    }
    case 'REMOVE_ITEM': {
      const newItems = state.items.filter(
        item => !(item.productId === action.payload.productId && item.packagingId === action.payload.packagingId)
      );
      return { ...state, items: newItems };
    }
    case 'UPDATE_QUANTITY': {
      if (action.payload.quantity <= 0) {
        return cartReducer(state, { type: 'REMOVE_ITEM', payload: { productId: action.payload.productId, packagingId: action.payload.packagingId } });
      }
      return {
        ...state,
        items: state.items.map(item =>
          item.productId === action.payload.productId && item.packagingId === action.payload.packagingId
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      };
    }
    case 'SELECT_WAREHOUSE':
      return {
        ...state,
        selectedWarehouseIds: { ...state.selectedWarehouseIds, [action.payload.productId]: action.payload.warehouseId },
      };
    case 'SET_REGION':
      return { ...state, selectedRegion: action.payload };
    case 'CLEAR':
      return { items: [], selectedRegion: state.selectedRegion, selectedWarehouseIds: {} };
    default:
      return state;
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, {
    items: [],
    selectedRegion: 'Москва',
    selectedWarehouseIds: {},
  });

  const addItem = (product: Product, packaging: PackagingOption, quantity: number, warehouseId?: string) => {
    dispatch({ type: 'ADD_ITEM', payload: { product, packaging, quantity, warehouseId } });
  };

  const removeItem = (productId: string, packagingId: string) => {
    dispatch({ type: 'REMOVE_ITEM', payload: { productId, packagingId } });
  };

  const updateQuantity = (productId: string, packagingId: string, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { productId, packagingId, quantity } });
  };

  const selectWarehouse = (productId: string, warehouseId: string) => {
    dispatch({ type: 'SELECT_WAREHOUSE', payload: { productId, warehouseId } });
  };

  const setRegion = (region: string) => {
    dispatch({ type: 'SET_REGION', payload: region });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR' });
  };

  const totalCount = state.items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = state.items.reduce((sum, item) => sum + item.packaging.price * item.quantity, 0);
  const totalWeight = state.items.reduce((sum, item) => {
    const weightPerUnit = item.packaging.volume.includes('л') ? parseFloat(item.packaging.volume) * 0.9 : 1;
    return sum + weightPerUnit * item.quantity;
  }, 0);

  return (
    <CartContext.Provider value={{ state, addItem, removeItem, updateQuantity, selectWarehouse, setRegion, clearCart, totalCount, totalPrice, totalWeight }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
