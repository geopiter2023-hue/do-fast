import { createContext, useContext, useState, type ReactNode } from 'react';

interface User {
  email: string;
  name: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  showModal: boolean;
  modalTab: 'login' | 'register';
}

interface AuthContextType {
  state: AuthState;
  login: (email: string, password: string) => void;
  logout: () => void;
  openModal: (tab?: 'login' | 'register') => void;
  closeModal: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    showModal: false,
    modalTab: 'login',
  });

  const login = (email: string, _password: string) => {
    setState({
      ...state,
      isAuthenticated: true,
      user: { email, name: email.split('@')[0] },
      showModal: false,
    });
  };

  const logout = () => {
    setState({
      isAuthenticated: false,
      user: null,
      showModal: false,
      modalTab: 'login',
    });
  };

  const openModal = (tab: 'login' | 'register' = 'login') => {
    setState({ ...state, showModal: true, modalTab: tab });
  };

  const closeModal = () => {
    setState({ ...state, showModal: false });
  };

  return (
    <AuthContext.Provider value={{ state, login, logout, openModal, closeModal }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
