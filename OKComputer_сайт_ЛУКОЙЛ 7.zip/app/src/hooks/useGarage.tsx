import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Vehicle } from '@/types/garage';

interface GarageState {
  vehicles: Vehicle[];
}

interface GarageContextType {
  state: GarageState;
  addVehicle: (vehicle: Omit<Vehicle, 'id' | 'createdAt'>) => void;
  removeVehicle: (id: string) => void;
  vehicleCount: number;
}

const GarageContext = createContext<GarageContextType | null>(null);

const STORAGE_KEY = 'lukoil_garage';

function loadGarage(): Vehicle[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveGarage(vehicles: Vehicle[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(vehicles));
}

export function GarageProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<GarageState>({ vehicles: loadGarage() });

  const addVehicle = useCallback((vehicle: Omit<Vehicle, 'id' | 'createdAt'>) => {
    const newVehicle: Vehicle = {
      ...vehicle,
      id: `v_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
    };
    setState((prev) => {
      const updated = { vehicles: [...prev.vehicles, newVehicle] };
      saveGarage(updated.vehicles);
      return updated;
    });
  }, []);

  const removeVehicle = useCallback((id: string) => {
    setState((prev) => {
      const updated = { vehicles: prev.vehicles.filter((v) => v.id !== id) };
      saveGarage(updated.vehicles);
      return updated;
    });
  }, []);

  return (
    <GarageContext.Provider
      value={{
        state,
        addVehicle,
        removeVehicle,
        vehicleCount: state.vehicles.length,
      }}
    >
      {children}
    </GarageContext.Provider>
  );
}

export function useGarage() {
  const context = useContext(GarageContext);
  if (!context) {
    throw new Error('useGarage must be used within a GarageProvider');
  }
  return context;
}
