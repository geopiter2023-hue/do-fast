import { createContext, useContext, useReducer, type ReactNode } from 'react';

export interface CashbackState {
  points: number;
  history: CashbackTransaction[];
}

export interface CashbackTransaction {
  id: string;
  date: string;
  productName: string;
  amount: number;
  type: 'earn' | 'spend';
}

interface CashbackAction {
  type: 'EARN_POINTS' | 'SPEND_POINTS' | 'LOAD_STATE';
  payload?: { productName: string; amount: number; transaction?: CashbackTransaction };
}

function calculatePoints(productPrice: number): number {
  // 1 point per 10 rubles spent
  return Math.round(productPrice / 10);
}

function cashbackReducer(state: CashbackState, action: CashbackAction): CashbackState {
  switch (action.type) {
    case 'EARN_POINTS': {
      const pts = calculatePoints(action.payload?.amount || 0);
      const tx: CashbackTransaction = {
        id: `tx-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        productName: action.payload?.productName || 'Покупка',
        amount: pts,
        type: 'earn',
      };
      const newState = {
        points: state.points + pts,
        history: [tx, ...state.history],
      };
      localStorage.setItem('lukoil_cashback', JSON.stringify(newState));
      return newState;
    }
    case 'SPEND_POINTS': {
      const pts = action.payload?.amount || 0;
      if (state.points < pts) return state;
      const tx: CashbackTransaction = {
        id: `tx-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        productName: action.payload?.productName || 'Списание',
        amount: pts,
        type: 'spend',
      };
      const newState = {
        points: state.points - pts,
        history: [tx, ...state.history],
      };
      localStorage.setItem('lukoil_cashback', JSON.stringify(newState));
      return newState;
    }
    case 'LOAD_STATE':
      return action.payload?.transaction
        ? { points: action.payload.amount, history: [action.payload.transaction] }
        : state;
    default:
      return state;
  }
}

const CashbackContext = createContext<{
  state: CashbackState;
  earnPoints: (productName: string, amount: number) => void;
  spendPoints: (productName: string, amount: number) => void;
  getPointsForProduct: (price: number) => number;
} | null>(null);

const STORAGE_KEY = 'lukoil_cashback';

function loadInitialState(): CashbackState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  // Demo starting balance
  return { points: 1250, history: [] };
}

export function CashbackProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cashbackReducer, null, loadInitialState);

  const earnPoints = (productName: string, amount: number) => {
    dispatch({ type: 'EARN_POINTS', payload: { productName, amount } });
  };

  const spendPoints = (productName: string, amount: number) => {
    dispatch({ type: 'SPEND_POINTS', payload: { productName, amount } });
  };

  const getPointsForProduct = (price: number): number => calculatePoints(price);

  return (
    <CashbackContext.Provider value={{ state, earnPoints, spendPoints, getPointsForProduct }}>
      {children}
    </CashbackContext.Provider>
  );
}

export function useCashback() {
  const context = useContext(CashbackContext);
  if (!context) throw new Error('useCashback must be used within CashbackProvider');
  return context;
}
